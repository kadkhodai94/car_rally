#!/usr/bin/env python3
from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[2]
res_root = root / 'android' / 'app' / 'src' / 'main' / 'res'
source_root = root / 'assets' / 'launcher_icons'

if not res_root.exists():
    raise SystemExit('Android resources directory not found. Run flutter create first.')

for src_dir in source_root.glob('mipmap-*'):
    target_dir = res_root / src_dir.name
    target_dir.mkdir(parents=True, exist_ok=True)
    for icon_name in ('ic_launcher.png', 'ic_launcher_round.png'):
        src = src_dir / icon_name
        if src.exists():
            shutil.copy2(src, target_dir / icon_name)

manifest = root / 'android' / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    text = text.replace('android:label="vertical_racer"', 'android:label="جاده بی‌پایان"')
    text = text.replace('android:label="vertical racer"', 'android:label="جاده بی‌پایان"')
    if 'android:roundIcon=' not in text:
        text = text.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"')
    manifest.write_text(text, encoding='utf-8')

print('Launcher icons applied.')
