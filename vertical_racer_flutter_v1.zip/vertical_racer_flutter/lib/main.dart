import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF070A18),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const VerticalRacerApp());
}

class VerticalRacerApp extends StatelessWidget {
  const VerticalRacerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'جاده بی‌پایان',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF31D8FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _highScore = 0;
  int _totalCoins = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _highScore = prefs.getInt(StorageKeys.highScore) ?? 0;
      _totalCoins = prefs.getInt(StorageKeys.totalCoins) ?? 0;
    });
  }

  Future<void> _startGame() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const Directionality(
          textDirection: TextDirection.rtl,
          child: GameScreen(),
        ),
      ),
    );
    await _loadStats();
  }

  void _showGuide() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF121A35),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.white.withOpacity(0.10)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 28,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'راهنمای سریع',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 14),
            _GuideLine(icon: Icons.touch_app_rounded, text: 'سمت چپ صفحه را لمس کن تا ماشین یک لاین به چپ برود.'),
            _GuideLine(icon: Icons.touch_app_rounded, text: 'سمت راست صفحه را لمس کن تا ماشین یک لاین به راست برود.'),
            _GuideLine(icon: Icons.speed_rounded, text: 'با بالا رفتن امتیاز، سرعت و تعداد مانع‌ها بیشتر می‌شود.'),
            _GuideLine(icon: Icons.shield_rounded, text: 'سپر، آهنربا و نیترو را بگیر تا بیشتر دوام بیاوری.'),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF172B64), Color(0xFF070A18)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              const Positioned.fill(child: _HomeBackground()),
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        _StatChip(icon: Icons.emoji_events_rounded, label: 'رکورد', value: _highScore.toString()),
                        const SizedBox(width: 10),
                        _StatChip(icon: Icons.monetization_on_rounded, label: 'سکه', value: _totalCoins.toString()),
                      ],
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(34),
                        gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: [
                            Colors.white.withOpacity(0.18),
                            Colors.white.withOpacity(0.06),
                          ],
                        ),
                        border: Border.all(color: Colors.white.withOpacity(0.12)),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF31D8FF).withOpacity(0.16),
                            blurRadius: 35,
                            offset: const Offset(0, 18),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          const Text(
                            'جاده بی‌پایان',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 38,
                              height: 1,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -1.0,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'مسابقه عمودی، سریع، روان و مرحله‌ای',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.74),
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 30),
                          SizedBox(
                            height: 168,
                            child: CustomPaint(
                              painter: _HeroCarPainter(),
                              child: const SizedBox.expand(),
                            ),
                          ),
                          const SizedBox(height: 30),
                          _PrimaryButton(
                            title: 'شروع بازی',
                            icon: Icons.play_arrow_rounded,
                            onPressed: _startGame,
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: _GhostButton(
                                  title: 'راهنما',
                                  icon: Icons.info_outline_rounded,
                                  onPressed: _showGuide,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _GhostButton(
                                  title: 'گاراژ',
                                  icon: Icons.directions_car_filled_rounded,
                                  onPressed: () {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('گاراژ ماشین‌ها برای نسخه بعد آماده می‌شود.')),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Text(
                      'هدف: جاخالی بده، سکه جمع کن، رکورد بزن.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white.withOpacity(0.56), fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GuideLine extends StatelessWidget {
  const _GuideLine({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: const Color(0xFF31D8FF).withOpacity(0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: const Color(0xFF31D8FF), size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: Colors.white.withOpacity(0.80), height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.10),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.10)),
        ),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFFFFD166), size: 24),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(color: Colors.white.withOpacity(0.58), fontSize: 12)),
                  Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({required this.title, required this.icon, required this.onPressed});

  final String title;
  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(24),
        child: Ink(
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              colors: [Color(0xFF31D8FF), Color(0xFF6C63FF)],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF31D8FF).withOpacity(0.30),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 34, color: Colors.white),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      ),
    );
  }
}

class _GhostButton extends StatelessWidget {
  const _GhostButton({required this.title, required this.icon, required this.onPressed});

  final String title;
  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(20),
        child: Ink(
          height: 50,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white.withOpacity(0.09),
            border: Border.all(color: Colors.white.withOpacity(0.11)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white.withOpacity(0.82)),
              const SizedBox(width: 7),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomeBackground extends StatelessWidget {
  const _HomeBackground();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _HomeBackgroundPainter());
  }
}

class _HomeBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    paint.color = const Color(0xFF31D8FF).withOpacity(0.08);
    canvas.drawCircle(Offset(size.width * 0.14, size.height * 0.18), 92, paint);
    paint.color = const Color(0xFF6C63FF).withOpacity(0.10);
    canvas.drawCircle(Offset(size.width * 0.88, size.height * 0.36), 128, paint);
    paint.color = const Color(0xFFFFD166).withOpacity(0.07);
    canvas.drawCircle(Offset(size.width * 0.18, size.height * 0.80), 112, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  final math.Random _random = math.Random();
  final List<RoadEntity> _entities = <RoadEntity>[];

  late final Ticker _ticker;
  Duration? _lastTick;

  int _targetLane = 1;
  double _playerLaneX = 1.0;
  double _score = 0;
  int _coinsThisRun = 0;
  int _level = 1;
  double _roadOffset = 0;
  double _spawnTimer = 0;
  double _shake = 0;
  double _shieldSeconds = 0;
  double _magnetSeconds = 0;
  double _nitroSeconds = 0;
  bool _gameOver = false;
  bool _saved = false;
  int _bestScore = 0;
  int _totalCoinsBeforeRun = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
    _ticker = createTicker(_tick)..start();
  }

  Future<void> _loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _bestScore = prefs.getInt(StorageKeys.highScore) ?? 0;
      _totalCoinsBeforeRun = prefs.getInt(StorageKeys.totalCoins) ?? 0;
    });
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  double get _speed {
    final nitroBoost = _nitroSeconds > 0 ? 0.15 : 0.0;
    return 0.23 + (_level - 1) * 0.022 + nitroBoost;
  }

  double get _spawnInterval {
    final raw = 1.26 - (_level - 1) * 0.055;
    return math.max(0.46, raw);
  }

  void _tick(Duration elapsed) {
    final previous = _lastTick;
    _lastTick = elapsed;
    if (previous == null || _gameOver) return;

    final dt = ((elapsed - previous).inMicroseconds / 1000000.0).clamp(0.0, 0.05).toDouble();
    _updateGame(dt);
  }

  void _updateGame(double dt) {
    final nextLevel = (_score ~/ 650) + 1;
    if (nextLevel != _level) {
      _level = nextLevel;
      _shake = 0.22;
    }

    _shieldSeconds = math.max(0.0, _shieldSeconds - dt);
    _magnetSeconds = math.max(0.0, _magnetSeconds - dt);
    _nitroSeconds = math.max(0.0, _nitroSeconds - dt);
    _shake = math.max(0.0, _shake - dt);

    final speed = _speed;
    final scoreMultiplier = _nitroSeconds > 0 ? 1.4 : 1.0;
    _score += dt * speed * 1220 * scoreMultiplier;
    _roadOffset = (_roadOffset + dt * speed * 960) % 96;
    _playerLaneX += (_targetLane - _playerLaneX) * math.min(1.0, dt * 12);

    _spawnTimer -= dt;
    if (_spawnTimer <= 0) {
      _spawnWave();
      _spawnTimer = _spawnInterval * (0.84 + _random.nextDouble() * 0.34);
    }

    for (final entity in _entities) {
      entity.y += dt * speed * entity.speedMultiplier;
      if (entity.kind == EntityKind.enemy && _level >= 5) {
        entity.drift += dt * entity.driftDirection * 0.30;
        if (entity.drift.abs() > 0.18) entity.driftDirection *= -1;
      }
    }

    _handleCollisions();
    _entities.removeWhere((entity) => entity.y > 1.22 || entity.collected);

    if (mounted) setState(() {});
  }

  void _spawnWave() {
    final lanes = <int>[0, 1, 2]..shuffle(_random);
    final shouldSpawnPair = _level >= 4 && _random.nextDouble() < math.min(0.34, 0.08 + _level * 0.015);
    final count = shouldSpawnPair ? 2 : 1;

    for (var i = 0; i < count; i++) {
      final lane = lanes[i];
      final kind = _chooseEntityKind(forceHazard: shouldSpawnPair && i == 1);
      _entities.add(
        RoadEntity(
          kind: kind,
          lane: lane,
          y: -0.18 - i * 0.10,
          seed: _random.nextDouble(),
          speedMultiplier: kind == EntityKind.enemy ? 1.04 + _random.nextDouble() * 0.10 : 1.0,
          driftDirection: _random.nextBool() ? 1 : -1,
        ),
      );
    }

    if (_random.nextDouble() < 0.22 && _level <= 8) {
      final freeLane = lanes.last;
      _entities.add(
        RoadEntity(kind: EntityKind.coin, lane: freeLane, y: -0.34, seed: _random.nextDouble()),
      );
    }
  }

  EntityKind _chooseEntityKind({bool forceHazard = false}) {
    if (forceHazard) return _random.nextBool() ? EntityKind.enemy : EntityKind.cone;
    final roll = _random.nextDouble();
    if (roll < 0.42) return EntityKind.coin;
    if (roll < 0.75) return EntityKind.enemy;
    if (roll < 0.88) return EntityKind.cone;
    if (roll < 0.925) return EntityKind.shield;
    if (roll < 0.965) return EntityKind.magnet;
    return EntityKind.nitro;
  }

  void _handleCollisions() {
    const playerY = 0.80;
    for (final entity in List<RoadEntity>.from(_entities)) {
      final entityLaneX = entity.lane + entity.drift;
      final laneDistance = (entityLaneX - _playerLaneX).abs();
      final yDistance = (entity.y - playerY).abs();

      final canCollectByTouch = laneDistance < 0.34 && yDistance < 0.075;
      final canCollectByMagnet = _magnetSeconds > 0 && entity.kind == EntityKind.coin && yDistance < 0.18;

      if (entity.isCollectible && (canCollectByTouch || canCollectByMagnet)) {
        _collect(entity);
        continue;
      }

      if (entity.isHazard && laneDistance < 0.35 && yDistance < 0.082) {
        if (_shieldSeconds > 0) {
          entity.collected = true;
          _shieldSeconds = math.max(0.0, _shieldSeconds - 1.4);
          _shake = 0.16;
        } else {
          _crash();
          return;
        }
      }
    }
  }

  void _collect(RoadEntity entity) {
    entity.collected = true;
    switch (entity.kind) {
      case EntityKind.coin:
        _coinsThisRun += _magnetSeconds > 0 ? 2 : 1;
        _score += 45;
        break;
      case EntityKind.shield:
        _shieldSeconds = 7.5;
        _score += 90;
        break;
      case EntityKind.magnet:
        _magnetSeconds = 6.5;
        _score += 70;
        break;
      case EntityKind.nitro:
        _nitroSeconds = 4.5;
        _score += 120;
        break;
      case EntityKind.enemy:
      case EntityKind.cone:
        break;
    }
  }

  void _crash() {
    if (_gameOver) return;
    _gameOver = true;
    _shake = 0.35;
    _saveResult();
    if (mounted) setState(() {});
  }

  Future<void> _saveResult() async {
    if (_saved) return;
    _saved = true;
    final prefs = await SharedPreferences.getInstance();
    final score = _score.round();
    final currentBest = prefs.getInt(StorageKeys.highScore) ?? 0;
    final currentCoins = prefs.getInt(StorageKeys.totalCoins) ?? 0;
    if (score > currentBest) {
      await prefs.setInt(StorageKeys.highScore, score);
      _bestScore = score;
    }
    await prefs.setInt(StorageKeys.totalCoins, currentCoins + _coinsThisRun);
  }

  void _moveLeft() {
    if (_gameOver) return;
    setState(() => _targetLane = math.max(0, _targetLane - 1));
    HapticFeedback.selectionClick();
  }

  void _moveRight() {
    if (_gameOver) return;
    setState(() => _targetLane = math.min(2, _targetLane + 1));
    HapticFeedback.selectionClick();
  }

  void _restart() {
    setState(() {
      _entities.clear();
      _targetLane = 1;
      _playerLaneX = 1;
      _score = 0;
      _coinsThisRun = 0;
      _level = 1;
      _roadOffset = 0;
      _spawnTimer = 0.2;
      _shake = 0;
      _shieldSeconds = 0;
      _magnetSeconds = 0;
      _nitroSeconds = 0;
      _gameOver = false;
      _saved = false;
      _lastTick = null;
    });
    _loadStats();
  }

  @override
  Widget build(BuildContext context) {
    final shakeX = _shake > 0 ? math.sin(_shake * 90) * 5 : 0.0;
    return Scaffold(
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (details) {
          final half = MediaQuery.of(context).size.width / 2;
          if (details.globalPosition.dx < half) {
            _moveLeft();
          } else {
            _moveRight();
          }
        },
        child: Stack(
          children: [
            Transform.translate(
              offset: Offset(shakeX, 0),
              child: CustomPaint(
                painter: RacingPainter(
                  entities: _entities,
                  playerLaneX: _playerLaneX,
                  targetLane: _targetLane,
                  roadOffset: _roadOffset,
                  score: _score,
                  level: _level,
                  shieldSeconds: _shieldSeconds,
                  magnetSeconds: _magnetSeconds,
                  nitroSeconds: _nitroSeconds,
                ),
                child: const SizedBox.expand(),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                child: Column(
                  children: [
                    _GameHud(
                      score: _score.round(),
                      coins: _coinsThisRun,
                      level: _level,
                      best: math.max(_bestScore, _score.round()),
                    ),
                    const Spacer(),
                    if (!_gameOver) _PowerRow(shield: _shieldSeconds, magnet: _magnetSeconds, nitro: _nitroSeconds),
                    const SizedBox(height: 10),
                    if (!_gameOver)
                      Row(
                        children: [
                          _ControlButton(icon: Icons.keyboard_arrow_right_rounded, onPressed: _moveRight),
                          const Spacer(),
                          _ControlButton(icon: Icons.keyboard_arrow_left_rounded, onPressed: _moveLeft),
                        ],
                      ),
                  ],
                ),
              ),
            ),
            if (_gameOver)
              _GameOverOverlay(
                score: _score.round(),
                coins: _coinsThisRun,
                best: math.max(_bestScore, _score.round()),
                totalCoins: _totalCoinsBeforeRun + _coinsThisRun,
                onRestart: _restart,
                onHome: () => Navigator.of(context).pop(),
              ),
          ],
        ),
      ),
    );
  }
}

class _GameHud extends StatelessWidget {
  const _GameHud({required this.score, required this.coins, required this.level, required this.best});

  final int score;
  final int coins;
  final int level;
  final int best;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF071022).withOpacity(0.70),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.20), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: [
          Expanded(child: _HudItem(icon: Icons.speed_rounded, label: 'امتیاز', value: score.toString())),
          Expanded(child: _HudItem(icon: Icons.monetization_on_rounded, label: 'سکه', value: coins.toString())),
          Expanded(child: _HudItem(icon: Icons.local_fire_department_rounded, label: 'مرحله', value: level.toString())),
          Expanded(child: _HudItem(icon: Icons.emoji_events_rounded, label: 'رکورد', value: best.toString())),
        ],
      ),
    );
  }
}

class _HudItem extends StatelessWidget {
  const _HudItem({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: const Color(0xFFFFD166), size: 20),
        const SizedBox(height: 3),
        Text(label, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.54), fontWeight: FontWeight.w700)),
        Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _PowerRow extends StatelessWidget {
  const _PowerRow({required this.shield, required this.magnet, required this.nitro});

  final double shield;
  final double magnet;
  final double nitro;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _PowerChip(icon: Icons.shield_rounded, label: 'سپر', value: shield),
        const SizedBox(width: 8),
        _PowerChip(icon: Icons.blur_on_rounded, label: 'آهنربا', value: magnet),
        const SizedBox(width: 8),
        _PowerChip(icon: Icons.flash_on_rounded, label: 'نیترو', value: nitro),
      ],
    );
  }
}

class _PowerChip extends StatelessWidget {
  const _PowerChip({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    final active = value > 0;
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 180),
      opacity: active ? 1 : 0.28,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.36),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: active ? const Color(0xFF31D8FF).withOpacity(0.55) : Colors.white.withOpacity(0.10)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 17, color: active ? const Color(0xFF31D8FF) : Colors.white54),
            const SizedBox(width: 4),
            Text(active ? '${value.ceil()}ث' : label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}

class _ControlButton extends StatelessWidget {
  const _ControlButton({required this.icon, required this.onPressed});

  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(28),
        child: Ink(
          width: 86,
          height: 64,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            color: Colors.white.withOpacity(0.12),
            border: Border.all(color: Colors.white.withOpacity(0.13)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.22), blurRadius: 18, offset: const Offset(0, 8))],
          ),
          child: Icon(icon, size: 42, color: Colors.white),
        ),
      ),
    );
  }
}

class _GameOverOverlay extends StatelessWidget {
  const _GameOverOverlay({
    required this.score,
    required this.coins,
    required this.best,
    required this.totalCoins,
    required this.onRestart,
    required this.onHome,
  });

  final int score;
  final int coins;
  final int best;
  final int totalCoins;
  final VoidCallback onRestart;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.52),
      child: Center(
        child: Container(
          width: double.infinity,
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(32),
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFF182B66), Color(0xFF0D1230)],
            ),
            border: Border.all(color: Colors.white.withOpacity(0.14)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40), blurRadius: 30, offset: const Offset(0, 16))],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFFF4D6D).withOpacity(0.14),
                  border: Border.all(color: const Color(0xFFFF4D6D).withOpacity(0.45)),
                ),
                child: const Icon(Icons.car_crash_rounded, color: Color(0xFFFF4D6D), size: 38),
              ),
              const SizedBox(height: 16),
              const Text('بازی تمام شد', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('رکورد بعدی نزدیکه؛ دوباره امتحان کن.', style: TextStyle(color: Colors.white.withOpacity(0.62))),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(child: _ResultBox(label: 'امتیاز', value: score.toString(), icon: Icons.speed_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: _ResultBox(label: 'سکه این دست', value: coins.toString(), icon: Icons.monetization_on_rounded)),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _ResultBox(label: 'رکورد', value: best.toString(), icon: Icons.emoji_events_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: _ResultBox(label: 'کل سکه', value: totalCoins.toString(), icon: Icons.account_balance_wallet_rounded)),
                ],
              ),
              const SizedBox(height: 22),
              _PrimaryButton(title: 'دوباره بازی کن', icon: Icons.replay_rounded, onPressed: onRestart),
              const SizedBox(height: 10),
              _GhostButton(title: 'برگشت به خانه', icon: Icons.home_rounded, onPressed: onHome),
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultBox extends StatelessWidget {
  const _ResultBox({required this.label, required this.value, required this.icon});

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFFFD166)),
          const SizedBox(height: 6),
          Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.56), fontWeight: FontWeight.w700)),
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class RacingPainter extends CustomPainter {
  RacingPainter({
    required this.entities,
    required this.playerLaneX,
    required this.targetLane,
    required this.roadOffset,
    required this.score,
    required this.level,
    required this.shieldSeconds,
    required this.magnetSeconds,
    required this.nitroSeconds,
  });

  final List<RoadEntity> entities;
  final double playerLaneX;
  final int targetLane;
  final double roadOffset;
  final double score;
  final int level;
  final double shieldSeconds;
  final double magnetSeconds;
  final double nitroSeconds;

  @override
  void paint(Canvas canvas, Size size) {
    _drawWorld(canvas, size);
    _drawRoad(canvas, size);
    _drawEntities(canvas, size);
    _drawPlayer(canvas, size);
    _drawSpeedGlow(canvas, size);
  }

  void _drawWorld(Canvas canvas, Size size) {
    final backgroundPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF102C68), Color(0xFF070A18)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, backgroundPaint);

    final starPaint = Paint()..color = Colors.white.withOpacity(0.13);
    for (var i = 0; i < 26; i++) {
      final x = ((i * 73 + 19) % size.width.toInt()).toDouble();
      final y = ((i * 131 + roadOffset * 0.18) % size.height.toInt()).toDouble();
      canvas.drawCircle(Offset(x, y), 1.1 + (i % 3) * 0.35, starPaint);
    }

    final sidePaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [const Color(0xFF101B3D), const Color(0xFF07101F).withOpacity(0.96)],
      ).createShader(Offset.zero & size);
    final roadWidth = size.width * 0.74;
    final left = (size.width - roadWidth) / 2;
    canvas.drawRect(Rect.fromLTWH(0, 0, left, size.height), sidePaint);
    canvas.drawRect(Rect.fromLTWH(left + roadWidth, 0, left, size.height), sidePaint);

    final lightPaint = Paint()..color = const Color(0xFF31D8FF).withOpacity(0.10);
    for (var y = -80.0 + roadOffset; y < size.height + 80; y += 125) {
      canvas.drawCircle(Offset(left * 0.50, y), 12, lightPaint);
      canvas.drawCircle(Offset(size.width - left * 0.50, y + 58), 12, lightPaint);
    }
  }

  void _drawRoad(Canvas canvas, Size size) {
    final roadWidth = size.width * 0.74;
    final left = (size.width - roadWidth) / 2;
    final roadRect = Rect.fromLTWH(left, -10, roadWidth, size.height + 20);

    final roadPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF262F46), Color(0xFF151925)],
      ).createShader(roadRect);
    canvas.drawRRect(RRect.fromRectAndRadius(roadRect, const Radius.circular(26)), roadPaint);

    final edgePaint = Paint()
      ..color = const Color(0xFF31D8FF).withOpacity(0.42)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(left + 4, 0), Offset(left + 4, size.height), edgePaint);
    canvas.drawLine(Offset(left + roadWidth - 4, 0), Offset(left + roadWidth - 4, size.height), edgePaint);

    final lanePaint = Paint()
      ..color = Colors.white.withOpacity(0.52)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    final laneA = left + roadWidth / 3;
    final laneB = left + roadWidth * 2 / 3;
    for (final x in [laneA, laneB]) {
      for (var y = -96.0 + roadOffset; y < size.height + 96; y += 96) {
        canvas.drawLine(Offset(x, y), Offset(x, y + 48), lanePaint);
      }
    }

    final centerGlow = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFF31D8FF).withOpacity(0.12), Colors.transparent],
      ).createShader(Rect.fromCircle(center: Offset(size.width / 2, size.height * 0.54), radius: roadWidth * 0.65));
    canvas.drawRect(roadRect, centerGlow);
  }

  void _drawEntities(Canvas canvas, Size size) {
    for (final entity in entities) {
      final lanePoint = _laneCenter(size, entity.lane + entity.drift, entity.y);
      switch (entity.kind) {
        case EntityKind.enemy:
          _drawEnemyCar(canvas, lanePoint, size, entity.seed);
          break;
        case EntityKind.cone:
          _drawCone(canvas, lanePoint, size);
          break;
        case EntityKind.coin:
          _drawCoin(canvas, lanePoint, size, entity.seed);
          break;
        case EntityKind.shield:
          _drawPower(canvas, lanePoint, Icons.shield_rounded, const Color(0xFF31D8FF));
          break;
        case EntityKind.magnet:
          _drawPower(canvas, lanePoint, Icons.blur_on_rounded, const Color(0xFFFF4D6D));
          break;
        case EntityKind.nitro:
          _drawPower(canvas, lanePoint, Icons.flash_on_rounded, const Color(0xFFFFD166));
          break;
      }
    }
  }

  Offset _laneCenter(Size size, double lane, double normalizedY) {
    final roadWidth = size.width * 0.74;
    final left = (size.width - roadWidth) / 2;
    final laneWidth = roadWidth / 3;
    return Offset(left + laneWidth * (lane + 0.5), normalizedY * size.height);
  }

  void _drawPlayer(Canvas canvas, Size size) {
    final center = _laneCenter(size, playerLaneX, 0.80);
    if (shieldSeconds > 0) {
      final shieldPaint = Paint()
        ..shader = RadialGradient(
          colors: [const Color(0xFF31D8FF).withOpacity(0.22), const Color(0xFF31D8FF).withOpacity(0.03)],
        ).createShader(Rect.fromCircle(center: center, radius: 58));
      canvas.drawCircle(center, 58, shieldPaint);
      canvas.drawCircle(center, 58, Paint()..color = const Color(0xFF31D8FF).withOpacity(0.42)..style = PaintingStyle.stroke..strokeWidth = 2);
    }

    if (magnetSeconds > 0) {
      canvas.drawCircle(
        center,
        74,
        Paint()
          ..color = const Color(0xFFFF4D6D).withOpacity(0.12)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3,
      );
    }

    _drawCarBody(
      canvas,
      center,
      bodyColor: const Color(0xFF31D8FF),
      accentColor: const Color(0xFFFFD166),
      scale: 1.10,
      isPlayer: true,
    );
  }

  void _drawSpeedGlow(Canvas canvas, Size size) {
    if (nitroSeconds <= 0) return;
    final center = _laneCenter(size, playerLaneX, 0.85);
    final flamePaint = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFFFFD166).withOpacity(0.28), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: 96));
    canvas.drawCircle(center, 96, flamePaint);
  }

  void _drawEnemyCar(Canvas canvas, Offset center, Size size, double seed) {
    final colors = [
      const Color(0xFFFF4D6D),
      const Color(0xFF6C63FF),
      const Color(0xFFFF9F1C),
      const Color(0xFFB8F35A),
    ];
    final index = math.min(colors.length - 1, math.max(0, (seed * colors.length).floor()));
    _drawCarBody(canvas, center, bodyColor: colors[index], accentColor: Colors.white, scale: 0.96, isPlayer: false);
  }

  void _drawCarBody(
    Canvas canvas,
    Offset center, {
    required Color bodyColor,
    required Color accentColor,
    required double scale,
    required bool isPlayer,
  }) {
    final width = 48.0 * scale;
    final height = 78.0 * scale;
    final rect = Rect.fromCenter(center: center, width: width, height: height);

    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.34)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawRRect(RRect.fromRectAndRadius(rect.shift(const Offset(0, 8)), Radius.circular(17 * scale)), shadow);

    final bodyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color.lerp(bodyColor, Colors.white, 0.18)!, bodyColor, Color.lerp(bodyColor, Colors.black, 0.22)!],
      ).createShader(rect);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, Radius.circular(16 * scale)), bodyPaint);

    final roof = Rect.fromCenter(center: center.translate(0, -12 * scale), width: width * 0.58, height: height * 0.34);
    canvas.drawRRect(
      RRect.fromRectAndRadius(roof, Radius.circular(9 * scale)),
      Paint()..color = const Color(0xFF071022).withOpacity(0.82),
    );

    final stripePaint = Paint()..color = accentColor.withOpacity(isPlayer ? 0.90 : 0.65);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: center.translate(0, 12 * scale), width: width * 0.14, height: height * 0.55),
        Radius.circular(4 * scale),
      ),
      stripePaint,
    );

    final wheelPaint = Paint()..color = const Color(0xFF05070F);
    for (final dx in [-width * 0.52, width * 0.52]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: center.translate(dx, -height * 0.22), width: 9 * scale, height: 22 * scale), Radius.circular(4 * scale)),
        wheelPaint,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: center.translate(dx, height * 0.24), width: 9 * scale, height: 22 * scale), Radius.circular(4 * scale)),
        wheelPaint,
      );
    }

    final lightPaint = Paint()..color = isPlayer ? const Color(0xFFFFF3B0) : const Color(0xFFFF4D6D);
    canvas.drawCircle(center.translate(-width * 0.24, -height * 0.44), 4 * scale, lightPaint);
    canvas.drawCircle(center.translate(width * 0.24, -height * 0.44), 4 * scale, lightPaint);
  }

  void _drawCone(Canvas canvas, Offset center, Size size) {
    final path = Path()
      ..moveTo(center.dx, center.dy - 30)
      ..lineTo(center.dx - 22, center.dy + 26)
      ..lineTo(center.dx + 22, center.dy + 26)
      ..close();
    canvas.drawShadow(path, Colors.black, 8, true);
    canvas.drawPath(path, Paint()..color = const Color(0xFFFF9F1C));
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: center.translate(0, 8), width: 34, height: 7), const Radius.circular(4)),
      Paint()..color = Colors.white.withOpacity(0.85),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: center.translate(0, 26), width: 48, height: 9), const Radius.circular(5)),
      Paint()..color = const Color(0xFF33210A),
    );
  }

  void _drawCoin(Canvas canvas, Offset center, Size size, double seed) {
    final pulse = 1 + math.sin((score * 0.035) + seed * 10) * 0.07;
    final radius = 15.0 * pulse;
    final rect = Rect.fromCircle(center: center, radius: radius);
    canvas.drawCircle(center.translate(0, 4), radius, Paint()..color = Colors.black.withOpacity(0.18));
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..shader = const LinearGradient(colors: [Color(0xFFFFE66D), Color(0xFFFF9F1C)]).createShader(rect),
    );
    canvas.drawCircle(center, radius * 0.62, Paint()..color = Colors.white.withOpacity(0.20)..style = PaintingStyle.stroke..strokeWidth = 3);
    final textPainter = TextPainter(
      text: const TextSpan(text: '₵', style: TextStyle(color: Color(0xFF5E3B00), fontSize: 17, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(canvas, center - Offset(textPainter.width / 2, textPainter.height / 2));
  }

  void _drawPower(Canvas canvas, Offset center, IconData icon, Color color) {
    final rect = Rect.fromCircle(center: center, radius: 24);
    canvas.drawCircle(center.translate(0, 5), 24, Paint()..color = Colors.black.withOpacity(0.20));
    canvas.drawCircle(
      center,
      24,
      Paint()
        ..shader = LinearGradient(colors: [Color.lerp(color, Colors.white, 0.20)!, color]).createShader(rect),
    );
    canvas.drawCircle(center, 30, Paint()..color = color.withOpacity(0.20)..style = PaintingStyle.stroke..strokeWidth = 3);

    final textPainter = TextPainter(
      text: TextSpan(text: String.fromCharCode(icon.codePoint), style: TextStyle(fontFamily: icon.fontFamily, package: icon.fontPackage, color: Colors.white, fontSize: 26)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(canvas, center - Offset(textPainter.width / 2, textPainter.height / 2));
  }

  @override
  bool shouldRepaint(covariant RacingPainter oldDelegate) => true;
}

class _HeroCarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final roadRect = Rect.fromCenter(center: Offset(size.width / 2, size.height / 2), width: size.width * 0.56, height: size.height);
    canvas.drawRRect(
      RRect.fromRectAndRadius(roadRect, const Radius.circular(26)),
      Paint()
        ..shader = const LinearGradient(colors: [Color(0xFF303A57), Color(0xFF161B2C)], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(roadRect),
    );
    final lanePaint = Paint()..color = Colors.white.withOpacity(0.45)..strokeWidth = 4..strokeCap = StrokeCap.round;
    for (var y = -10.0; y < size.height + 30; y += 44) {
      canvas.drawLine(Offset(size.width / 2, y), Offset(size.width / 2, y + 20), lanePaint);
    }
    final carCenter = Offset(size.width / 2, size.height * 0.58);
    RacingPainter(
      entities: const [],
      playerLaneX: 1,
      targetLane: 1,
      roadOffset: 0,
      score: 0,
      level: 1,
      shieldSeconds: 0,
      magnetSeconds: 0,
      nitroSeconds: 0,
    )._drawCarBody(canvas, carCenter, bodyColor: const Color(0xFF31D8FF), accentColor: const Color(0xFFFFD166), scale: 1.2, isPlayer: true);
    final glow = Paint()
      ..shader = ui.Gradient.radial(carCenter, 86, [const Color(0xFF31D8FF).withOpacity(0.18), Colors.transparent]);
    canvas.drawCircle(carCenter, 86, glow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

enum EntityKind { enemy, cone, coin, shield, magnet, nitro }

class RoadEntity {
  RoadEntity({
    required this.kind,
    required this.lane,
    required this.y,
    required this.seed,
    this.speedMultiplier = 1.0,
    this.driftDirection = 1,
  });

  final EntityKind kind;
  final int lane;
  double y;
  final double seed;
  double speedMultiplier;
  double drift = 0;
  int driftDirection;
  bool collected = false;

  bool get isHazard => kind == EntityKind.enemy || kind == EntityKind.cone;
  bool get isCollectible => kind == EntityKind.coin || kind == EntityKind.shield || kind == EntityKind.magnet || kind == EntityKind.nitro;
}

class StorageKeys {
  static const highScore = 'vertical_racer_high_score';
  static const totalCoins = 'vertical_racer_total_coins';
}
