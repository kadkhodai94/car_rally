# جاده بی‌پایان - Vertical Racer

یک بازی ماشینی عمودی ساده، روان و جذاب با Flutter.

## امکانات نسخه ۱

- کنترل ماشین با لمس چپ و راست صفحه
- جابه‌جایی نرم ماشین بین ۳ لاین
- جاده متحرک با حس سرعت
- ماشین‌های حریف و مانع‌های جاده‌ای
- جمع‌آوری سکه
- آیتم‌های سپر، آهنربا و نیترو
- افزایش سختی بر اساس امتیاز
- نمایش مرحله، امتیاز، رکورد و سکه
- ذخیره رکورد و سکه روی گوشی
- صفحه شروع، صفحه بازی و صفحه پایان بازی
- آیکون اختصاصی اندروید
- GitHub Actions برای ساخت APK و AAB

## اجرا در سیستم شخصی

```bash
flutter pub get
flutter run
```

## ساخت خروجی اندروید

```bash
flutter build apk --release --build-name=1.0.0 --build-number=1
flutter build appbundle --release --build-name=1.0.0 --build-number=1
```

## ساخت با GitHub Actions

فایل workflow در مسیر زیر قرار دارد:

```text
.github/workflows/build.yml
```

بعد از آپلود پروژه در GitHub، از تب Actions می‌توانی workflow را اجرا کنی. خروجی‌ها به‌صورت artifact شامل APK و AAB قرار می‌گیرند.

## نکته

این نسخه WebView نیست. بازی با Flutter و CustomPaint پیاده‌سازی شده و برای شروع انتشار سبک و قابل توسعه است.
