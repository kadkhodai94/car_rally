# Changelog

## v1.1.0+2 - CI Fixed

- بازسازی workflow خروجی Godot برای GitHub Actions
- اضافه شدن تشخیص آخرین ZIP نسخه‌دار
- بازنویسی خودکار export_presets.cfg در CI
- تنظیم نام Android به انگلیسی برای جلوگیری از خطای CI
- تنظیم renderer روی gl_compatibility
- ساخت debug keystore داخل CI
- نصب Android SDK packages لازم برای Godot 4.3
- تلاش اول خروجی Android مستقیم
- تلاش دوم fallback با Android Gradle Build Template
- آپلود لاگ‌های Godot به Artifacts برای عیب‌یابی دقیق

## v1.0.0+1

- ساخت نسخه اولیه بازی ماشینی رکوردی با Godot
- کنترل لمسی چپ/راست
- جاده بی‌پایان، مانع، امتیاز، رکورد، سکه و فروشگاه ماشین
