extends Control

const SAVE_PATH := "user://jade_bipayan_save.cfg"
const LANES := 3
const CAR_PRICES := [0, 150, 320, 600]
const CAR_NAMES := ["نارنجی", "آبی", "سبز", "طلایی"]
const CAR_COLORS := [Color(1.0, 0.42, 0.08), Color(0.15, 0.55, 1.0), Color(0.1, 0.85, 0.45), Color(1.0, 0.82, 0.18)]

var rng := RandomNumberGenerator.new()
var font: Font
var state := "menu"
var buttons: Array = []

var high_score := 0
var wallet := 0
var selected_car := 0
var owned_cars := [true, false, false, false]

var score := 0.0
var run_coins := 0
var speed := 420.0
var road_offset := 0.0
var player_lane := 1
var player_x := 0.0
var spawn_timer := 0.0
var coin_timer := 0.0
var flash_timer := 0.0
var last_reward_paid := false
var obstacles: Array = []
var coins: Array = []

func _ready() -> void:
	rng.randomize()
	font = get_theme_default_font()
	load_save()
	set_process(true)
	queue_redraw()

func _process(delta: float) -> void:
	if state == "play":
		update_game(delta)
	elif state == "menu":
		road_offset = fmod(road_offset + 190.0 * delta, 160.0)
		queue_redraw()
	elif state == "gameover" and flash_timer > 0.0:
		flash_timer -= delta
		queue_redraw()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		queue_redraw()

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("move_left"):
		move_left()
	elif event.is_action_pressed("move_right"):
		move_right()
	elif event is InputEventScreenTouch and event.pressed:
		handle_press(event.position)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		handle_press(event.position)

func handle_press(pos: Vector2) -> void:
	for b in buttons:
		if b["rect"].has_point(pos):
			handle_button(str(b["id"]))
			return
	if state == "play":
		if pos.x < get_size().x * 0.5:
			move_left()
		else:
			move_right()

func handle_button(id: String) -> void:
	match id:
		"start":
			start_game()
		"shop":
			state = "shop"
			queue_redraw()
		"records":
			state = "records"
			queue_redraw()
		"menu":
			state = "menu"
			queue_redraw()
		"retry":
			start_game()
		"left":
			move_left()
		"right":
			move_right()
		_:
			if id.begins_with("car_"):
				var idx := int(id.replace("car_", ""))
				buy_or_select_car(idx)

func start_game() -> void:
	state = "play"
	score = 0.0
	run_coins = 0
	speed = 420.0
	road_offset = 0.0
	player_lane = 1
	player_x = lane_x(player_lane)
	spawn_timer = 0.3
	coin_timer = 1.2
	flash_timer = 0.0
	last_reward_paid = false
	obstacles.clear()
	coins.clear()
	queue_redraw()

func update_game(delta: float) -> void:
	speed = min(980.0, 420.0 + score * 0.13)
	score += delta * (40.0 + speed * 0.08)
	road_offset = fmod(road_offset + speed * delta, 160.0)
	player_x = lerp(player_x, lane_x(player_lane), min(1.0, delta * 12.0))

	spawn_timer -= delta
	coin_timer -= delta
	if spawn_timer <= 0.0:
		spawn_obstacle()
		var target_interval := max(0.42, 1.08 - score / 9000.0)
		spawn_timer = rng.randf_range(target_interval * 0.7, target_interval * 1.15)
	if coin_timer <= 0.0:
		spawn_coin()
		coin_timer = rng.randf_range(0.85, 1.65)

	for o in obstacles:
		o["y"] = float(o["y"]) + speed * delta
	for c in coins:
		c["y"] = float(c["y"]) + speed * delta * 0.96

	var screen_h := get_size().y
	obstacles = obstacles.filter(func(o): return o["y"] < screen_h + 180.0)
	coins = coins.filter(func(c): return c["y"] < screen_h + 140.0 and not c.get("taken", false))

	var player_rect := get_player_rect()
	for o in obstacles:
		if player_rect.intersects(get_enemy_rect(o)):
			game_over()
			return
	for c in coins:
		if player_rect.intersects(get_coin_rect(c)):
			c["taken"] = true
			run_coins += 1
			score += 45.0
	queue_redraw()

func game_over() -> void:
	if last_reward_paid:
		return
	last_reward_paid = true
	state = "gameover"
	var final_score := int(score)
	var reward := int(score / 850.0) + run_coins
	wallet += reward
	if final_score > high_score:
		high_score = final_score
		flash_timer = 1.3
	save_game()
	queue_redraw()

func move_left() -> void:
	if state == "play":
		player_lane = max(0, player_lane - 1)

func move_right() -> void:
	if state == "play":
		player_lane = min(LANES - 1, player_lane + 1)

func spawn_obstacle() -> void:
	var lane := rng.randi_range(0, LANES - 1)
	if obstacles.size() > 0 and rng.randf() < 0.28:
		lane = (int(obstacles[obstacles.size() - 1]["lane"]) + rng.randi_range(1, 2)) % LANES
	obstacles.append({"lane": lane, "y": -120.0, "color": Color(0.95, 0.14, 0.22), "type": rng.randi_range(0, 2)})
	if score > 1800.0 and rng.randf() < min(0.42, score / 13000.0):
		var lane2 := (lane + rng.randi_range(1, 2)) % LANES
		obstacles.append({"lane": lane2, "y": -260.0, "color": Color(0.5, 0.12, 0.95), "type": rng.randi_range(0, 2)})

func spawn_coin() -> void:
	coins.append({"lane": rng.randi_range(0, LANES - 1), "y": -90.0, "taken": false})

func road_rect() -> Rect2:
	var s := get_size()
	return Rect2(s.x * 0.13, -20.0, s.x * 0.74, s.y + 40.0)

func lane_x(lane: int) -> float:
	var r := road_rect()
	var lane_w := r.size.x / float(LANES)
	return r.position.x + lane_w * (float(lane) + 0.5)

func car_size() -> Vector2:
	var r := road_rect()
	var lane_w := r.size.x / float(LANES)
	return Vector2(lane_w * 0.48, min(get_size().y * 0.105, lane_w * 0.86))

func get_player_rect() -> Rect2:
	var cs := car_size()
	var center := Vector2(player_x, get_size().y * 0.78)
	return Rect2(center - cs * 0.5, cs)

func get_enemy_rect(o: Dictionary) -> Rect2:
	var cs := car_size()
	var center := Vector2(lane_x(int(o["lane"])), float(o["y"]))
	return Rect2(center - cs * 0.5, cs)

func get_coin_rect(c: Dictionary) -> Rect2:
	var r := road_rect()
	var lane_w := r.size.x / float(LANES)
	var size_coin := min(42.0, lane_w * 0.26)
	var center := Vector2(lane_x(int(c["lane"])), float(c["y"]))
	return Rect2(center - Vector2(size_coin, size_coin) * 0.5, Vector2(size_coin, size_coin))

func buy_or_select_car(idx: int) -> void:
	if idx < 0 or idx >= CAR_PRICES.size():
		return
	if owned_cars[idx]:
		selected_car = idx
		save_game()
		queue_redraw()
		return
	var price := CAR_PRICES[idx]
	if wallet >= price:
		wallet -= price
		owned_cars[idx] = true
		selected_car = idx
		save_game()
	queue_redraw()

func load_save() -> void:
	var cfg := ConfigFile.new()
	var err := cfg.load(SAVE_PATH)
	if err == OK:
		high_score = int(cfg.get_value("game", "high_score", 0))
		wallet = int(cfg.get_value("game", "wallet", 0))
		selected_car = int(cfg.get_value("game", "selected_car", 0))
		for i in range(owned_cars.size()):
			owned_cars[i] = bool(cfg.get_value("cars", "owned_%d" % i, i == 0))
	owned_cars[0] = true
	selected_car = clamp(selected_car, 0, owned_cars.size() - 1)

func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "high_score", high_score)
	cfg.set_value("game", "wallet", wallet)
	cfg.set_value("game", "selected_car", selected_car)
	for i in range(owned_cars.size()):
		cfg.set_value("cars", "owned_%d" % i, owned_cars[i])
	cfg.save(SAVE_PATH)

func _draw() -> void:
	buttons.clear()
	draw_background()
	match state:
		"menu":
			draw_menu()
		"play":
			draw_gameplay()
		"gameover":
			draw_gameplay()
			draw_gameover()
		"shop":
			draw_shop()
		"records":
			draw_records()

func draw_background() -> void:
	var s := get_size()
	for i in range(18):
		var t := float(i) / 17.0
		var col := Color(0.02 + t * 0.02, 0.04 + t * 0.04, 0.09 + t * 0.09)
		draw_rect(Rect2(0, s.y * t, s.x, s.y / 17.0 + 2.0), col)
	draw_road()

func draw_road() -> void:
	var s := get_size()
	var r := road_rect()
	draw_rect(Rect2(0, 0, r.position.x, s.y), Color(0.03, 0.11, 0.09))
	draw_rect(Rect2(r.position.x + r.size.x, 0, s.x - r.position.x - r.size.x, s.y), Color(0.03, 0.11, 0.09))
	draw_rect(r, Color(0.09, 0.10, 0.13))
	draw_rect(Rect2(r.position.x - 6.0, 0, 6.0, s.y), Color(0.95, 0.85, 0.2))
	draw_rect(Rect2(r.position.x + r.size.x, 0, 6.0, s.y), Color(0.95, 0.85, 0.2))
	var lane_w := r.size.x / float(LANES)
	for lane in range(1, LANES):
		var x := r.position.x + lane_w * lane
		var y := -160.0 + road_offset
		while y < s.y + 160.0:
			draw_round_rect(Rect2(x - 5.0, y, 10.0, 82.0), Color(0.86, 0.88, 0.93, 0.82), 5.0)
			y += 160.0

func draw_gameplay() -> void:
	for c in coins:
		draw_coin(Vector2(lane_x(int(c["lane"])), float(c["y"])))
	for o in obstacles:
		draw_car(get_enemy_rect(o), Color(o["color"]), false)
	draw_car(get_player_rect(), CAR_COLORS[selected_car], true)
	draw_hud()
	draw_controls()

func draw_hud() -> void:
	var s := get_size()
	var top := Rect2(22.0, 24.0, s.x - 44.0, 86.0)
	draw_round_rect(top, Color(0.02, 0.03, 0.07, 0.72), 24.0)
	draw_string_center("امتیاز: %d" % int(score), Rect2(top.position.x + 16.0, top.position.y + 12.0, top.size.x * 0.45, 36.0), 28, Color.WHITE)
	draw_string_center("سکه: %d" % wallet, Rect2(top.position.x + top.size.x * 0.48, top.position.y + 12.0, top.size.x * 0.25, 36.0), 26, Color(1.0, 0.86, 0.20))
	draw_string_center("رکورد: %d" % high_score, Rect2(top.position.x + top.size.x * 0.72, top.position.y + 12.0, top.size.x * 0.26, 36.0), 24, Color(0.7, 0.85, 1.0))

func draw_controls() -> void:
	var s := get_size()
	var y := s.y - 132.0
	add_button("left", "‹", Rect2(34.0, y, 110.0, 92.0), Color(0.12, 0.18, 0.33, 0.72), 56)
	add_button("right", "›", Rect2(s.x - 144.0, y, 110.0, 92.0), Color(0.12, 0.18, 0.33, 0.72), 56)

func draw_menu() -> void:
	var s := get_size()
	var card := Rect2(s.x * 0.08, s.y * 0.16, s.x * 0.84, s.y * 0.55)
	draw_panel(card, Color(0.02, 0.05, 0.12, 0.84))
	draw_string_center("جاده بی‌پایان", Rect2(card.position.x, card.position.y + 34.0, card.size.x, 64.0), 46, Color.WHITE)
	draw_string_center("بازی ماشینی رکوردی", Rect2(card.position.x, card.position.y + 102.0, card.size.x, 38.0), 25, Color(0.75, 0.86, 1.0))
	draw_string_center("رکورد شما: %d" % high_score, Rect2(card.position.x, card.position.y + 158.0, card.size.x, 40.0), 27, Color(1.0, 0.85, 0.22))
	draw_string_center("سکه‌ها: %d" % wallet, Rect2(card.position.x, card.position.y + 202.0, card.size.x, 36.0), 25, Color(0.83, 1.0, 0.76))
	var btn_w := card.size.x * 0.72
	var x := card.position.x + (card.size.x - btn_w) * 0.5
	add_button("start", "شروع بازی", Rect2(x, card.position.y + 282.0, btn_w, 72.0), Color(0.12, 0.48, 1.0), 28)
	add_button("shop", "فروشگاه ماشین", Rect2(x, card.position.y + 370.0, btn_w, 70.0), Color(0.12, 0.72, 0.42), 26)
	add_button("records", "رکوردها", Rect2(x, card.position.y + 454.0, btn_w, 64.0), Color(0.18, 0.20, 0.38), 24)
	var preview := get_player_rect()
	preview.position = Vector2(s.x * 0.5 - car_size().x * 0.5, s.y * 0.77)
	draw_car(preview, CAR_COLORS[selected_car], true)

func draw_gameover() -> void:
	var s := get_size()
	var overlay := Rect2(0, 0, s.x, s.y)
	draw_rect(overlay, Color(0.0, 0.0, 0.0, 0.54))
	var card := Rect2(s.x * 0.08, s.y * 0.25, s.x * 0.84, s.y * 0.44)
	draw_panel(card, Color(0.03, 0.04, 0.09, 0.94))
	var title := "پایان بازی"
	if int(score) >= high_score and flash_timer > 0.0:
		title = "رکورد جدید!"
	draw_string_center(title, Rect2(card.position.x, card.position.y + 34.0, card.size.x, 56.0), 42, Color.WHITE)
	draw_string_center("امتیاز: %d" % int(score), Rect2(card.position.x, card.position.y + 116.0, card.size.x, 42.0), 30, Color(0.75, 0.88, 1.0))
	draw_string_center("رکورد: %d" % high_score, Rect2(card.position.x, card.position.y + 166.0, card.size.x, 38.0), 27, Color(1.0, 0.84, 0.24))
	draw_string_center("سکه‌های این دست: %d" % (int(score / 850.0) + run_coins), Rect2(card.position.x, card.position.y + 214.0, card.size.x, 36.0), 25, Color(0.7, 1.0, 0.7))
	var btn_w := card.size.x * 0.68
	var x := card.position.x + (card.size.x - btn_w) * 0.5
	add_button("retry", "دوباره بازی کن", Rect2(x, card.position.y + 286.0, btn_w, 68.0), Color(0.12, 0.48, 1.0), 26)
	add_button("menu", "منوی اصلی", Rect2(x, card.position.y + 368.0, btn_w, 62.0), Color(0.18, 0.20, 0.38), 23)

func draw_shop() -> void:
	var s := get_size()
	var card := Rect2(s.x * 0.06, s.y * 0.08, s.x * 0.88, s.y * 0.82)
	draw_panel(card, Color(0.02, 0.04, 0.10, 0.9))
	draw_string_center("فروشگاه ماشین", Rect2(card.position.x, card.position.y + 26.0, card.size.x, 54.0), 40, Color.WHITE)
	draw_string_center("سکه شما: %d" % wallet, Rect2(card.position.x, card.position.y + 82.0, card.size.x, 38.0), 25, Color(1.0, 0.85, 0.22))
	var item_h := 118.0
	var top := card.position.y + 145.0
	for i in range(CAR_PRICES.size()):
		var item := Rect2(card.position.x + 28.0, top + i * (item_h + 18.0), card.size.x - 56.0, item_h)
		var bg := Color(0.08, 0.11, 0.20, 0.92)
		if i == selected_car:
			bg = Color(0.10, 0.32, 0.30, 0.95)
		draw_round_rect(item, bg, 24.0)
		var car_r := Rect2(item.position.x + 26.0, item.position.y + 20.0, 64.0, 78.0)
		draw_car(car_r, CAR_COLORS[i], true)
		draw_string_center("ماشین %s" % CAR_NAMES[i], Rect2(item.position.x + 102.0, item.position.y + 18.0, item.size.x * 0.38, 36.0), 24, Color.WHITE)
		var status := "انتخاب شده"
		if not owned_cars[i]:
			status = "%d سکه" % CAR_PRICES[i]
		elif i != selected_car:
			status = "انتخاب"
		add_button("car_%d" % i, status, Rect2(item.position.x + item.size.x - 154.0, item.position.y + 30.0, 128.0, 58.0), Color(0.12, 0.48, 1.0) if owned_cars[i] else Color(0.88, 0.50, 0.12), 21)
	add_button("menu", "بازگشت", Rect2(card.position.x + 42.0, card.position.y + card.size.y - 86.0, card.size.x - 84.0, 60.0), Color(0.18, 0.20, 0.38), 23)

func draw_records() -> void:
	var s := get_size()
	var card := Rect2(s.x * 0.08, s.y * 0.22, s.x * 0.84, s.y * 0.48)
	draw_panel(card, Color(0.02, 0.04, 0.10, 0.92))
	draw_string_center("رکوردها", Rect2(card.position.x, card.position.y + 36.0, card.size.x, 58.0), 42, Color.WHITE)
	draw_string_center("بهترین رکورد فعلی", Rect2(card.position.x, card.position.y + 124.0, card.size.x, 34.0), 24, Color(0.75, 0.85, 1.0))
	draw_string_center("%d" % high_score, Rect2(card.position.x, card.position.y + 164.0, card.size.x, 72.0), 56, Color(1.0, 0.84, 0.22))
	draw_string_center("نسخه ۱ رکورد را داخل گوشی ذخیره می‌کند.", Rect2(card.position.x + 24.0, card.position.y + 262.0, card.size.x - 48.0, 40.0), 22, Color(0.78, 0.86, 0.95))
	draw_string_center("نسخه بعدی می‌تواند لیدربورد آنلاین داشته باشد.", Rect2(card.position.x + 24.0, card.position.y + 304.0, card.size.x - 48.0, 40.0), 21, Color(0.78, 0.86, 0.95))
	add_button("menu", "بازگشت", Rect2(card.position.x + card.size.x * 0.16, card.position.y + card.size.y - 92.0, card.size.x * 0.68, 62.0), Color(0.18, 0.20, 0.38), 23)

func draw_coin(center: Vector2) -> void:
	draw_circle(center + Vector2(0, 5), 23.0, Color(0.0, 0.0, 0.0, 0.22))
	draw_circle(center, 21.0, Color(1.0, 0.76, 0.12))
	draw_circle(center, 13.0, Color(1.0, 0.92, 0.32))
	draw_string_center("¢", Rect2(center.x - 18.0, center.y - 18.0, 36.0, 36.0), 21, Color(0.45, 0.27, 0.02))

func draw_car(rect: Rect2, color: Color, player: bool) -> void:
	var shadow := Rect2(rect.position.x + 4.0, rect.position.y + 8.0, rect.size.x, rect.size.y)
	draw_round_rect(shadow, Color(0.0, 0.0, 0.0, 0.28), 18.0)
	draw_round_rect(rect, color, 18.0)
	var cabin := Rect2(rect.position.x + rect.size.x * 0.18, rect.position.y + rect.size.y * 0.18, rect.size.x * 0.64, rect.size.y * 0.28)
	draw_round_rect(cabin, Color(0.04, 0.08, 0.16, 0.88), 10.0)
	var nose := PackedVector2Array([
		Vector2(rect.position.x + rect.size.x * 0.18, rect.position.y + rect.size.y * 0.50),
		Vector2(rect.position.x + rect.size.x * 0.82, rect.position.y + rect.size.y * 0.50),
		Vector2(rect.position.x + rect.size.x * 0.66, rect.position.y + rect.size.y * 0.82),
		Vector2(rect.position.x + rect.size.x * 0.34, rect.position.y + rect.size.y * 0.82)
	])
	draw_colored_polygon(nose, Color(1.0, 1.0, 1.0, 0.16))
	draw_round_rect(Rect2(rect.position.x - 6.0, rect.position.y + rect.size.y * 0.22, 9.0, rect.size.y * 0.24), Color(0.02, 0.02, 0.03), 4.0)
	draw_round_rect(Rect2(rect.position.x + rect.size.x - 3.0, rect.position.y + rect.size.y * 0.22, 9.0, rect.size.y * 0.24), Color(0.02, 0.02, 0.03), 4.0)
	draw_round_rect(Rect2(rect.position.x - 6.0, rect.position.y + rect.size.y * 0.62, 9.0, rect.size.y * 0.24), Color(0.02, 0.02, 0.03), 4.0)
	draw_round_rect(Rect2(rect.position.x + rect.size.x - 3.0, rect.position.y + rect.size.y * 0.62, 9.0, rect.size.y * 0.24), Color(0.02, 0.02, 0.03), 4.0)
	if player:
		draw_circle(Vector2(rect.position.x + rect.size.x * 0.28, rect.position.y + rect.size.y * 0.09), 4.0, Color(0.95, 1.0, 0.7))
		draw_circle(Vector2(rect.position.x + rect.size.x * 0.72, rect.position.y + rect.size.y * 0.09), 4.0, Color(0.95, 1.0, 0.7))

func draw_panel(rect: Rect2, color: Color) -> void:
	draw_round_rect(Rect2(rect.position.x + 0.0, rect.position.y + 10.0, rect.size.x, rect.size.y), Color(0.0, 0.0, 0.0, 0.24), 32.0)
	draw_round_rect(rect, color, 32.0)
	draw_rect(Rect2(rect.position.x + 20.0, rect.position.y + 2.0, rect.size.x - 40.0, 2.0), Color(1.0, 1.0, 1.0, 0.16))

func add_button(id: String, label: String, rect: Rect2, color: Color, size_px: int = 24) -> void:
	buttons.append({"id": id, "rect": rect})
	draw_round_rect(Rect2(rect.position.x, rect.position.y + 5.0, rect.size.x, rect.size.y), Color(0.0, 0.0, 0.0, 0.28), 22.0)
	draw_round_rect(rect, color, 22.0)
	draw_string_center(label, rect, size_px, Color.WHITE)

func draw_round_rect(rect: Rect2, color: Color, radius: float) -> void:
	var r := min(radius, min(rect.size.x, rect.size.y) * 0.5)
	draw_rect(Rect2(rect.position.x + r, rect.position.y, rect.size.x - 2.0 * r, rect.size.y), color)
	draw_rect(Rect2(rect.position.x, rect.position.y + r, rect.size.x, rect.size.y - 2.0 * r), color)
	draw_circle(rect.position + Vector2(r, r), r, color)
	draw_circle(rect.position + Vector2(rect.size.x - r, r), r, color)
	draw_circle(rect.position + Vector2(r, rect.size.y - r), r, color)
	draw_circle(rect.position + Vector2(rect.size.x - r, rect.size.y - r), r, color)

func draw_string_center(text: String, rect: Rect2, size_px: int, color: Color) -> void:
	if font == null:
		return
	var y := rect.position.y + rect.size.y * 0.5 + float(size_px) * 0.35
	draw_string(font, Vector2(rect.position.x, y), text, HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, size_px, color)
