# اصلاح CI نسخه 1.1

این نسخه برای GitHub Actions آماده‌تر شده است:

- workflow فقط patch ساده انجام نمی‌دهد؛ `export_presets.cfg` را از صفر بازنویسی می‌کند.
- ابتدا خروجی مستقیم Android Template را امتحان می‌کند.
- اگر export مستقیم خطا داد، خودکار Android Gradle Build Template را از `android_source.zip` نصب می‌کند و دوباره خروجی می‌گیرد.
- `project.godot` برای CI روی renderer سازگار `gl_compatibility` تنظیم می‌شود.
- debug keystore داخل CI ساخته می‌شود و داخل preset هم مستقیم قرار می‌گیرد.
- Android SDK، Build Tools 34، Platform 34، CMake و NDK 23 نصب می‌شود.
- آخرین ZIP نسخه‌دار ریشه ریپو را خودش تشخیص می‌دهد.

برای استفاده:

1. این ZIP را در ریشه GitHub آپلود کن.
2. فایل `.github/workflows/build-godot-latest-zip.yml` را هم در ریپو داشته باش.
3. Actions را اجرا کن.
4. خروجی APK از Artifacts دانلود می‌شود.
