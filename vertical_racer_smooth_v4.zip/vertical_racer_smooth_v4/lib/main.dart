import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: Color(0xFF030713),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const SmoothRacerApp());
}

class SmoothRacerApp extends StatelessWidget {
  const SmoothRacerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'جاده بی‌پایان',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF030713),
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF21D9FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(),
      ),
    );
  }
}

class StorageKeys {
  static const highScore = 'smooth_vr_high_score';
  static const coins = 'smooth_vr_total_coins';
  static const bestLevel = 'smooth_vr_best_level';
  static const selectedCar = 'smooth_vr_selected_car';
}

class CarSkin {
  const CarSkin({required this.name, required this.top, required this.bottom, required this.accent, required this.price});

  final String name;
  final Color top;
  final Color bottom;
  final Color accent;
  final int price;
}

class CarSkins {
  static const all = <CarSkin>[
    CarSkin(name: 'آبی نئونی', top: Color(0xFF43E6FF), bottom: Color(0xFF0F7BFF), accent: Color(0xFFFFFFA7), price: 0),
    CarSkin(name: 'قرمز توربو', top: Color(0xFFFF5478), bottom: Color(0xFFE21540), accent: Color(0xFFFFD166), price: 160),
    CarSkin(name: 'بنفش اسپرت', top: Color(0xFFA866FF), bottom: Color(0xFF4D62FF), accent: Color(0xFFFF6FD8), price: 260),
    CarSkin(name: 'سبز لیزری', top: Color(0xFF44F5B7), bottom: Color(0xFF009A65), accent: Color(0xFFFFFFFF), price: 360),
    CarSkin(name: 'طلایی ویژه', top: Color(0xFFFFD166), bottom: Color(0xFFFF8C00), accent: Color(0xFFFFF4B0), price: 520),
  ];

  static const enemies = <CarSkin>[
    CarSkin(name: 'حریف', top: Color(0xFFFFB04D), bottom: Color(0xFFFF7B1A), accent: Color(0xFFFF3D76), price: 0),
    CarSkin(name: 'حریف', top: Color(0xFF8A7DFF), bottom: Color(0xFF4B5EFF), accent: Color(0xFFFF477E), price: 0),
    CarSkin(name: 'حریف', top: Color(0xFF53F3CF), bottom: Color(0xFF07A9D8), accent: Color(0xFFFFFFB3), price: 0),
    CarSkin(name: 'حریف', top: Color(0xFFFF6B9B), bottom: Color(0xFFE1306C), accent: Color(0xFFFFD166), price: 0),
  ];
}

BoxDecoration glass({double radius = 30, double opacity = 0.14}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topRight,
      end: Alignment.bottomLeft,
      colors: [Colors.white.withOpacity(opacity + 0.045), Colors.white.withOpacity(opacity * 0.35)],
    ),
    border: Border.all(color: Colors.white.withOpacity(0.17)),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.38), blurRadius: 28, offset: const Offset(0, 18)),
      BoxShadow(color: const Color(0xFF21D9FF).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, -8)),
    ],
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  int _highScore = 0;
  int _coins = 0;
  int _bestLevel = 1;
  int _selectedCar = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
    _load();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _highScore = prefs.getInt(StorageKeys.highScore) ?? 0;
      _coins = prefs.getInt(StorageKeys.coins) ?? 0;
      _bestLevel = prefs.getInt(StorageKeys.bestLevel) ?? 1;
      _selectedCar = (prefs.getInt(StorageKeys.selectedCar) ?? 0).clamp(0, CarSkins.all.length - 1).toInt();
    });
  }

  Future<void> _start() async {
    HapticFeedback.lightImpact();
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) {
      return Directionality(textDirection: TextDirection.rtl, child: GameScreen(carIndex: _selectedCar));
    }));
    await _load();
  }

  Future<void> _garage() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) {
      return const Directionality(textDirection: TextDirection.rtl, child: GarageScreen());
    }));
    await _load();
  }

  void _guide() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          margin: const EdgeInsets.fromLTRB(14, 0, 14, 18),
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
          decoration: glass(radius: 30, opacity: 0.18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Icon(Icons.info_rounded, color: Color(0xFFFFD166), size: 30),
                  const SizedBox(width: 10),
                  const Expanded(child: Text('راهنمای سریع', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                ],
              ),
              const SizedBox(height: 8),
              const GuideLine(icon: Icons.touch_app_rounded, title: 'کنترل', text: 'سمت چپ یا راست صفحه را لمس کن تا ماشین بین لاین‌ها جابه‌جا شود.'),
              const GuideLine(icon: Icons.speed_rounded, title: 'روانی', text: 'نسخه v4 با حلقه بازی سبک ساخته شده و در حین حرکت صفحه rebuild نمی‌شود.'),
              const GuideLine(icon: Icons.auto_awesome_rounded, title: 'آیتم‌ها', text: 'سکه، سپر، آهنربا و نیترو را بگیر و از برخورد با ماشین‌ها و موانع دوری کن.'),
              const GuideLine(icon: Icons.emoji_events_rounded, title: 'هدف', text: 'زنده بمان، رکورد بزن، مرحله‌ها را بالا ببر و ماشین‌های جدید باز کن.'),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final car = CarSkins.all[_selectedCar];
    return Scaffold(
      body: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: HomePainter(t: _controller.value))),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(child: HomeStat(title: 'رکورد', value: _highScore.toString(), icon: Icons.emoji_events_rounded)),
                          const SizedBox(width: 12),
                          Expanded(child: HomeStat(title: 'سکه', value: _coins.toString(), icon: Icons.monetization_on_rounded)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: HomeStat(title: 'بهترین مرحله', value: _bestLevel.toString(), icon: Icons.local_fire_department_rounded, compact: true)),
                          const SizedBox(width: 12),
                          Expanded(child: HomeStat(title: 'ماشین', value: car.name, icon: Icons.directions_car_rounded, compact: true)),
                        ],
                      ),
                      const Spacer(),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                        decoration: glass(radius: 38, opacity: 0.19),
                        child: Column(
                          children: [
                            const Text('جاده بی‌پایان', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, height: 1.08)),
                            const SizedBox(height: 8),
                            Text('نسخه روان، سبک و مرحله‌ای', style: TextStyle(fontSize: 16, color: Colors.white.withOpacity(0.74), fontWeight: FontWeight.w800)),
                            const SizedBox(height: 22),
                            SizedBox(
                              height: 210,
                              child: CustomPaint(painter: HeroRoadPainter(t: _controller.value, skin: car), child: const SizedBox.expand()),
                            ),
                            const SizedBox(height: 20),
                            BigGradientButton(text: 'شروع بازی', icon: Icons.play_arrow_rounded, onTap: _start),
                            const SizedBox(height: 14),
                            Row(
                              children: [
                                Expanded(child: SmallGlassButton(text: 'راهنما', icon: Icons.info_outline_rounded, onTap: _guide)),
                                const SizedBox(width: 12),
                                Expanded(child: SmallGlassButton(text: 'گاراژ', icon: Icons.directions_car_filled_rounded, onTap: _garage)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Text('هدف: جاخالی بده، سکه جمع کن و رکورد بزن.', style: TextStyle(color: Colors.white.withOpacity(0.66), fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class HomePainter extends CustomPainter {
  HomePainter({required this.t});
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF152B68), Color(0xFF050914), Color(0xFF02040A)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final orb = Paint()..color = const Color(0xFF36D9FF).withOpacity(0.08);
    canvas.drawCircle(Offset(size.width * (0.15 + 0.04 * math.sin(t * math.pi * 2)), size.height * 0.22), size.width * 0.38, orb);
    canvas.drawCircle(Offset(size.width * (0.83 + 0.03 * math.cos(t * math.pi * 2)), size.height * 0.44), size.width * 0.34, Paint()..color = const Color(0xFF756CFF).withOpacity(0.10));
    canvas.drawCircle(Offset(size.width * 0.18, size.height * 0.83), size.width * 0.33, Paint()..color = const Color(0xFF21D9FF).withOpacity(0.07));

    final sidePaint = Paint()
      ..color = const Color(0xFF21D9FF).withOpacity(0.25)
      ..strokeWidth = 3;
    final x1 = size.width * 0.14;
    final x2 = size.width * 0.86;
    canvas.drawLine(Offset(x1, 0), Offset(x1, size.height), sidePaint);
    canvas.drawLine(Offset(x2, 0), Offset(x2, size.height), sidePaint);
    final dotPaint = Paint()..color = const Color(0xFF21D9FF).withOpacity(0.08);
    for (int i = 0; i < 12; i++) {
      final y = (i * 130.0 + t * 120) % (size.height + 80) - 40;
      canvas.drawCircle(Offset(size.width * 0.07, y), 22, dotPaint);
      canvas.drawCircle(Offset(size.width * 0.94, y + 50), 22, dotPaint);
    }
  }

  @override
  bool shouldRepaint(HomePainter oldDelegate) => oldDelegate.t != t;
}

class HeroRoadPainter extends CustomPainter {
  HeroRoadPainter({required this.t, required this.skin});
  final double t;
  final CarSkin skin;

  @override
  void paint(Canvas canvas, Size size) {
    final roadRect = RRect.fromRectAndRadius(Rect.fromLTWH(size.width * 0.22, 0, size.width * 0.56, size.height), const Radius.circular(34));
    canvas.drawRRect(roadRect, Paint()..color = const Color(0xFF111A31));
    final center = size.width * 0.5;
    final dashPaint = Paint()
      ..color = Colors.white.withOpacity(0.60)
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 5;
    final dashH = 42.0;
    final gap = 68.0;
    final offset = (t * (dashH + gap) * 2) % (dashH + gap);
    for (double y = -dashH + offset; y < size.height + dashH; y += dashH + gap) {
      canvas.drawLine(Offset(center, y), Offset(center, y + dashH), dashPaint);
    }
    final carW = size.width * 0.24;
    _drawCar(canvas, Offset(center, size.height * 0.54), carW, carW * 1.38, skin, 1.0, false);
  }

  @override
  bool shouldRepaint(HeroRoadPainter oldDelegate) => oldDelegate.t != t || oldDelegate.skin != skin;
}

class HomeStat extends StatelessWidget {
  const HomeStat({super.key, required this.title, required this.value, required this.icon, this.compact = false});

  final String title;
  final String value;
  final IconData icon;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: compact ? 12 : 16),
      decoration: glass(radius: 22, opacity: 0.12),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFFFD166), size: compact ? 24 : 30),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(color: Colors.white.withOpacity(0.58), fontSize: compact ? 12 : 13, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 16 : 22, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BigGradientButton extends StatelessWidget {
  const BigGradientButton({super.key, required this.text, required this.icon, required this.onTap});
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onTap,
        child: Ink(
          height: 76,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(colors: [Color(0xFF2FE1FF), Color(0xFF7467FF)]),
            boxShadow: [BoxShadow(color: const Color(0xFF2FE1FF).withOpacity(0.28), blurRadius: 28, offset: const Offset(0, 12))],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(text, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              const SizedBox(width: 12),
              Icon(icon, size: 34),
            ],
          ),
        ),
      ),
    );
  }
}

class SmallGlassButton extends StatelessWidget {
  const SmallGlassButton({super.key, required this.text, required this.icon, required this.onTap});
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Ink(
          height: 60,
          decoration: glass(radius: 24, opacity: 0.11),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(width: 8),
              Icon(icon, size: 26, color: Colors.white.withOpacity(0.84)),
            ],
          ),
        ),
      ),
    );
  }
}

class GuideLine extends StatelessWidget {
  const GuideLine({super.key, required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.09), borderRadius: BorderRadius.circular(14)),
            child: Icon(icon, color: const Color(0xFF21D9FF)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 3),
                Text(text, style: TextStyle(fontSize: 14, height: 1.55, color: Colors.white.withOpacity(0.70))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class GarageScreen extends StatefulWidget {
  const GarageScreen({super.key});

  @override
  State<GarageScreen> createState() => _GarageScreenState();
}

class _GarageScreenState extends State<GarageScreen> {
  int _coins = 0;
  int _selected = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _coins = prefs.getInt(StorageKeys.coins) ?? 0;
      _selected = (prefs.getInt(StorageKeys.selectedCar) ?? 0).clamp(0, CarSkins.all.length - 1).toInt();
    });
  }

  Future<void> _select(int index) async {
    final skin = CarSkins.all[index];
    if (_coins < skin.price) {
      HapticFeedback.mediumImpact();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سکه کافی نداری.')));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(StorageKeys.selectedCar, index);
    if (!mounted) return;
    setState(() => _selected = index);
    HapticFeedback.selectionClick();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: HomePainter(t: 0.2))),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                      const Expanded(child: Text('گاراژ ماشین‌ها', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: glass(radius: 18, opacity: 0.13),
                        child: Row(children: [const Icon(Icons.monetization_on_rounded, color: Color(0xFFFFD166)), const SizedBox(width: 6), Text('$_coins', style: const TextStyle(fontWeight: FontWeight.w900))]),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: ListView.separated(
                      itemCount: CarSkins.all.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final skin = CarSkins.all[index];
                        final selected = index == _selected;
                        final locked = _coins < skin.price;
                        return InkWell(
                          borderRadius: BorderRadius.circular(28),
                          onTap: () => _select(index),
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            decoration: glass(radius: 28, opacity: selected ? 0.22 : 0.12),
                            child: Row(
                              children: [
                                SizedBox(width: 90, height: 110, child: CustomPaint(painter: GarageCarPainter(skin: skin))),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(skin.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                                      const SizedBox(height: 8),
                                      Text(skin.price == 0 ? 'رایگان' : '${skin.price} سکه', style: TextStyle(color: locked ? Colors.redAccent : const Color(0xFFFFD166), fontWeight: FontWeight.w900)),
                                      const SizedBox(height: 8),
                                      Text(selected ? 'انتخاب شده' : locked ? 'برای انتخاب سکه بیشتری لازم است' : 'برای انتخاب لمس کن', style: TextStyle(color: Colors.white.withOpacity(0.62), fontWeight: FontWeight.w700)),
                                    ],
                                  ),
                                ),
                                Icon(selected ? Icons.check_circle_rounded : locked ? Icons.lock_rounded : Icons.radio_button_unchecked_rounded, color: selected ? const Color(0xFF45F0B0) : Colors.white.withOpacity(0.55)),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class GarageCarPainter extends CustomPainter {
  GarageCarPainter({required this.skin});
  final CarSkin skin;

  @override
  void paint(Canvas canvas, Size size) {
    _drawCar(canvas, Offset(size.width / 2, size.height / 2), size.width * 0.62, size.height * 0.72, skin, 1.0, false);
  }

  @override
  bool shouldRepaint(GarageCarPainter oldDelegate) => oldDelegate.skin != skin;
}

class HudData {
  const HudData({required this.score, required this.coins, required this.level, required this.lives, required this.shield, required this.magnet, required this.nitro});

  final int score;
  final int coins;
  final int level;
  final int lives;
  final double shield;
  final double magnet;
  final double nitro;
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.carIndex});
  final int carIndex;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final RacingEngine _engine;
  late final Ticker _ticker;
  Duration? _last;
  bool _gameOverVisible = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _engine = RacingEngine(skin: CarSkins.all[widget.carIndex], onGameOver: _showGameOver);
    _ticker = createTicker(_onTick)..start();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    _engine.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _engine.paused = true;
    } else if (state == AppLifecycleState.resumed) {
      _last = null;
      _engine.paused = false;
    }
  }

  void _onTick(Duration elapsed) {
    if (_last == null) {
      _last = elapsed;
      return;
    }
    final dt = (elapsed - _last!).inMicroseconds / Duration.microsecondsPerSecond;
    _last = elapsed;
    _engine.tick(dt);
  }

  Future<void> _showGameOver() async {
    await _engine.saveResult();
    if (!mounted) return;
    setState(() => _gameOverVisible = true);
    HapticFeedback.heavyImpact();
  }

  void _restart() {
    setState(() => _gameOverVisible = false);
    _engine.restart();
    _last = null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          final size = Size(constraints.maxWidth, constraints.maxHeight);
          _engine.setSize(size, MediaQuery.of(context).padding);
          return Stack(
            children: [
              Positioned.fill(
                child: RepaintBoundary(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapDown: (details) {
                      if (_gameOverVisible) return;
                      if (details.localPosition.dx < size.width / 2) {
                        _engine.moveLeft();
                      } else {
                        _engine.moveRight();
                      }
                    },
                    onHorizontalDragUpdate: (details) {
                      if (_gameOverVisible) return;
                      if (details.primaryDelta == null) return;
                      if (details.primaryDelta! < -8) _engine.moveLeft();
                      if (details.primaryDelta! > 8) _engine.moveRight();
                    },
                    child: CustomPaint(painter: RacingPainter(_engine)),
                  ),
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                  child: ValueListenableBuilder<HudData>(
                    valueListenable: _engine.hud,
                    builder: (context, hud, child) => GameHud(hud: hud),
                  ),
                ),
              ),
              Positioned(
                left: 18,
                right: 18,
                bottom: 20 + MediaQuery.of(context).padding.bottom,
                child: IgnorePointer(
                  ignoring: _gameOverVisible,
                  child: Row(
                    children: [
                      ControlButton(icon: Icons.keyboard_arrow_right_rounded, onTap: _engine.moveLeft),
                      const Spacer(),
                      ControlButton(icon: Icons.keyboard_arrow_left_rounded, onTap: _engine.moveRight),
                    ],
                  ),
                ),
              ),
              if (_gameOverVisible)
                Positioned.fill(
                  child: GameOverOverlay(engine: _engine, onRestart: _restart, onHome: () => Navigator.pop(context)),
                ),
            ],
          );
        },
      ),
    );
  }
}

class GameHud extends StatelessWidget {
  const GameHud({super.key, required this.hud});
  final HudData hud;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: glass(radius: 28, opacity: 0.10),
      child: Row(
        children: [
          Expanded(child: HudTile(icon: Icons.speed_rounded, title: 'امتیاز', value: hud.score.toString())),
          Expanded(child: HudTile(icon: Icons.monetization_on_rounded, title: 'سکه', value: hud.coins.toString())),
          Expanded(child: HudTile(icon: Icons.local_fire_department_rounded, title: 'مرحله', value: hud.level.toString())),
          Expanded(child: HudTile(icon: Icons.favorite_rounded, title: 'جان', value: hud.lives.toString())),
        ],
      ),
    );
  }
}

class HudTile extends StatelessWidget {
  const HudTile({super.key, required this.icon, required this.title, required this.value});
  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: const Color(0xFFFFD166), size: 25),
        const SizedBox(height: 3),
        Text(title, style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text(value, maxLines: 1, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class ControlButton extends StatelessWidget {
  const ControlButton({super.key, required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(30),
        child: Ink(
          width: 110,
          height: 92,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white.withOpacity(0.12),
            border: Border.all(color: Colors.white.withOpacity(0.22)),
          ),
          child: Icon(icon, size: 56, color: Colors.white.withOpacity(0.92)),
        ),
      ),
    );
  }
}

class GameOverOverlay extends StatelessWidget {
  const GameOverOverlay({super.key, required this.engine, required this.onRestart, required this.onHome});
  final RacingEngine engine;
  final VoidCallback onRestart;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.54),
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(22),
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
          decoration: glass(radius: 34, opacity: 0.20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.emoji_events_rounded, size: 58, color: Color(0xFFFFD166)),
              const SizedBox(height: 10),
              const Text('پایان بازی', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 10,
                runSpacing: 10,
                children: [
                  ResultChip(title: 'امتیاز', value: engine.scoreInt.toString()),
                  ResultChip(title: 'سکه', value: engine.sessionCoins.toString()),
                  ResultChip(title: 'مرحله', value: engine.level.toString()),
                ],
              ),
              const SizedBox(height: 20),
              BigGradientButton(text: 'شروع دوباره', icon: Icons.replay_rounded, onTap: onRestart),
              const SizedBox(height: 12),
              SmallGlassButton(text: 'بازگشت به خانه', icon: Icons.home_rounded, onTap: onHome),
            ],
          ),
        ),
      ),
    );
  }
}

class ResultChip extends StatelessWidget {
  const ResultChip({super.key, required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 94,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.10), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(0.13))),
      child: Column(
        children: [
          Text(title, style: TextStyle(color: Colors.white.withOpacity(0.56), fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class PoolObject {
  bool active = false;
  int kind = 0;
  int lane = 0;
  double x = 0;
  double y = 0;
  double w = 0;
  double h = 0;
  double phase = 0;
  double speedFactor = 1;
  int skinIndex = 0;
}

class Particle {
  bool active = false;
  double x = 0;
  double y = 0;
  double vx = 0;
  double vy = 0;
  double life = 0;
  double maxLife = 1;
  double radius = 2;
  Color color = Colors.white;
}

class RacingEngine extends ChangeNotifier {
  RacingEngine({required this.skin, required this.onGameOver}) {
    for (var i = 0; i < 24; i++) enemies.add(PoolObject());
    for (var i = 0; i < 40; i++) coins.add(PoolObject());
    for (var i = 0; i < 10; i++) powers.add(PoolObject());
    for (var i = 0; i < 90; i++) particles.add(Particle());
    hud = ValueNotifier<HudData>(_hudData());
    restart();
  }

  final CarSkin skin;
  final Future<void> Function() onGameOver;
  late final ValueNotifier<HudData> hud;
  final math.Random rng = math.Random();
  final List<PoolObject> enemies = <PoolObject>[];
  final List<PoolObject> coins = <PoolObject>[];
  final List<PoolObject> powers = <PoolObject>[];
  final List<Particle> particles = <Particle>[];

  Size size = Size.zero;
  EdgeInsets padding = EdgeInsets.zero;
  bool paused = false;
  bool over = false;
  bool _saving = false;

  double roadLeft = 0;
  double roadWidth = 0;
  double roadTop = 0;
  double roadBottom = 0;
  double playerY = 0;
  double playerX = 0;
  int playerLane = 1;
  double laneT = 1;
  double targetLaneT = 1;

  double score = 0;
  int sessionCoins = 0;
  int level = 1;
  int lives = 3;
  double speed = 330;
  double roadOffset = 0;
  double spawnTimer = 0;
  double coinTimer = 0;
  double powerTimer = 3;
  double shieldTime = 0;
  double magnetTime = 0;
  double nitroTime = 0;
  double invincibleTime = 0;
  double _accumulator = 0;
  double _hudTimer = 0;
  double _distanceSeed = 0;

  int get scoreInt => score.floor();

  void setSize(Size newSize, EdgeInsets safePadding) {
    if (size == newSize && padding == safePadding) return;
    size = newSize;
    padding = safePadding;
    roadLeft = size.width * 0.13;
    roadWidth = size.width * 0.74;
    roadTop = -60;
    roadBottom = size.height + 60;
    playerY = size.height * 0.76;
    _syncPlayerX(immediate: true);
  }

  void restart() {
    over = false;
    paused = false;
    _saving = false;
    score = 0;
    sessionCoins = 0;
    level = 1;
    lives = 3;
    speed = 330;
    roadOffset = 0;
    spawnTimer = 0.65;
    coinTimer = 0.55;
    powerTimer = 3.8;
    shieldTime = 0;
    magnetTime = 0;
    nitroTime = 0;
    invincibleTime = 0.8;
    _accumulator = 0;
    _hudTimer = 0;
    _distanceSeed = rng.nextDouble() * 1000;
    playerLane = 1;
    laneT = 1;
    targetLaneT = 1;
    for (final o in enemies) o.active = false;
    for (final o in coins) o.active = false;
    for (final o in powers) o.active = false;
    for (final p in particles) p.active = false;
    _syncPlayerX(immediate: true);
    _publishHud(force: true);
    notifyListeners();
  }

  void moveLeft() {
    if (over) return;
    final next = (playerLane - 1).clamp(0, 2).toInt();
    if (next != playerLane) {
      playerLane = next;
      targetLaneT = next.toDouble();
      HapticFeedback.selectionClick();
    }
  }

  void moveRight() {
    if (over) return;
    final next = (playerLane + 1).clamp(0, 2).toInt();
    if (next != playerLane) {
      playerLane = next;
      targetLaneT = next.toDouble();
      HapticFeedback.selectionClick();
    }
  }

  void tick(double rawDt) {
    if (paused || over || size.isEmpty) return;
    final clamped = rawDt.clamp(0.0, 0.033).toDouble();
    _accumulator += clamped;
    const step = 1 / 60.0;
    int loops = 0;
    while (_accumulator >= step && loops < 3) {
      _update(step);
      _accumulator -= step;
      loops++;
    }
    if (loops == 3) _accumulator = 0;
    notifyListeners();
  }

  Future<void> saveResult() async {
    if (_saving) return;
    _saving = true;
    final prefs = await SharedPreferences.getInstance();
    final oldHigh = prefs.getInt(StorageKeys.highScore) ?? 0;
    final oldCoins = prefs.getInt(StorageKeys.coins) ?? 0;
    final oldLevel = prefs.getInt(StorageKeys.bestLevel) ?? 1;
    if (scoreInt > oldHigh) await prefs.setInt(StorageKeys.highScore, scoreInt);
    if (level > oldLevel) await prefs.setInt(StorageKeys.bestLevel, level);
    await prefs.setInt(StorageKeys.coins, oldCoins + sessionCoins);
  }

  void _update(double dt) {
    final targetSpeed = 320 + (level - 1) * 24 + math.min(220, score * 0.035);
    speed += (targetSpeed - speed) * math.min(1, 2.2 * dt);
    final effectiveSpeed = speed * (nitroTime > 0 ? 1.22 : 1.0);

    score += effectiveSpeed * 0.44 * dt;
    final newLevel = (score ~/ 750) + 1;
    if (newLevel != level) {
      level = newLevel;
      _burst(size.width * 0.5, size.height * 0.30, const Color(0xFFFFD166), 16);
    }

    roadOffset = (roadOffset + effectiveSpeed * dt) % 130;
    _distanceSeed += effectiveSpeed * dt;
    _syncPlayerX(immediate: false);

    shieldTime = math.max(0, shieldTime - dt);
    magnetTime = math.max(0, magnetTime - dt);
    nitroTime = math.max(0, nitroTime - dt);
    invincibleTime = math.max(0, invincibleTime - dt);

    spawnTimer -= dt;
    coinTimer -= dt;
    powerTimer -= dt;

    if (spawnTimer <= 0) {
      _spawnEnemy();
      final interval = math.max(0.36, 0.95 - level * 0.035 - score * 0.000012);
      spawnTimer = interval + rng.nextDouble() * 0.18;
    }
    if (coinTimer <= 0) {
      _spawnCoinLine();
      coinTimer = 0.75 + rng.nextDouble() * 0.75;
    }
    if (powerTimer <= 0) {
      _spawnPower();
      powerTimer = 7.2 + rng.nextDouble() * 4.4;
    }

    _updateEnemies(effectiveSpeed, dt);
    _updateCoins(effectiveSpeed, dt);
    _updatePowers(effectiveSpeed, dt);
    _updateParticles(dt);

    _hudTimer -= dt;
    if (_hudTimer <= 0) {
      _hudTimer = 0.12;
      _publishHud();
    }
  }

  void _syncPlayerX({required bool immediate}) {
    final laneWidth = roadWidth / 3;
    final target = roadLeft + laneWidth * (targetLaneT + 0.5);
    if (immediate) {
      playerX = target;
      laneT = targetLaneT;
    } else {
      playerX += (target - playerX) * 0.22;
      laneT += (targetLaneT - laneT) * 0.22;
    }
  }

  double laneCenter(int lane) => roadLeft + roadWidth / 3 * (lane + 0.5);

  Rect playerRect() {
    final w = roadWidth * 0.17;
    final h = w * 1.46;
    return Rect.fromCenter(center: Offset(playerX, playerY), width: w, height: h);
  }

  void _spawnEnemy() {
    final obj = enemies.firstWhere((e) => !e.active, orElse: () => enemies.first);
    final lane = rng.nextInt(3);
    final car = rng.nextDouble() > 0.80;
    obj
      ..active = true
      ..kind = car ? 1 : rng.nextInt(4)
      ..lane = lane
      ..x = laneCenter(lane)
      ..y = -size.height * (0.10 + rng.nextDouble() * 0.12)
      ..w = roadWidth * (obj.kind == 1 ? 0.20 : 0.16)
      ..h = roadWidth * (obj.kind == 1 ? 0.42 : 0.24)
      ..phase = rng.nextDouble() * math.pi * 2
      ..speedFactor = 0.95 + rng.nextDouble() * 0.20
      ..skinIndex = rng.nextInt(CarSkins.enemies.length);
  }

  void _spawnCoinLine() {
    final lane = rng.nextInt(3);
    final count = 2 + rng.nextInt(3);
    for (var i = 0; i < count; i++) {
      final obj = coins.firstWhere((e) => !e.active, orElse: () => coins.first);
      obj
        ..active = true
        ..kind = 0
        ..lane = lane
        ..x = laneCenter(lane)
        ..y = -70.0 - i * 58.0
        ..w = 26
        ..h = 26
        ..phase = rng.nextDouble() * math.pi * 2
        ..speedFactor = 1.0
        ..skinIndex = 0;
    }
  }

  void _spawnPower() {
    final obj = powers.firstWhere((e) => !e.active, orElse: () => powers.first);
    final lane = rng.nextInt(3);
    obj
      ..active = true
      ..kind = rng.nextInt(3)
      ..lane = lane
      ..x = laneCenter(lane)
      ..y = -90
      ..w = 34
      ..h = 34
      ..phase = rng.nextDouble() * math.pi * 2
      ..speedFactor = 0.98
      ..skinIndex = 0;
  }

  void _updateEnemies(double effectiveSpeed, double dt) {
    final p = playerRect().deflate(5);
    for (final o in enemies) {
      if (!o.active) continue;
      o.y += effectiveSpeed * o.speedFactor * dt;
      if (o.y > size.height + 140) {
        o.active = false;
        continue;
      }
      final hit = Rect.fromCenter(center: Offset(o.x, o.y), width: o.w * 0.80, height: o.h * 0.80);
      if (hit.overlaps(p)) {
        if (shieldTime > 0 || invincibleTime > 0) {
          o.active = false;
          score += 70;
          _burst(o.x, o.y, const Color(0xFF21D9FF), 14);
        } else {
          o.active = false;
          lives -= 1;
          invincibleTime = 1.0;
          _burst(playerX, playerY, const Color(0xFFFF4F70), 22);
          HapticFeedback.mediumImpact();
          if (lives <= 0) {
            _endGame();
            return;
          }
        }
      }
    }
  }

  void _updateCoins(double effectiveSpeed, double dt) {
    final p = playerRect().inflate(magnetTime > 0 ? 72 : 8);
    for (final o in coins) {
      if (!o.active) continue;
      if (magnetTime > 0) {
        final dx = playerX - o.x;
        final dy = playerY - o.y;
        final d = math.sqrt(dx * dx + dy * dy);
        if (d < 160 && d > 1) {
          o.x += dx / d * 260 * dt;
          o.y += dy / d * 260 * dt;
        }
      }
      o.y += effectiveSpeed * 0.94 * dt;
      if (o.y > size.height + 80) {
        o.active = false;
        continue;
      }
      final hit = Rect.fromCenter(center: Offset(o.x, o.y), width: 34, height: 34);
      if (hit.overlaps(p)) {
        o.active = false;
        sessionCoins += 1;
        score += 28;
        _burst(o.x, o.y, const Color(0xFFFFD166), 8);
      }
    }
  }

  void _updatePowers(double effectiveSpeed, double dt) {
    final p = playerRect().inflate(10);
    for (final o in powers) {
      if (!o.active) continue;
      o.y += effectiveSpeed * 0.92 * dt;
      if (o.y > size.height + 80) {
        o.active = false;
        continue;
      }
      final hit = Rect.fromCenter(center: Offset(o.x, o.y), width: 46, height: 46);
      if (hit.overlaps(p)) {
        o.active = false;
        if (o.kind == 0) shieldTime = 5.5;
        if (o.kind == 1) magnetTime = 5.5;
        if (o.kind == 2) nitroTime = 4.3;
        score += 50;
        _burst(o.x, o.y, o.kind == 0 ? const Color(0xFF70A7FF) : o.kind == 1 ? const Color(0xFF43F2B3) : const Color(0xFFFFD166), 18);
      }
    }
  }

  void _updateParticles(double dt) {
    for (final p in particles) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
      } else {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vx *= 0.985;
        p.vy += 20 * dt;
      }
    }
  }

  void _burst(double x, double y, Color color, int count) {
    for (var i = 0; i < count; i++) {
      final p = particles.firstWhere((e) => !e.active, orElse: () => particles.first);
      final a = rng.nextDouble() * math.pi * 2;
      final s = 70 + rng.nextDouble() * 190;
      p
        ..active = true
        ..x = x
        ..y = y
        ..vx = math.cos(a) * s
        ..vy = math.sin(a) * s
        ..life = 0.32 + rng.nextDouble() * 0.42
        ..maxLife = 0.74
        ..radius = 2 + rng.nextDouble() * 3.5
        ..color = color;
    }
  }

  void _endGame() {
    if (over) return;
    over = true;
    _publishHud(force: true);
    onGameOver();
  }

  HudData _hudData() => HudData(score: scoreInt, coins: sessionCoins, level: level, lives: lives, shield: shieldTime, magnet: magnetTime, nitro: nitroTime);

  void _publishHud({bool force = false}) {
    final data = _hudData();
    if (force || hud.value.score != data.score || hud.value.coins != data.coins || hud.value.level != data.level || hud.value.lives != data.lives) {
      hud.value = data;
    }
  }

  @override
  void dispose() {
    hud.dispose();
    super.dispose();
  }
}

class RacingPainter extends CustomPainter {
  RacingPainter(this.engine) : super(repaint: engine);

  final RacingEngine engine;
  final Paint _paint = Paint();
  final Paint _stroke = Paint()..style = PaintingStyle.stroke;

  @override
  void paint(Canvas canvas, Size size) {
    _drawBackground(canvas, size);
    _drawRoad(canvas, size);
    _drawSpeedLines(canvas, size);
    _drawObjects(canvas);
    _drawPlayer(canvas);
    _drawParticles(canvas);
    _drawPowerBars(canvas, size);
  }

  void _drawBackground(Canvas canvas, Size size) {
    _paint.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF182E6E), Color(0xFF08122C), Color(0xFF02040A)],
    ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, _paint);
    _paint.shader = null;

    final t = engine._distanceSeed * 0.001;
    _paint.color = const Color(0xFF25D7FF).withOpacity(0.07);
    for (var i = 0; i < 10; i++) {
      final y = ((i * 150.0 + t * 140) % (size.height + 120)) - 60;
      canvas.drawCircle(Offset(size.width * 0.07, y), 21, _paint);
      canvas.drawCircle(Offset(size.width * 0.94, y + 70), 21, _paint);
    }
  }

  void _drawRoad(Canvas canvas, Size size) {
    final left = engine.roadLeft;
    final w = engine.roadWidth;
    final road = RRect.fromRectAndRadius(Rect.fromLTWH(left, -40, w, size.height + 80), const Radius.circular(28));
    _paint.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF222D44), Color(0xFF151D31), Color(0xFF121827)],
    ).createShader(road.outerRect);
    canvas.drawRRect(road, _paint);
    _paint.shader = null;

    _stroke
      ..shader = const LinearGradient(colors: [Color(0xFF21D9FF), Color(0xFF3463FF)]).createShader(Rect.fromLTWH(left, 0, w, size.height))
      ..strokeWidth = 3.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(left + 3, -30), Offset(left + 3, size.height + 30), _stroke);
    canvas.drawLine(Offset(left + w - 3, -30), Offset(left + w - 3, size.height + 30), _stroke);
    _stroke.shader = null;

    final laneW = w / 3;
    _stroke
      ..color = Colors.white.withOpacity(0.56)
      ..strokeWidth = 5.0
      ..strokeCap = StrokeCap.round;
    const dashH = 68.0;
    const gap = 62.0;
    final off = engine.roadOffset % (dashH + gap);
    for (double y = -dashH + off; y < size.height + dashH; y += dashH + gap) {
      canvas.drawLine(Offset(left + laneW, y), Offset(left + laneW, y + dashH), _stroke);
      canvas.drawLine(Offset(left + laneW * 2, y + 18), Offset(left + laneW * 2, y + dashH + 18), _stroke);
    }

    _paint.color = const Color(0xFF21D9FF).withOpacity(0.10);
    canvas.drawRect(Rect.fromLTWH(left + 4, 0, 8, size.height), _paint);
    canvas.drawRect(Rect.fromLTWH(left + w - 12, 0, 8, size.height), _paint);
  }

  void _drawSpeedLines(Canvas canvas, Size size) {
    final intensity = (engine.speed / 600).clamp(0.25, 1.0).toDouble();
    _stroke
      ..color = Colors.white.withOpacity(0.09 * intensity)
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;
    final base = engine._distanceSeed * 0.45;
    for (var i = 0; i < 18; i++) {
      final y = ((i * 83.0 + base) % (size.height + 140)) - 70;
      final len = 32 + (i % 3) * 18;
      canvas.drawLine(Offset(engine.roadLeft - 20 - (i % 2) * 25, y), Offset(engine.roadLeft - 20 - (i % 2) * 25, y + len), _stroke);
      canvas.drawLine(Offset(engine.roadLeft + engine.roadWidth + 20 + (i % 2) * 25, y + 38), Offset(engine.roadLeft + engine.roadWidth + 20 + (i % 2) * 25, y + 38 + len), _stroke);
    }
  }

  void _drawObjects(Canvas canvas) {
    for (final c in engine.coins) {
      if (!c.active) continue;
      _drawCoin(canvas, Offset(c.x, c.y), 13 + math.sin(c.phase + engine._distanceSeed * 0.03) * 1.4);
    }
    for (final p in engine.powers) {
      if (!p.active) continue;
      _drawPower(canvas, Offset(p.x, p.y), p.kind);
    }
    for (final o in engine.enemies) {
      if (!o.active) continue;
      if (o.kind == 0) {
        _drawCar(canvas, Offset(o.x, o.y), o.w, o.h, CarSkins.enemies[o.skinIndex], 0.88, true);
      } else if (o.kind == 1) {
        _drawTruck(canvas, Offset(o.x, o.y), o.w, o.h);
      } else if (o.kind == 2) {
        _drawCone(canvas, Offset(o.x, o.y), o.w);
      } else {
        _drawOil(canvas, Offset(o.x, o.y), o.w);
      }
    }
  }

  void _drawPlayer(Canvas canvas) {
    final pulse = engine.invincibleTime > 0 ? (0.55 + 0.45 * math.sin(engine._distanceSeed * 0.05)).abs() : 1.0;
    final playerW = engine.roadWidth * 0.18;
    final playerH = playerW * 1.46;
    if (engine.shieldTime > 0) {
      _stroke
        ..color = const Color(0xFF70A7FF).withOpacity(0.42)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4;
      canvas.drawCircle(Offset(engine.playerX, engine.playerY), playerH * 0.58, _stroke);
    }
    if (engine.nitroTime > 0) {
      _paint.color = const Color(0xFF21D9FF).withOpacity(0.28);
      final flame = Path()
        ..moveTo(engine.playerX - playerW * 0.20, engine.playerY + playerH * 0.45)
        ..lineTo(engine.playerX, engine.playerY + playerH * (0.83 + 0.08 * math.sin(engine._distanceSeed * 0.09)))
        ..lineTo(engine.playerX + playerW * 0.20, engine.playerY + playerH * 0.45)
        ..close();
      canvas.drawPath(flame, _paint);
    }
    _drawCar(canvas, Offset(engine.playerX, engine.playerY), playerW, playerH, engine.skin, pulse, false);
  }

  void _drawParticles(Canvas canvas) {
    for (final p in engine.particles) {
      if (!p.active) continue;
      final opacity = (p.life / p.maxLife).clamp(0.0, 1.0).toDouble();
      _paint.color = p.color.withOpacity(opacity * 0.75);
      canvas.drawCircle(Offset(p.x, p.y), p.radius * opacity, _paint);
    }
  }

  void _drawPowerBars(Canvas canvas, Size size) {
    final bottom = size.height - 42;
    double x = size.width * 0.23;
    void bar(double value, Color color, IconData icon) {
      if (value <= 0) return;
      final rect = RRect.fromRectAndRadius(Rect.fromLTWH(x, bottom, size.width * 0.16, 8), const Radius.circular(8));
      _paint.color = Colors.white.withOpacity(0.12);
      canvas.drawRRect(rect, _paint);
      _paint.color = color.withOpacity(0.82);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, bottom, size.width * 0.16 * (value / 6).clamp(0.0, 1.0), 8), const Radius.circular(8)), _paint);
      x += size.width * 0.19;
    }
    bar(engine.shieldTime, const Color(0xFF70A7FF), Icons.shield_rounded);
    bar(engine.magnetTime, const Color(0xFF43F2B3), Icons.grid_3x3_rounded);
    bar(engine.nitroTime, const Color(0xFFFFD166), Icons.flash_on_rounded);
  }

  void _drawCoin(Canvas canvas, Offset c, double r) {
    _paint.color = const Color(0xFFFFD166).withOpacity(0.20);
    canvas.drawCircle(c, r * 1.7, _paint);
    _paint.color = const Color(0xFFFFD166);
    canvas.drawCircle(c, r, _paint);
    _stroke
      ..color = const Color(0xFF8A5A00).withOpacity(0.55)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(c, r * 0.68, _stroke);
    _stroke
      ..color = const Color(0xFF8A5A00).withOpacity(0.70)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(c.dx, c.dy - r * 0.45), Offset(c.dx, c.dy + r * 0.45), _stroke);
  }

  void _drawPower(Canvas canvas, Offset c, int kind) {
    final color = kind == 0 ? const Color(0xFF70A7FF) : kind == 1 ? const Color(0xFF43F2B3) : const Color(0xFFFFD166);
    _paint.color = color.withOpacity(0.20);
    canvas.drawCircle(c, 28, _paint);
    _paint.color = color.withOpacity(0.95);
    canvas.drawCircle(c, 18, _paint);
    _paint.color = const Color(0xFF07101F);
    if (kind == 0) {
      final path = Path()
        ..moveTo(c.dx, c.dy - 10)
        ..lineTo(c.dx + 10, c.dy - 5)
        ..quadraticBezierTo(c.dx + 8, c.dy + 10, c.dx, c.dy + 14)
        ..quadraticBezierTo(c.dx - 8, c.dy + 10, c.dx - 10, c.dy - 5)
        ..close();
      canvas.drawPath(path, _paint);
    } else if (kind == 1) {
      _stroke
        ..color = const Color(0xFF07101F)
        ..strokeWidth = 4
        ..style = PaintingStyle.stroke;
      canvas.drawCircle(c, 7, _stroke);
      canvas.drawLine(Offset(c.dx + 6, c.dy + 6), Offset(c.dx + 13, c.dy + 13), _stroke);
    } else {
      final path = Path()
        ..moveTo(c.dx + 2, c.dy - 13)
        ..lineTo(c.dx - 9, c.dy + 2)
        ..lineTo(c.dx + 0, c.dy + 2)
        ..lineTo(c.dx - 3, c.dy + 14)
        ..lineTo(c.dx + 10, c.dy - 2)
        ..lineTo(c.dx + 1, c.dy - 2)
        ..close();
      canvas.drawPath(path, _paint);
    }
  }

  void _drawTruck(Canvas canvas, Offset c, double w, double h) {
    _paint.color = Colors.black.withOpacity(0.24);
    canvas.drawOval(Rect.fromCenter(center: Offset(c.dx, c.dy + h * 0.43), width: w * 1.05, height: h * 0.14), _paint);
    final body = RRect.fromRectAndRadius(Rect.fromCenter(center: c, width: w, height: h), Radius.circular(w * 0.22));
    _paint.shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFF725C), Color(0xFF8727FF)]).createShader(body.outerRect);
    canvas.drawRRect(body, _paint);
    _paint.shader = null;
    _paint.color = const Color(0xFF0B1326).withOpacity(0.70);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx, c.dy - h * 0.20), width: w * 0.62, height: h * 0.22), Radius.circular(w * 0.12)), _paint);
    _paint.color = const Color(0xFF080A10);
    for (final dx in [-0.50, 0.50]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx + dx * w, c.dy - h * 0.22), width: w * 0.15, height: h * 0.24), Radius.circular(w * 0.06)), _paint);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx + dx * w, c.dy + h * 0.22), width: w * 0.15, height: h * 0.24), Radius.circular(w * 0.06)), _paint);
    }
  }

  void _drawCone(Canvas canvas, Offset c, double w) {
    _paint.color = Colors.black.withOpacity(0.18);
    canvas.drawOval(Rect.fromCenter(center: Offset(c.dx, c.dy + w * 0.32), width: w * 1.3, height: w * 0.26), _paint);
    final path = Path()
      ..moveTo(c.dx, c.dy - w * 0.58)
      ..lineTo(c.dx - w * 0.45, c.dy + w * 0.45)
      ..lineTo(c.dx + w * 0.45, c.dy + w * 0.45)
      ..close();
    _paint.color = const Color(0xFFFF8C00);
    canvas.drawPath(path, _paint);
    _stroke
      ..color = Colors.white.withOpacity(0.8)
      ..strokeWidth = 4;
    canvas.drawLine(Offset(c.dx - w * 0.22, c.dy + w * 0.05), Offset(c.dx + w * 0.22, c.dy + w * 0.05), _stroke);
  }

  void _drawOil(Canvas canvas, Offset c, double w) {
    _paint.color = Colors.black.withOpacity(0.28);
    canvas.drawOval(Rect.fromCenter(center: c, width: w * 1.35, height: w * 0.72), _paint);
    _paint.color = const Color(0xFF0A0B12).withOpacity(0.88);
    canvas.drawOval(Rect.fromCenter(center: c, width: w * 1.08, height: w * 0.55), _paint);
    _paint.color = const Color(0xFF6C7BFF).withOpacity(0.16);
    canvas.drawCircle(Offset(c.dx - w * 0.16, c.dy - w * 0.07), w * 0.15, _paint);
  }

  @override
  bool shouldRepaint(RacingPainter oldDelegate) => oldDelegate.engine != engine;
}

void _drawCar(Canvas canvas, Offset c, double w, double h, CarSkin skin, double opacity, bool enemy) {
  final paint = Paint();
  paint.color = Colors.black.withOpacity(0.24 * opacity);
  canvas.drawOval(Rect.fromCenter(center: Offset(c.dx, c.dy + h * 0.45), width: w * 1.05, height: h * 0.14), paint);

  final body = RRect.fromRectAndRadius(Rect.fromCenter(center: c, width: w, height: h), Radius.circular(w * 0.32));
  paint.shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [skin.top.withOpacity(opacity), skin.bottom.withOpacity(opacity)]).createShader(body.outerRect);
  canvas.drawRRect(body, paint);
  paint.shader = null;

  paint.color = Colors.white.withOpacity(0.10 * opacity);
  canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx - w * 0.14, c.dy - h * 0.06), width: w * 0.22, height: h * 0.76), Radius.circular(w * 0.11)), paint);

  paint.color = const Color(0xFF07101F).withOpacity(0.72 * opacity);
  canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx, c.dy - h * 0.18), width: w * 0.56, height: h * 0.30), Radius.circular(w * 0.16)), paint);

  paint.color = skin.accent.withOpacity(0.90 * opacity);
  canvas.drawCircle(Offset(c.dx - w * 0.24, c.dy - h * 0.40), w * 0.09, paint);
  canvas.drawCircle(Offset(c.dx + w * 0.24, c.dy - h * 0.40), w * 0.09, paint);

  paint.color = const Color(0xFF080A10).withOpacity(opacity);
  for (final dx in [-0.58, 0.58]) {
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx + dx * w, c.dy - h * 0.18), width: w * 0.18, height: h * 0.28), Radius.circular(w * 0.08)), paint);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx + dx * w, c.dy + h * 0.24), width: w * 0.18, height: h * 0.28), Radius.circular(w * 0.08)), paint);
  }

  paint.color = Colors.white.withOpacity(0.65 * opacity);
  canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx, c.dy + h * 0.20), width: w * 0.14, height: h * 0.52), Radius.circular(w * 0.07)), paint);
}
