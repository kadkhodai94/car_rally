#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / 'assets' / 'app_icon' / 'app_icon.png'
ANDROID = ROOT / 'android' / 'app' / 'src' / 'main'

if not SRC.exists():
    raise SystemExit(f'Icon source not found: {SRC}')

img = Image.open(SRC).convert('RGBA')
legacy_sizes = {
    'mipmap-mdpi': 48,
    'mipmap-hdpi': 72,
    'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144,
    'mipmap-xxxhdpi': 192,
}
for folder, size in legacy_sizes.items():
    out_dir = ANDROID / 'res' / folder
    out_dir.mkdir(parents=True, exist_ok=True)
    resized = img.resize((size, size), Image.Resampling.LANCZOS)
    resized.save(out_dir / 'ic_launcher.png')
    resized.save(out_dir / 'ic_launcher_round.png')

# Adaptive icon foreground/background
fg_dir = ANDROID / 'res' / 'drawable'
fg_dir.mkdir(parents=True, exist_ok=True)
fg_size = 432
img.resize((fg_size, fg_size), Image.Resampling.LANCZOS).save(fg_dir / 'ic_launcher_foreground.png')

values = ANDROID / 'res' / 'values'
values.mkdir(parents=True, exist_ok=True)
(values / 'ic_launcher_background.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#030713</color>\n</resources>\n''', encoding='utf-8')

anydpi = ANDROID / 'res' / 'mipmap-anydpi-v26'
anydpi.mkdir(parents=True, exist_ok=True)
xml = '''<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@drawable/ic_launcher_foreground"/>\n</adaptive-icon>\n'''
(anydpi / 'ic_launcher.xml').write_text(xml, encoding='utf-8')
(anydpi / 'ic_launcher_round.xml').write_text(xml, encoding='utf-8')

manifest = ANDROID / 'AndroidManifest.xml'
if manifest.exists():
    txt = manifest.read_text(encoding='utf-8')
    if 'android:icon=' in txt:
        import re
        txt = re.sub(r'android:icon="[^"]+"', 'android:icon="@mipmap/ic_launcher"', txt)
    else:
        txt = txt.replace('<application', '<application android:icon="@mipmap/ic_launcher"', 1)
    if 'android:roundIcon=' in txt:
        import re
        txt = re.sub(r'android:roundIcon="[^"]+"', 'android:roundIcon="@mipmap/ic_launcher_round"', txt)
    else:
        txt = txt.replace('<application', '<application android:roundIcon="@mipmap/ic_launcher_round"', 1)
    manifest.write_text(txt, encoding='utf-8')

print('Launcher icons applied.')
