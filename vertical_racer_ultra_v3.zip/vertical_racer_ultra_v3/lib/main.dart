import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: Color(0xFF030713),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const UltraRacerApp());
}

class UltraRacerApp extends StatelessWidget {
  const UltraRacerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'جاده بی‌پایان Ultra',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF030713),
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF20D6FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(),
      ),
    );
  }
}

class StorageKeys {
  static const highScore = 'ultra_vr_high_score';
  static const coins = 'ultra_vr_total_coins';
  static const bestLevel = 'ultra_vr_best_level';
  static const selectedCar = 'ultra_vr_selected_car';
}

class CarSkin {
  const CarSkin({required this.name, required this.top, required this.bottom, required this.accent, required this.price});

  final String name;
  final Color top;
  final Color bottom;
  final Color accent;
  final int price;
}

class CarSkins {
  static const all = <CarSkin>[
    CarSkin(name: 'آبی نئونی', top: Color(0xFF39E5FF), bottom: Color(0xFF118DFF), accent: Color(0xFFFFFF96), price: 0),
    CarSkin(name: 'قرمز توربو', top: Color(0xFFFF5277), bottom: Color(0xFFE01E37), accent: Color(0xFFFFD166), price: 180),
    CarSkin(name: 'بنفش اسپرت', top: Color(0xFF9B5CFF), bottom: Color(0xFF4E5CFF), accent: Color(0xFFFF6FD8), price: 260),
    CarSkin(name: 'سبز لیزری', top: Color(0xFF43F2B3), bottom: Color(0xFF06A66D), accent: Color(0xFFFFFFFF), price: 360),
    CarSkin(name: 'طلایی ویژه', top: Color(0xFFFFD166), bottom: Color(0xFFFF8C00), accent: Color(0xFFFFF2B0), price: 520),
  ];

  static const enemy = <CarSkin>[
    CarSkin(name: 'حریف', top: Color(0xFFFFB84D), bottom: Color(0xFFFF7A18), accent: Color(0xFFFF3E78), price: 0),
    CarSkin(name: 'حریف', top: Color(0xFF8C7BFF), bottom: Color(0xFF4D63FF), accent: Color(0xFFFF477E), price: 0),
    CarSkin(name: 'حریف', top: Color(0xFF53F3CF), bottom: Color(0xFF05B2DC), accent: Color(0xFFFFFFB3), price: 0),
    CarSkin(name: 'حریف', top: Color(0xFFFF6B9A), bottom: Color(0xFFE1306C), accent: Color(0xFFFFD166), price: 0),
  ];
}

BoxDecoration glass({double radius = 32, double opacity = 0.13, Color border = const Color(0x66FFFFFF)}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topRight,
      end: Alignment.bottomLeft,
      colors: [Colors.white.withOpacity(opacity + 0.045), Colors.white.withOpacity(opacity * 0.34)],
    ),
    border: Border.all(color: border.withOpacity(0.32)),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.34), blurRadius: 30, offset: const Offset(0, 18)),
      BoxShadow(color: const Color(0xFF20D6FF).withOpacity(0.05), blurRadius: 32, offset: const Offset(0, -6)),
    ],
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  int _highScore = 0;
  int _coins = 0;
  int _bestLevel = 1;
  int _selectedCar = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();
    _load();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _highScore = prefs.getInt(StorageKeys.highScore) ?? 0;
      _coins = prefs.getInt(StorageKeys.coins) ?? 0;
      _bestLevel = prefs.getInt(StorageKeys.bestLevel) ?? 1;
      _selectedCar = (prefs.getInt(StorageKeys.selectedCar) ?? 0).clamp(0, CarSkins.all.length - 1).toInt();
    });
  }

  Future<void> _start() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) {
      return Directionality(textDirection: TextDirection.rtl, child: GameScreen(carIndex: _selectedCar));
    }));
    await _load();
  }

  Future<void> _garage() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) {
      return const Directionality(textDirection: TextDirection.rtl, child: GarageScreen());
    }));
    await _load();
  }

  void _guide() {
    HapticFeedback.selectionClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            margin: const EdgeInsets.fromLTRB(14, 0, 14, 16),
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
            decoration: glass(radius: 30, opacity: 0.18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const Icon(Icons.info_rounded, color: Color(0xFFFFD166), size: 30),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('راهنمای سریع', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                  ],
                ),
                const SizedBox(height: 10),
                const GuideLine(icon: Icons.touch_app_rounded, title: 'کنترل', text: 'چپ یا راست صفحه را بزن تا ماشین نرم بین لاین‌ها جابه‌جا شود.'),
                const GuideLine(icon: Icons.speed_rounded, title: 'سختی', text: 'با بالا رفتن امتیاز، سرعت، تراکم ترافیک و الگوی موانع سنگین‌تر می‌شود.'),
                const GuideLine(icon: Icons.auto_awesome_rounded, title: 'آیتم‌ها', text: 'سکه، سپر، آهنربا و نیترو را بگیر. آیتم‌ها کوتاه‌مدت ولی اثرگذارند.'),
                const GuideLine(icon: Icons.emoji_events_rounded, title: 'هدف', text: 'زنده بمان، رکورد بزن، سکه جمع کن و ماشین‌های بهتر را باز کن.'),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final car = CarSkins.all[_selectedCar];
    return Scaffold(
      body: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: HomePainter(t: _controller.value))),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(child: HomeStat(title: 'رکورد', value: _highScore.toString(), icon: Icons.emoji_events_rounded)),
                          const SizedBox(width: 12),
                          Expanded(child: HomeStat(title: 'سکه', value: _coins.toString(), icon: Icons.monetization_on_rounded)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: HomeStat(title: 'بهترین مرحله', value: _bestLevel.toString(), icon: Icons.local_fire_department_rounded, compact: true)),
                          const SizedBox(width: 12),
                          Expanded(child: HomeStat(title: 'ماشین', value: car.name, icon: Icons.directions_car_rounded, compact: true)),
                        ],
                      ),
                      const Spacer(),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                        decoration: glass(radius: 38, opacity: 0.19),
                        child: Column(
                          children: [
                            const Text('جاده بی‌پایان', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, height: 1.05)),
                            const SizedBox(height: 8),
                            Text('مسابقه عمودی، سریع، روان و مرحله‌ای', style: TextStyle(fontSize: 16, color: Colors.white.withOpacity(0.72), fontWeight: FontWeight.w800)),
                            const SizedBox(height: 22),
                            SizedBox(
                              height: 220,
                              child: CustomPaint(
                                painter: HeroRoadPainter(t: _controller.value, skin: car),
                                child: const SizedBox.expand(),
                              ),
                            ),
                            const SizedBox(height: 20),
                            BigGradientButton(text: 'شروع بازی', icon: Icons.play_arrow_rounded, onTap: _start),
                            const SizedBox(height: 14),
                            Row(
                              children: [
                                Expanded(child: SecondaryButton(text: 'گاراژ', icon: Icons.garage_rounded, onTap: _garage)),
                                const SizedBox(width: 12),
                                Expanded(child: SecondaryButton(text: 'راهنما', icon: Icons.info_outline_rounded, onTap: _guide)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      Text('هدف: جاخالی بده، سکه جمع کن، رکورد بزن.', style: TextStyle(color: Colors.white.withOpacity(0.64), fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class HomeStat extends StatelessWidget {
  const HomeStat({super.key, required this.title, required this.value, required this.icon, this.compact = false});

  final String title;
  final String value;
  final IconData icon;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: compact ? 76 : 92,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: glass(radius: 24, opacity: 0.13),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFFFD166), size: compact ? 28 : 32),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.55), fontWeight: FontWeight.w800, fontSize: compact ? 12 : 13)),
                const SizedBox(height: 2),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 19 : 25, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BigGradientButton extends StatelessWidget {
  const BigGradientButton({super.key, required this.text, required this.icon, required this.onTap});
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onTap,
        child: Ink(
          height: 76,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(colors: [Color(0xFF32DAFF), Color(0xFF4B7BFF), Color(0xFF735CFF)]),
            boxShadow: [BoxShadow(color: const Color(0xFF36D8FF).withOpacity(0.28), blurRadius: 28, offset: const Offset(0, 14))],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(text, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(width: 12),
              Icon(icon, size: 34),
            ],
          ),
        ),
      ),
    );
  }
}

class SecondaryButton extends StatelessWidget {
  const SecondaryButton({super.key, required this.text, required this.icon, required this.onTap});
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(25),
        onTap: onTap,
        child: Ink(
          height: 62,
          decoration: glass(radius: 25, opacity: 0.12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(width: 8),
              Icon(icon, size: 25, color: Colors.white.withOpacity(0.78)),
            ],
          ),
        ),
      ),
    );
  }
}

class GuideLine extends StatelessWidget {
  const GuideLine({super.key, required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: Colors.white.withOpacity(0.07), border: Border.all(color: Colors.white.withOpacity(0.10))),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF36D8FF), size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 3),
                Text(text, style: TextStyle(color: Colors.white.withOpacity(0.68), height: 1.55, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class GarageScreen extends StatefulWidget {
  const GarageScreen({super.key});

  @override
  State<GarageScreen> createState() => _GarageScreenState();
}

class _GarageScreenState extends State<GarageScreen> {
  int _coins = 0;
  int _selected = 0;
  final Set<int> _owned = {0};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _coins = prefs.getInt(StorageKeys.coins) ?? 0;
      _selected = (prefs.getInt(StorageKeys.selectedCar) ?? 0).clamp(0, CarSkins.all.length - 1).toInt();
      for (var i = 0; i < CarSkins.all.length; i++) {
        if ((prefs.getBool('ultra_vr_owned_$i') ?? i == 0)) _owned.add(i);
      }
    });
  }

  Future<void> _selectOrBuy(int index) async {
    final prefs = await SharedPreferences.getInstance();
    final skin = CarSkins.all[index];
    if (_owned.contains(index)) {
      await prefs.setInt(StorageKeys.selectedCar, index);
      setState(() => _selected = index);
      HapticFeedback.selectionClick();
      return;
    }
    if (_coins < skin.price) {
      HapticFeedback.mediumImpact();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سکه کافی نداری.')));
      return;
    }
    _coins -= skin.price;
    _owned.add(index);
    _selected = index;
    await prefs.setInt(StorageKeys.coins, _coins);
    await prefs.setBool('ultra_vr_owned_$index', true);
    await prefs.setInt(StorageKeys.selectedCar, index);
    HapticFeedback.mediumImpact();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF142A66), Color(0xFF071024), Color(0xFF030713)])))),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                      const Expanded(child: Text('گاراژ', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: glass(radius: 20, opacity: 0.14),
                        child: Row(children: [const Icon(Icons.monetization_on_rounded, color: Color(0xFFFFD166)), const SizedBox(width: 6), Text(_coins.toString(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18))]),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: ListView.separated(
                      itemCount: CarSkins.all.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 14),
                      itemBuilder: (context, index) {
                        final skin = CarSkins.all[index];
                        final owned = _owned.contains(index);
                        final selected = _selected == index;
                        return Container(
                          padding: const EdgeInsets.all(16),
                          decoration: glass(radius: 28, opacity: selected ? 0.20 : 0.12, border: selected ? const Color(0xFF36D8FF) : Colors.white),
                          child: Row(
                            children: [
                              SizedBox(width: 92, height: 118, child: CustomPaint(painter: GarageCarPainter(skin: skin, selected: selected))),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(skin.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                                    const SizedBox(height: 6),
                                    Text(owned ? 'آماده مسابقه' : 'قیمت: ${skin.price} سکه', style: TextStyle(color: Colors.white.withOpacity(0.62), fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 14),
                                    SizedBox(
                                      height: 48,
                                      child: ElevatedButton.icon(
                                        onPressed: () => _selectOrBuy(index),
                                        icon: Icon(selected ? Icons.check_circle_rounded : owned ? Icons.directions_car_rounded : Icons.shopping_bag_rounded),
                                        label: Text(selected ? 'انتخاب شده' : owned ? 'انتخاب کن' : 'خرید'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: selected ? const Color(0xFF22C55E) : const Color(0xFF2F7BFF),
                                          foregroundColor: Colors.white,
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

enum ObjectKind { enemy, truck, cone, oil, coin, shield, magnet, nitro }

class GameObject {
  GameObject({required this.id, required this.kind, required this.lane, required this.y, required this.seed, this.speedFactor = 1.0});

  final int id;
  final ObjectKind kind;
  double lane;
  double y;
  final double seed;
  final double speedFactor;
  bool consumed = false;

  bool get isCollectible => kind == ObjectKind.coin || kind == ObjectKind.shield || kind == ObjectKind.magnet || kind == ObjectKind.nitro;
  bool get isHazard => !isCollectible;
}

class Particle {
  Particle({required this.p, required this.v, required this.life, required this.maxLife, required this.color, required this.size});

  Offset p;
  Offset v;
  double life;
  final double maxLife;
  final Color color;
  final double size;
}

class SpeedStreak {
  SpeedStreak(this.x, this.y, this.length, this.alpha);
  double x;
  double y;
  double length;
  double alpha;
}

class GameModel extends ChangeNotifier {
  GameModel({required this.carIndex, this.onGameOver});

  static const laneCount = 3;
  final int carIndex;
  final VoidCallback? onGameOver;
  final math.Random rng = math.Random();

  Size size = Size.zero;
  bool running = true;
  bool gameOver = false;
  bool saved = false;
  int nextId = 1;
  int playerLane = 1;
  double playerLaneVisual = 1;
  double roadOffset = 0;
  double score = 0;
  int coins = 0;
  int lives = 3;
  int highScore = 0;
  int totalCoinsBefore = 0;
  double obstacleTimer = 0.28;
  double coinTimer = 0.68;
  double powerTimer = 4.8;
  double hitCooldown = 0;
  double shieldTime = 0;
  double magnetTime = 0;
  double nitroTime = 0;
  double levelBanner = 0;
  double shake = 0;
  int lastLevel = 1;
  double elapsedTime = 0;

  final List<GameObject> objects = <GameObject>[];
  final List<Particle> particles = <Particle>[];
  final List<SpeedStreak> streaks = <SpeedStreak>[];

  int get level => math.max(1, (score ~/ 950) + 1);
  double get difficulty => ((level - 1) / 14.0).clamp(0.0, 1.0).toDouble();
  double get baseSpeed => 330 + level * 23 + score * 0.010 + (nitroTime > 0 ? 145 : 0);
  CarSkin get playerSkin => CarSkins.all[carIndex.clamp(0, CarSkins.all.length - 1).toInt()];

  void setSize(Size next) {
    if ((size.width - next.width).abs() < 0.5 && (size.height - next.height).abs() < 0.5) return;
    size = next;
  }

  void loadStats({required int high, required int totalCoins}) {
    highScore = high;
    totalCoinsBefore = totalCoins;
  }

  void tick(double dt) {
    if (!running || gameOver || size == Size.zero) return;
    elapsedTime += dt;
    final speed = baseSpeed;
    roadOffset = (roadOffset + speed * dt) % 176;
    score += dt * (48 + level * 5.8) * (nitroTime > 0 ? 1.55 : 1.0);
    final laneEase = 1 - math.pow(0.0008, dt).toDouble();
    playerLaneVisual += (playerLane - playerLaneVisual) * laneEase;

    if (level > lastLevel) {
      lastLevel = level;
      levelBanner = 1.35;
      _burst(Offset(size.width / 2, size.height * 0.25), const Color(0xFF36D8FF), 24);
      HapticFeedback.mediumImpact();
    }

    shieldTime = math.max(0, shieldTime - dt);
    magnetTime = math.max(0, magnetTime - dt);
    nitroTime = math.max(0, nitroTime - dt);
    hitCooldown = math.max(0, hitCooldown - dt);
    levelBanner = math.max(0, levelBanner - dt);
    shake = math.max(0, shake - dt * 7);

    obstacleTimer -= dt;
    coinTimer -= dt;
    powerTimer -= dt;

    if (obstacleTimer <= 0) {
      _spawnTrafficPattern();
      obstacleTimer = math.max(0.35, 1.0 - difficulty * 0.50 - rng.nextDouble() * 0.20);
    }
    if (coinTimer <= 0) {
      _spawnCoinTrail();
      coinTimer = math.max(0.62, 1.25 - difficulty * 0.28 + rng.nextDouble() * 0.22);
    }
    if (powerTimer <= 0) {
      _spawnPower();
      powerTimer = math.max(4.2, 7.4 - difficulty * 1.6 + rng.nextDouble() * 2.4);
    }

    _updateObjects(dt, speed);
    _updateParticles(dt);
    _updateSpeedStreaks(dt, speed);
    _collisions();
    objects.removeWhere((o) => o.consumed || o.y > size.height + 170);
    notifyListeners();
  }

  void _spawnTrafficPattern() {
    final top = -140.0;
    final lane = rng.nextInt(laneCount);
    final roll = rng.nextDouble();
    ObjectKind kind;
    if (roll < 0.16 + difficulty * 0.10) {
      kind = ObjectKind.truck;
    } else if (roll < 0.28 + difficulty * 0.08) {
      kind = ObjectKind.oil;
    } else if (roll < 0.40) {
      kind = ObjectKind.cone;
    } else {
      kind = ObjectKind.enemy;
    }
    objects.add(GameObject(id: nextId++, kind: kind, lane: lane.toDouble(), y: top, seed: rng.nextDouble() * math.pi * 2, speedFactor: kind == ObjectKind.truck ? 0.90 : 1.0));

    if (level >= 4 && rng.nextDouble() < 0.35) {
      final second = _differentLane(lane);
      final secondKind = rng.nextBool() ? ObjectKind.enemy : ObjectKind.cone;
      objects.add(GameObject(id: nextId++, kind: secondKind, lane: second.toDouble(), y: top - 180 - rng.nextDouble() * 70, seed: rng.nextDouble() * math.pi * 2));
    }
    if (level >= 8 && rng.nextDouble() < 0.18) {
      final lanes = [0, 1, 2]..shuffle(rng);
      for (var i = 0; i < 2; i++) {
        objects.add(GameObject(id: nextId++, kind: i == 0 ? ObjectKind.truck : ObjectKind.enemy, lane: lanes[i].toDouble(), y: top - 300 - i * 70, seed: rng.nextDouble() * math.pi * 2, speedFactor: i == 0 ? 0.90 : 1.0));
      }
    }
  }

  int _differentLane(int lane) {
    final offset = 1 + rng.nextInt(laneCount - 1);
    return (lane + offset) % laneCount;
  }

  void _spawnCoinTrail() {
    final lane = rng.nextInt(laneCount);
    final count = 4 + rng.nextInt(3);
    for (var i = 0; i < count; i++) {
      final zig = level >= 5 && rng.nextDouble() < 0.35 ? ((lane + (i % 2)) % laneCount) : lane;
      objects.add(GameObject(id: nextId++, kind: ObjectKind.coin, lane: zig.toDouble(), y: -95.0 - i * 54, seed: rng.nextDouble() * math.pi * 2));
    }
  }

  void _spawnPower() {
    final kinds = [ObjectKind.shield, ObjectKind.magnet, ObjectKind.nitro];
    objects.add(GameObject(id: nextId++, kind: kinds[rng.nextInt(kinds.length)], lane: rng.nextInt(laneCount).toDouble(), y: -120, seed: rng.nextDouble() * math.pi * 2));
  }

  void _updateObjects(double dt, double speed) {
    for (final o in objects) {
      o.y += speed * dt * o.speedFactor;
      if (level >= 6 && o.kind == ObjectKind.enemy) {
        o.lane += math.sin(elapsedTime * 1.4 + o.seed) * dt * 0.18;
        o.lane = o.lane.clamp(0.0, 2.0).toDouble();
      }
      if (magnetTime > 0 && o.kind == ObjectKind.coin) {
        final pc = playerCenter();
        final oc = itemCenter(o);
        final d = pc - oc;
        final distance = d.distance;
        if (distance < 210 && distance > 2) {
          final pull = math.min(430 * dt, distance);
          final next = oc + d / distance * pull;
          o.y = next.dy;
          final road = roadRect();
          o.lane = ((next.dx - road.left) / (road.width / laneCount) - 0.5).clamp(0.0, 2.0).toDouble();
        }
      }
    }
  }

  void _updateParticles(double dt) {
    for (final p in particles) {
      p.life -= dt;
      p.p += p.v * dt;
      p.v = Offset(p.v.dx * 0.92, p.v.dy * 0.92 + 18 * dt);
    }
    particles.removeWhere((p) => p.life <= 0);
  }

  void _updateSpeedStreaks(double dt, double speed) {
    if (streaks.length < 18 && rng.nextDouble() < (nitroTime > 0 ? 0.65 : 0.22)) {
      final road = roadRect();
      streaks.add(SpeedStreak(road.left + rng.nextDouble() * road.width, road.top - 30, 18 + rng.nextDouble() * 54 + level, 0.18 + rng.nextDouble() * 0.20));
    }
    for (final s in streaks) {
      s.y += speed * dt * 1.55;
      s.alpha *= 0.985;
    }
    streaks.removeWhere((s) => s.y > size.height + 80 || s.alpha < 0.025);
  }

  void _collisions() {
    final pr = playerRect();
    for (final o in objects) {
      if (o.consumed) continue;
      if (!pr.overlaps(itemRect(o))) continue;
      if (o.isCollectible) {
        o.consumed = true;
        _collect(o);
      } else if (hitCooldown <= 0) {
        o.consumed = true;
        _hit(o.kind);
      }
    }
  }

  void _collect(GameObject o) {
    final c = itemCenter(o);
    HapticFeedback.selectionClick();
    switch (o.kind) {
      case ObjectKind.coin:
        coins += magnetTime > 0 ? 2 : 1;
        score += magnetTime > 0 ? 38 : 24;
        _burst(c, const Color(0xFFFFD166), 10);
        break;
      case ObjectKind.shield:
        shieldTime = 7.0;
        score += 80;
        _burst(c, const Color(0xFF8B5CFF), 16);
        break;
      case ObjectKind.magnet:
        magnetTime = 7.5;
        score += 80;
        _burst(c, const Color(0xFF20D6FF), 16);
        break;
      case ObjectKind.nitro:
        nitroTime = 5.5;
        score += 100;
        _burst(c, const Color(0xFFFF3D9A), 20);
        break;
      default:
        break;
    }
  }

  void _hit(ObjectKind kind) {
    if (shieldTime > 0) {
      shieldTime = math.max(0, shieldTime - 2.0);
      hitCooldown = 0.75;
      shake = 0.55;
      HapticFeedback.lightImpact();
      _burst(playerCenter(), const Color(0xFF8B5CFF), 22);
      return;
    }
    lives -= kind == ObjectKind.oil ? 1 : 1;
    hitCooldown = 1.0;
    nitroTime = 0;
    shake = 1.0;
    HapticFeedback.heavyImpact();
    _burst(playerCenter(), const Color(0xFFFF4B5C), 30);
    if (lives <= 0) {
      running = false;
      gameOver = true;
      onGameOver?.call();
    }
  }

  void _burst(Offset center, Color color, int count) {
    for (var i = 0; i < count; i++) {
      final angle = rng.nextDouble() * math.pi * 2;
      final speed = 70 + rng.nextDouble() * 170;
      final life = 0.35 + rng.nextDouble() * 0.42;
      particles.add(Particle(p: center, v: Offset(math.cos(angle) * speed, math.sin(angle) * speed), life: life, maxLife: life, color: color, size: 2.0 + rng.nextDouble() * 4.2));
    }
  }

  void restart() {
    running = true;
    gameOver = false;
    saved = false;
    nextId = 1;
    playerLane = 1;
    playerLaneVisual = 1;
    roadOffset = 0;
    score = 0;
    coins = 0;
    lives = 3;
    obstacleTimer = 0.28;
    coinTimer = 0.68;
    powerTimer = 4.8;
    hitCooldown = 0;
    shieldTime = 0;
    magnetTime = 0;
    nitroTime = 0;
    levelBanner = 0;
    shake = 0;
    lastLevel = 1;
    elapsedTime = 0;
    objects.clear();
    particles.clear();
    streaks.clear();
    HapticFeedback.mediumImpact();
    notifyListeners();
  }

  void moveLeft() {
    if (!running || gameOver) return;
    if (playerLane > 0) {
      playerLane--;
      HapticFeedback.selectionClick();
    }
  }

  void moveRight() {
    if (!running || gameOver) return;
    if (playerLane < laneCount - 1) {
      playerLane++;
      HapticFeedback.selectionClick();
    }
  }

  Rect roadRect() {
    final safeTop = math.max(118.0, size.height * 0.105);
    return Rect.fromLTWH(size.width * 0.115, safeTop, size.width * 0.77, size.height - safeTop + 76);
  }

  Offset laneCenter(double lane, double y) {
    final road = roadRect();
    final laneWidth = road.width / laneCount;
    return Offset(road.left + laneWidth * (lane + 0.5), y);
  }

  Offset playerCenter() => laneCenter(playerLaneVisual, size.height * 0.785);

  Rect playerRect() => Rect.fromCenter(center: playerCenter(), width: 50, height: 84).deflate(7);

  Offset itemCenter(GameObject o) => laneCenter(o.lane, o.y);

  Rect itemRect(GameObject o) {
    final c = itemCenter(o);
    switch (o.kind) {
      case ObjectKind.truck:
        return Rect.fromCenter(center: c, width: 66, height: 112).deflate(8);
      case ObjectKind.enemy:
        return Rect.fromCenter(center: c, width: 56, height: 92).deflate(7);
      case ObjectKind.cone:
        return Rect.fromCenter(center: c, width: 46, height: 54).deflate(5);
      case ObjectKind.oil:
        return Rect.fromCenter(center: c, width: 58, height: 42).deflate(4);
      case ObjectKind.coin:
        return Rect.fromCircle(center: c, radius: 22);
      case ObjectKind.shield:
      case ObjectKind.magnet:
      case ObjectKind.nitro:
        return Rect.fromCircle(center: c, radius: 27);
    }
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.carIndex});

  final int carIndex;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  late final GameModel _game;
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  double _hudAccum = 0;
  int _hudPulse = 0;

  @override
  void initState() {
    super.initState();
    _game = GameModel(carIndex: widget.carIndex, onGameOver: _onGameOver);
    _loadStats();
    _ticker = createTicker(_tick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _game.dispose();
    super.dispose();
  }

  Future<void> _loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    _game.loadStats(high: prefs.getInt(StorageKeys.highScore) ?? 0, totalCoins: prefs.getInt(StorageKeys.coins) ?? 0);
    if (mounted) setState(() {});
  }

  void _tick(Duration elapsed) {
    if (_last == Duration.zero) {
      _last = elapsed;
      return;
    }
    final dt = ((elapsed - _last).inMicroseconds / 1000000.0).clamp(0.0, 0.026).toDouble();
    _last = elapsed;
    _game.tick(dt);
    _hudAccum += dt;
    if (_hudAccum >= 0.12 && mounted) {
      _hudAccum = 0;
      _hudPulse++;
      setState(() {});
    }
  }

  Future<void> _onGameOver() async {
    await _saveResult();
    if (mounted) setState(() {});
  }

  Future<void> _saveResult() async {
    if (_game.saved) return;
    _game.saved = true;
    final prefs = await SharedPreferences.getInstance();
    final finalScore = _game.score.floor();
    final oldHigh = prefs.getInt(StorageKeys.highScore) ?? 0;
    final oldCoins = prefs.getInt(StorageKeys.coins) ?? 0;
    final oldBest = prefs.getInt(StorageKeys.bestLevel) ?? 1;
    if (finalScore > oldHigh) await prefs.setInt(StorageKeys.highScore, finalScore);
    await prefs.setInt(StorageKeys.coins, oldCoins + _game.coins);
    if (_game.level > oldBest) await prefs.setInt(StorageKeys.bestLevel, _game.level);
  }

  Future<void> _home() async {
    await _saveResult();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) {
        if (didPop) unawaited(_saveResult());
      },
      child: Scaffold(
        body: LayoutBuilder(
          builder: (context, constraints) {
            _game.setSize(Size(constraints.maxWidth, constraints.maxHeight));
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (details) {
                if (_game.gameOver) return;
                if (details.localPosition.dy > constraints.maxHeight - 145) return;
                if (details.localPosition.dx < constraints.maxWidth / 2) {
                  _game.moveLeft();
                } else {
                  _game.moveRight();
                }
              },
              child: Stack(
                children: [
                  Positioned.fill(
                    child: RepaintBoundary(
                      child: CustomPaint(painter: GamePainter(_game)),
                    ),
                  ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                      child: Column(
                        children: [
                          GameHud(game: _game, pulse: _hudPulse),
                          const Spacer(),
                          PowerRail(game: _game),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              ControlButton(icon: Icons.chevron_left_rounded, onTap: _game.moveLeft),
                              ControlButton(icon: Icons.chevron_right_rounded, onTap: _game.moveRight),
                            ],
                          ),
                          const SizedBox(height: 14),
                        ],
                      ),
                    ),
                  ),
                  if (_game.levelBanner > 0)
                    Positioned(
                      top: math.max(150, constraints.maxHeight * 0.20),
                      left: 38,
                      right: 38,
                      child: IgnorePointer(
                        child: Opacity(
                          opacity: math.min(1, _game.levelBanner / 0.28),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                            decoration: glass(radius: 26, opacity: 0.18),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.local_fire_department_rounded, color: Color(0xFFFFD166), size: 30),
                                const SizedBox(width: 10),
                                Text('مرحله ${_game.level}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                                const SizedBox(width: 8),
                                Text('سرعت بیشتر شد', style: TextStyle(color: Colors.white.withOpacity(0.68), fontWeight: FontWeight.w800)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (_game.gameOver)
                    Positioned.fill(
                      child: GameOverPanel(
                        score: _game.score.floor(),
                        coins: _game.coins,
                        level: _game.level,
                        record: _game.score.floor() > _game.highScore,
                        totalCoins: _game.totalCoinsBefore + _game.coins,
                        onRestart: () {
                          _game.restart();
                          _last = Duration.zero;
                          setState(() {});
                        },
                        onHome: _home,
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class GameHud extends StatelessWidget {
  const GameHud({super.key, required this.game, required this.pulse});
  final GameModel game;
  final int pulse;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 9),
      decoration: glass(radius: 27, opacity: 0.105),
      child: Row(
        children: [
          Expanded(child: HudCell(icon: Icons.speed_rounded, title: 'امتیاز', value: game.score.floor().toString())),
          Expanded(child: HudCell(icon: Icons.monetization_on_rounded, title: 'سکه', value: game.coins.toString())),
          Expanded(child: HudCell(icon: Icons.local_fire_department_rounded, title: 'مرحله', value: game.level.toString())),
          Expanded(child: HudCell(icon: Icons.emoji_events_rounded, title: 'رکورد', value: math.max(game.highScore, game.score.floor()).toString())),
          SizedBox(
            width: 62,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (i) => Icon(i < game.lives ? Icons.favorite_rounded : Icons.favorite_border_rounded, size: 17, color: i < game.lives ? const Color(0xFFFF4FA3) : Colors.white.withOpacity(0.33))),
            ),
          ),
        ],
      ),
    );
  }
}

class HudCell extends StatelessWidget {
  const HudCell({super.key, required this.icon, required this.title, required this.value});
  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: const Color(0xFFFFD166), size: 21),
        const SizedBox(height: 3),
        Text(title, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.56), fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class PowerRail extends StatelessWidget {
  const PowerRail({super.key, required this.game});
  final GameModel game;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        PowerPill(title: 'سپر', icon: Icons.shield_rounded, seconds: game.shieldTime, activeColor: const Color(0xFF8B5CFF)),
        const SizedBox(width: 8),
        PowerPill(title: 'آهنربا', icon: Icons.auto_awesome_rounded, seconds: game.magnetTime, activeColor: const Color(0xFF20D6FF)),
        const SizedBox(width: 8),
        PowerPill(title: 'نیترو', icon: Icons.bolt_rounded, seconds: game.nitroTime, activeColor: const Color(0xFFFF3D9A)),
      ],
    );
  }
}

class PowerPill extends StatelessWidget {
  const PowerPill({super.key, required this.title, required this.icon, required this.seconds, required this.activeColor});
  final String title;
  final IconData icon;
  final double seconds;
  final Color activeColor;

  @override
  Widget build(BuildContext context) {
    final active = seconds > 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: active ? activeColor.withOpacity(0.18) : Colors.black.withOpacity(0.22),
        border: Border.all(color: active ? activeColor.withOpacity(0.60) : Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 17, color: active ? const Color(0xFFFFD166) : Colors.white.withOpacity(0.34)),
          const SizedBox(width: 5),
          Text(active ? '${seconds.ceil()}s' : title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: active ? Colors.white : Colors.white.withOpacity(0.38))),
        ],
      ),
    );
  }
}

class ControlButton extends StatelessWidget {
  const ControlButton({super.key, required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 118,
        height: 82,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Colors.white.withOpacity(0.20), Colors.white.withOpacity(0.070)]),
          border: Border.all(color: Colors.white.withOpacity(0.18)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.32), blurRadius: 22, offset: const Offset(0, 13))],
        ),
        child: Icon(icon, size: 54, color: Colors.white.withOpacity(0.96)),
      ),
    );
  }
}

class GameOverPanel extends StatelessWidget {
  const GameOverPanel({super.key, required this.score, required this.coins, required this.level, required this.record, required this.totalCoins, required this.onRestart, required this.onHome});
  final int score;
  final int coins;
  final int level;
  final bool record;
  final int totalCoins;
  final VoidCallback onRestart;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.62),
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
          decoration: glass(radius: 34, opacity: 0.18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(record ? Icons.emoji_events_rounded : Icons.flag_rounded, color: record ? const Color(0xFFFFD166) : const Color(0xFF36D8FF), size: 48),
              const SizedBox(height: 8),
              Text(record ? 'رکورد جدید!' : 'بازی تمام شد', style: const TextStyle(fontSize: 31, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('امتیاز نهایی: $score', style: TextStyle(color: Colors.white.withOpacity(0.72), fontWeight: FontWeight.w800)),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: ResultBox(title: 'سکه این بازی', value: coins.toString(), icon: Icons.monetization_on_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: ResultBox(title: 'مرحله', value: level.toString(), icon: Icons.local_fire_department_rounded)),
                  const SizedBox(width: 10),
                  Expanded(child: ResultBox(title: 'کل سکه', value: totalCoins.toString(), icon: Icons.account_balance_wallet_rounded)),
                ],
              ),
              const SizedBox(height: 20),
              BigGradientButton(text: 'دوباره بازی کن', icon: Icons.replay_rounded, onTap: onRestart),
              const SizedBox(height: 12),
              SecondaryButton(text: 'صفحه اصلی', icon: Icons.home_rounded, onTap: onHome),
            ],
          ),
        ),
      ),
    );
  }
}

class ResultBox extends StatelessWidget {
  const ResultBox({super.key, required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.white.withOpacity(0.075), border: Border.all(color: Colors.white.withOpacity(0.08))),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFFFD166), size: 24),
          const SizedBox(height: 5),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.55), fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class GamePainter extends CustomPainter {
  GamePainter(this.game) : super(repaint: game);
  final GameModel game;

  @override
  void paint(Canvas canvas, Size size) {
    final shakeOffset = game.shake > 0 ? Offset(math.sin(game.elapsedTime * 72) * game.shake * 2.4, math.cos(game.elapsedTime * 63) * game.shake * 1.6) : Offset.zero;
    canvas.save();
    canvas.translate(shakeOffset.dx, shakeOffset.dy);
    _background(canvas, size);
    final road = game.roadRect();
    _road(canvas, size, road);
    _objects(canvas, road, size);
    _player(canvas, road, size);
    _particles(canvas);
    _vignette(canvas, size);
    canvas.restore();
  }

  void _background(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF182E72), Color(0xFF081532), Color(0xFF030713)]).createShader(rect));

    final glow = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30);
    glow.color = const Color(0xFF20D6FF).withOpacity(0.10);
    canvas.drawCircle(Offset(size.width * 0.18, size.height * 0.46), 128, glow);
    glow.color = const Color(0xFF7B61FF).withOpacity(0.10);
    canvas.drawCircle(Offset(size.width * 0.88, size.height * 0.29), 154, glow);

    final side = Paint()..color = Colors.white.withOpacity(0.052);
    final neon = Paint()..color = const Color(0xFF20D6FF).withOpacity(0.14);
    for (var i = -1; i < 9; i++) {
      final y = ((i * 142 + game.roadOffset * 0.50) % (size.height + 190)) - 95;
      canvas.drawCircle(Offset(size.width * 0.060, y), 22, side);
      canvas.drawCircle(Offset(size.width * 0.940, y + 69), 22, side);
      canvas.drawCircle(Offset(size.width * 0.060, y), 8, neon);
      canvas.drawCircle(Offset(size.width * 0.940, y + 69), 8, neon);
    }
  }

  void _road(Canvas canvas, Size size, Rect road) {
    final r = RRect.fromRectAndRadius(road, const Radius.circular(34));
    final shadow = Paint()..color = Colors.black.withOpacity(0.38)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22);
    canvas.drawRRect(r.shift(const Offset(0, 10)), shadow);

    final roadPaint = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF253451), Color(0xFF141D31), Color(0xFF0D1424)]).createShader(road);
    canvas.drawRRect(r, roadPaint);

    final laneW = road.width / 3;
    final centerLight = Paint()..shader = RadialGradient(colors: [const Color(0xFF20D6FF).withOpacity(0.125), Colors.transparent], stops: const [0, 1]).createShader(Rect.fromCircle(center: Offset(road.center.dx, size.height * 0.70), radius: road.width * 0.90));
    canvas.drawRRect(r, centerLight);

    final edgeGlow = Paint()..strokeWidth = 6..strokeCap = StrokeCap.round..color = const Color(0xFF20D6FF).withOpacity(game.nitroTime > 0 ? 0.70 : 0.52)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
    canvas.drawLine(Offset(road.left + 4, road.top), Offset(road.left + 4, road.bottom), edgeGlow);
    canvas.drawLine(Offset(road.right - 4, road.top), Offset(road.right - 4, road.bottom), edgeGlow);
    final edge = Paint()..strokeWidth = 2..strokeCap = StrokeCap.round..color = const Color(0xFF65EAFF).withOpacity(0.62);
    canvas.drawLine(Offset(road.left + 4, road.top), Offset(road.left + 4, road.bottom), edge);
    canvas.drawLine(Offset(road.right - 4, road.top), Offset(road.right - 4, road.bottom), edge);

    final dash = Paint()..color = Colors.white.withOpacity(0.58)..style = PaintingStyle.fill;
    final dashGlow = Paint()..color = Colors.white.withOpacity(0.12)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    for (var lane = 1; lane <= 2; lane++) {
      final x = road.left + laneW * lane;
      for (double y = road.top - 220 + game.roadOffset; y < road.bottom + 160; y += 176) {
        final rrGlow = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, y + 35), width: 12, height: 76), const Radius.circular(8));
        final rr = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, y + 35), width: 6, height: 70), const Radius.circular(8));
        canvas.drawRRect(rrGlow, dashGlow);
        canvas.drawRRect(rr, dash);
      }
    }

    final streakPaint = Paint()..strokeCap = StrokeCap.round;
    for (final s in game.streaks) {
      streakPaint.color = Colors.white.withOpacity(s.alpha);
      streakPaint.strokeWidth = game.nitroTime > 0 ? 3 : 2;
      canvas.drawLine(Offset(s.x, s.y), Offset(s.x, s.y + s.length), streakPaint);
    }
  }

  void _objects(Canvas canvas, Rect road, Size size) {
    for (final o in game.objects) {
      if (o.y < -170 || o.y > size.height + 170) continue;
      final c = game.itemCenter(o);
      switch (o.kind) {
        case ObjectKind.enemy:
          _car(canvas, c, CarSkins.enemy[(o.id + game.level) % CarSkins.enemy.length], 0.98, enemy: true, nitro: false);
          break;
        case ObjectKind.truck:
          _truck(canvas, c);
          break;
        case ObjectKind.cone:
          _cone(canvas, c);
          break;
        case ObjectKind.oil:
          _oil(canvas, c);
          break;
        case ObjectKind.coin:
          _coin(canvas, c, o.seed + game.elapsedTime * 3);
          break;
        case ObjectKind.shield:
          _power(canvas, c, const Color(0xFF8B5CFF), 'S');
          break;
        case ObjectKind.magnet:
          _power(canvas, c, const Color(0xFF20D6FF), 'M');
          break;
        case ObjectKind.nitro:
          _power(canvas, c, const Color(0xFFFF3D9A), 'N');
          break;
      }
    }
  }

  void _player(Canvas canvas, Rect road, Size size) {
    final c = game.playerCenter();
    final blink = game.hitCooldown > 0 && (game.hitCooldown * 18).floor().isEven;
    if (game.shieldTime > 0 || game.magnetTime > 0 || game.nitroTime > 0) {
      final color = game.shieldTime > 0 ? const Color(0xFF8B5CFF) : game.magnetTime > 0 ? const Color(0xFF20D6FF) : const Color(0xFFFF3D9A);
      final aura = Paint()..style = PaintingStyle.stroke..strokeWidth = game.magnetTime > 0 ? 3.0 : 4.0..color = color.withOpacity(0.55)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
      canvas.drawCircle(c, game.magnetTime > 0 ? 72 : 56, aura);
    }
    if (!blink) _car(canvas, c, game.playerSkin, 1.08, enemy: false, nitro: game.nitroTime > 0);
  }

  void _particles(Canvas canvas) {
    for (final p in game.particles) {
      final alpha = (p.life / p.maxLife).clamp(0.0, 1.0).toDouble();
      canvas.drawCircle(p.p, p.size * (0.45 + alpha), Paint()..color = p.color.withOpacity(alpha));
    }
  }

  void _vignette(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..shader = RadialGradient(center: Alignment.center, radius: 1.0, colors: [Colors.transparent, Colors.black.withOpacity(0.40)], stops: const [0.62, 1.0]).createShader(Offset.zero & size));
  }

  void _car(Canvas canvas, Offset center, CarSkin skin, double scale, {required bool enemy, required bool nitro}) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);
    final shadow = Paint()..color = skin.bottom.withOpacity(enemy ? 0.18 : 0.24)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-31, -42, 62, 92).shift(const Offset(0, 10)), const Radius.circular(25)), shadow);

    if (nitro) {
      final flamePaint = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFD166), Color(0xFFFF3D9A), Colors.transparent]).createShader(const Rect.fromLTWH(-18, 38, 36, 64));
      final flame = Path()..moveTo(-15, 38)..cubicTo(-8, 62, -3, 78, 0, 96)..cubicTo(4, 78, 9, 62, 15, 38)..cubicTo(5, 49, -5, 49, -15, 38);
      canvas.drawPath(flame, flamePaint);
    }

    final bodyRect = const Rect.fromLTWH(-31, -49, 62, 98);
    final body = RRect.fromRectAndRadius(bodyRect, const Radius.circular(27));
    canvas.drawRRect(body, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [skin.top, skin.bottom]).createShader(bodyRect));
    canvas.drawRRect(body, Paint()..shader = LinearGradient(begin: Alignment.centerLeft, end: Alignment.centerRight, colors: [Colors.white.withOpacity(0.20), Colors.transparent, Colors.white.withOpacity(0.11)]).createShader(bodyRect));

    final hood = Path()..moveTo(-20, -34)..quadraticBezierTo(0, -48, 20, -34)..lineTo(15, -20)..quadraticBezierTo(0, -27, -15, -20)..close();
    canvas.drawPath(hood, Paint()..color = Colors.white.withOpacity(0.12));

    final cabin = RRect.fromRectAndRadius(const Rect.fromLTWH(-20, -28, 40, 40), const Radius.circular(14));
    canvas.drawRRect(cabin, Paint()..color = const Color(0xFF111B34).withOpacity(0.90));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-10, -9, 20, 44), const Radius.circular(10)), Paint()..color = Colors.white.withOpacity(0.37));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-4, -42, 8, 74), const Radius.circular(8)), Paint()..color = skin.accent.withOpacity(0.72));

    final light = Paint()..color = enemy ? const Color(0xFFFF4FA3) : skin.accent;
    canvas.drawCircle(const Offset(-16, -40), 7, light);
    canvas.drawCircle(const Offset(16, -40), 7, light);
    final wheel = Paint()..color = const Color(0xFF02050C);
    for (final x in [-36.0, 36.0]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 6, -34, 12, 29), const Radius.circular(8)), wheel);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 6, 13, 12, 29), const Radius.circular(8)), wheel);
    }
    canvas.restore();
  }

  void _truck(Canvas canvas, Offset center) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    final bodyRect = const Rect.fromLTWH(-37, -62, 74, 124);
    canvas.drawRRect(RRect.fromRectAndRadius(bodyRect.shift(const Offset(0, 9)), const Radius.circular(21)), Paint()..color = Colors.black.withOpacity(0.30)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12));
    canvas.drawRRect(RRect.fromRectAndRadius(bodyRect, const Radius.circular(20)), Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFD166), Color(0xFFFF8C00)]).createShader(bodyRect));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-25, -45, 50, 35), const Radius.circular(12)), Paint()..color = const Color(0xFF121C34).withOpacity(0.92));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-24, 4, 48, 46), const Radius.circular(9)), Paint()..color = Colors.white.withOpacity(0.13));
    final wheel = Paint()..color = const Color(0xFF02050C);
    for (final x in [-41.0, 41.0]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 7, -42, 14, 34), const Radius.circular(8)), wheel);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 7, 22, 14, 34), const Radius.circular(8)), wheel);
    }
    canvas.restore();
  }

  void _cone(Canvas canvas, Offset c) {
    canvas.save();
    canvas.translate(c.dx, c.dy);
    final path = Path()..moveTo(0, -30)..lineTo(-27, 25)..lineTo(27, 25)..close();
    canvas.drawPath(path.shift(const Offset(0, 7)), Paint()..color = Colors.black.withOpacity(0.22)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
    canvas.drawPath(path, Paint()..shader = const LinearGradient(colors: [Color(0xFFFFD166), Color(0xFFFF6B35)]).createShader(const Rect.fromLTWH(-27, -30, 54, 55)));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-16, -1, 32, 6), const Radius.circular(4)), Paint()..color = Colors.white.withOpacity(0.78));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-22, 20, 44, 8), const Radius.circular(4)), Paint()..color = const Color(0xFF10182E));
    canvas.restore();
  }

  void _oil(Canvas canvas, Offset c) {
    final rect = Rect.fromCenter(center: c, width: 62, height: 40);
    final path = Path()..addOval(rect)..addOval(Rect.fromCenter(center: c + const Offset(18, -3), width: 36, height: 28));
    canvas.drawPath(path.shift(const Offset(0, 4)), Paint()..color = Colors.black.withOpacity(0.28)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
    canvas.drawPath(path, Paint()..shader = const RadialGradient(colors: [Color(0xFF596DFF), Color(0xFF070B18)]).createShader(rect.inflate(20)));
    canvas.drawCircle(c + const Offset(-12, -6), 5, Paint()..color = Colors.white.withOpacity(0.22));
  }

  void _coin(Canvas canvas, Offset c, double t) {
    final pulse = 1 + math.sin(t) * 0.045;
    canvas.drawCircle(c, 25 * pulse, Paint()..color = const Color(0xFFFFD166).withOpacity(0.20)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9));
    canvas.drawCircle(c, 18 * pulse, Paint()..color = const Color(0xFFFFD166));
    canvas.drawCircle(c, 13 * pulse, Paint()..color = const Color(0xFFFFB703));
    canvas.drawCircle(c, 5 * pulse, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = const Color(0xFF7C4A00).withOpacity(0.55));
  }

  void _power(Canvas canvas, Offset c, Color color, String label) {
    canvas.drawCircle(c, 30, Paint()..color = color.withOpacity(0.22)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawCircle(c, 24, Paint()..shader = RadialGradient(colors: [Colors.white.withOpacity(0.30), color]).createShader(Rect.fromCircle(center: c, radius: 24)));
    final tp = TextPainter(text: TextSpan(text: label, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Colors.white)), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant GamePainter oldDelegate) => identical(oldDelegate.game, game) == false;
}

class HomePainter extends CustomPainter {
  const HomePainter({required this.t});
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1A347C), Color(0xFF0A1431), Color(0xFF030713)]).createShader(rect));
    final p = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40);
    p.color = const Color(0xFF20D6FF).withOpacity(0.12);
    canvas.drawCircle(Offset(size.width * (0.15 + 0.04 * math.sin(t * math.pi * 2)), size.height * 0.23), 140, p);
    p.color = const Color(0xFF7B61FF).withOpacity(0.12);
    canvas.drawCircle(Offset(size.width * 0.86, size.height * (0.42 + 0.04 * math.cos(t * math.pi * 2))), 168, p);
    p.color = const Color(0xFFFFD166).withOpacity(0.07);
    canvas.drawCircle(Offset(size.width * 0.22, size.height * 0.82), 160, p);
  }

  @override
  bool shouldRepaint(covariant HomePainter oldDelegate) => oldDelegate.t != t;
}

class HeroRoadPainter extends CustomPainter {
  const HeroRoadPainter({required this.t, required this.skin});
  final double t;
  final CarSkin skin;

  @override
  void paint(Canvas canvas, Size size) {
    final road = Rect.fromCenter(center: size.center(Offset.zero), width: size.width * 0.54, height: size.height * 0.92);
    final r = RRect.fromRectAndRadius(road, const Radius.circular(30));
    canvas.drawRRect(r, Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF263553), Color(0xFF10192E)]).createShader(road));
    final dash = Paint()..color = Colors.white.withOpacity(0.58)..strokeWidth = 6..strokeCap = StrokeCap.round;
    for (double y = road.top - 120 + (t * 180) % 180; y < road.bottom + 120; y += 88) {
      canvas.drawLine(Offset(road.center.dx, y), Offset(road.center.dx, y + 38), dash);
    }
    GamePainter(_HeroModel(size, road, skin))._car(canvas, road.center.translate(0, 20), skin, 1.04, enemy: false, nitro: false);
  }

  @override
  bool shouldRepaint(covariant HeroRoadPainter oldDelegate) => oldDelegate.t != t || oldDelegate.skin != skin;
}

class _HeroModel extends GameModel {
  _HeroModel(Size s, Rect r, CarSkin skin) : _skin = skin, _road = r, super(carIndex: 0) { size = s; }
  final CarSkin _skin;
  final Rect _road;
  @override
  CarSkin get playerSkin => _skin;
  @override
  Rect roadRect() => _road;
}

class GarageCarPainter extends CustomPainter {
  const GarageCarPainter({required this.skin, required this.selected});
  final CarSkin skin;
  final bool selected;

  @override
  void paint(Canvas canvas, Size size) {
    final glow = Paint()..color = (selected ? const Color(0xFF20D6FF) : skin.bottom).withOpacity(selected ? 0.24 : 0.12)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);
    canvas.drawCircle(size.center(Offset.zero), 44, glow);
    GamePainter(_HeroModel(size, Rect.fromLTWH(0, 0, size.width, size.height), skin))._car(canvas, size.center(Offset.zero), skin, 0.92, enemy: false, nitro: selected);
  }

  @override
  bool shouldRepaint(covariant GarageCarPainter oldDelegate) => oldDelegate.skin != skin || oldDelegate.selected != selected;
}
