#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

ROOT = Path.cwd()
SRC = ROOT / 'assets' / 'app_icon' / 'app_icon.png'
ANDROID = ROOT / 'android' / 'app' / 'src' / 'main'

if not SRC.exists():
    raise SystemExit('app icon not found: ' + str(SRC))

sizes = {
    'mipmap-mdpi': 48,
    'mipmap-hdpi': 72,
    'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144,
    'mipmap-xxxhdpi': 192,
}

img = Image.open(SRC).convert('RGBA')
for folder, size in sizes.items():
    out_dir = ANDROID / 'res' / folder
    out_dir.mkdir(parents=True, exist_ok=True)
    resized = img.resize((size, size), Image.LANCZOS)
    resized.save(out_dir / 'ic_launcher.png')
    resized.save(out_dir / 'ic_launcher_round.png')

anydpi = ANDROID / 'res' / 'mipmap-anydpi-v26'
anydpi.mkdir(parents=True, exist_ok=True)
(anydpi / 'ic_launcher.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
''', encoding='utf-8')
(anydpi / 'ic_launcher_round.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
''', encoding='utf-8')

values = ANDROID / 'res' / 'values'
values.mkdir(parents=True, exist_ok=True)
colors = values / 'colors.xml'
if colors.exists():
    text = colors.read_text(encoding='utf-8')
    if 'ic_launcher_background' not in text:
        text = text.replace('</resources>', '    <color name="ic_launcher_background">#030713</color>\n</resources>')
        colors.write_text(text, encoding='utf-8')
else:
    colors.write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#030713</color>
</resources>
''', encoding='utf-8')

foreground = img.resize((432, 432), Image.LANCZOS)
for folder in sizes:
    out_dir = ANDROID / 'res' / folder
    foreground.resize((sizes[folder], sizes[folder]), Image.LANCZOS).save(out_dir / 'ic_launcher_foreground.png')

manifest = ANDROID / 'AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    import re
    text = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', text)
    if 'android:roundIcon=' in text:
        text = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/ic_launcher_round"', text)
    else:
        text = text.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"')
    manifest.write_text(text, encoding='utf-8')

print('Launcher icons applied.')
