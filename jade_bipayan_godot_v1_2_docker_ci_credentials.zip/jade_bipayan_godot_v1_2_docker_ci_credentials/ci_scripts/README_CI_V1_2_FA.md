# توضیح CI نسخه v1.2

این نسخه از Docker image آماده `barichello/godot-ci:4.3` استفاده می‌کند و دیگر Godot/Android SDK را دستی روی runner نصب نمی‌کند.

اصلاح کلیدی این نسخه:

- بعد از warm up، فایل `.godot/export_credentials.cfg` ساخته می‌شود.
- همزمان خطوط keystore/debug داخل `export_presets.cfg` هم patch می‌شوند.
- preset اندروید با نام `Android` نگه داشته شده تا با نمونه‌های رایج Godot CI سازگارتر باشد.

اگر دوباره خطا رخ داد، artifact لاگ با نام `jade-bipayan-godot-logs` را دانلود کن و فایل `godot-android-export.log` را بفرست.
