# جاده بی‌پایان - Godot v1.2 Docker CI Credentials Fixed

این نسخه ادامه v1 است و تمرکزش روی اصلاح خروجی گرفتن با GitHub Actions است.

## امکانات بازی

- بازی ماشینی عمودی و بی‌پایان
- حرکت با لمس سمت چپ/راست صفحه یا کلیدهای جهت‌دار
- ماشین‌های دشمن
- برخورد و پایان بازی
- افزایش سختی با بالا رفتن امتیاز
- رکورد آفلاین داخل گوشی
- سکه داخل جاده
- پاداش سکه بعد از پایان بازی
- فروشگاه ماشین و ذخیره ماشین انتخابی

## اصلاحات CI در v1.1

- حذف وابستگی به preset ناقص نسخه قبل
- بازنویسی خودکار `export_presets.cfg` داخل workflow
- ساخت debug keystore داخل GitHub Actions
- تنظیم Android SDK/JDK داخل Editor Settings
- تلاش اول با Android Template مستقیم
- تلاش دوم خودکار با Gradle Build Template در صورت خطای export مستقیم
- ساخت خروجی APK و Web به‌صورت Artifact

## نحوه استفاده

1. ZIP را در ریشه ریپوی GitHub بگذار.
2. workflow مسیر `.github/workflows/build-godot-latest-zip.yml` را داخل ریپو داشته باش.
3. از تب Actions اجرا کن.
4. بعد از پایان، APK را از Artifacts دانلود کن.

## نکته

این نسخه خروجی debug APK برای تست می‌سازد. برای انتشار بازار/مایکت باید نسخه release با keystore واقعی جدا تنظیم شود.


## اصلاحات v1.2

- استفاده از Docker image آماده Godot CI به‌جای نصب دستی Godot/SDK روی runner.
- ساخت فایل `.godot/export_credentials.cfg` در زمان build برای حل مشکل credentialهای Godot 4.3.
- patch همزمان keystore داخل `export_presets.cfg` برای سازگاری با export CLI.
- نگه داشتن preset اندروید با نام ساده `Android`.
- خروجی APK از Artifact با نام `jade-bipayan-android-apk`.
