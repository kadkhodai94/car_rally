#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
ICON = ROOT / 'assets' / 'app_icon' / 'app_icon.png'
ANDROID = ROOT / 'android' / 'app' / 'src' / 'main'

if not ICON.exists():
    raise SystemExit(f'Icon not found: {ICON}')
if not ANDROID.exists():
    print('Android project not found yet; skipping launcher icon patch.')
    raise SystemExit(0)

sizes = {
    'mipmap-mdpi': 48,
    'mipmap-hdpi': 72,
    'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144,
    'mipmap-xxxhdpi': 192,
}

img = Image.open(ICON).convert('RGBA')
for folder, size in sizes.items():
    out_dir = ANDROID / 'res' / folder
    out_dir.mkdir(parents=True, exist_ok=True)
    resized = img.resize((size, size), Image.LANCZOS)
    resized.save(out_dir / 'ic_launcher.png')
    resized.save(out_dir / 'ic_launcher_round.png')

anydpi = ANDROID / 'res' / 'mipmap-anydpi-v26'
anydpi.mkdir(parents=True, exist_ok=True)
(anydpi / 'ic_launcher.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
''', encoding='utf-8')
(anydpi / 'ic_launcher_round.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
''', encoding='utf-8')

values = ANDROID / 'res' / 'values'
values.mkdir(parents=True, exist_ok=True)
colors = values / 'colors.xml'
if colors.exists():
    text = colors.read_text(encoding='utf-8')
    if 'ic_launcher_background' not in text:
        text = text.replace('</resources>', '    <color name="ic_launcher_background">#050816</color>\n</resources>')
        colors.write_text(text, encoding='utf-8')
else:
    colors.write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#050816</color>
</resources>
''', encoding='utf-8')

# Foreground image for adaptive icon.
fg_size = 432
for folder, base in sizes.items():
    out_dir = ANDROID / 'res' / folder
    size = int(base * 108 / 48)
    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    icon_size = int(size * 0.72)
    icon = img.resize((icon_size, icon_size), Image.LANCZOS)
    canvas.alpha_composite(icon, ((size - icon_size) // 2, (size - icon_size) // 2))
    canvas.save(out_dir / 'ic_launcher_foreground.png')

manifest = ANDROID / 'AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    import re
    if 'android:icon=' in text:
        text = re.sub(r'android:icon="[^"]+"', 'android:icon="@mipmap/ic_launcher"', text)
    else:
        text = text.replace('<application', '<application android:icon="@mipmap/ic_launcher"', 1)
    if 'android:roundIcon=' in text:
        text = re.sub(r'android:roundIcon="[^"]+"', 'android:roundIcon="@mipmap/ic_launcher_round"', text)
    else:
        text = text.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher_round"', 1)
    manifest.write_text(text, encoding='utf-8')

print('Launcher icon patched successfully.')
