import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: Color(0xFF050816),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const VerticalRacerProApp());
}

class VerticalRacerProApp extends StatelessWidget {
  const VerticalRacerProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'جاده بی‌پایان',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFF050816),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF36D8FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(),
      ),
    );
  }
}

class StorageKeys {
  static const highScore = 'vrp_high_score';
  static const totalCoins = 'vrp_total_coins';
  static const bestLevel = 'vrp_best_level';
  static const selectedCar = 'vrp_selected_car';
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  int _highScore = 0;
  int _coins = 0;
  int _bestLevel = 1;
  int _selectedCar = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    _loadStats();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _highScore = prefs.getInt(StorageKeys.highScore) ?? 0;
      _coins = prefs.getInt(StorageKeys.totalCoins) ?? 0;
      _bestLevel = prefs.getInt(StorageKeys.bestLevel) ?? 1;
      _selectedCar = prefs.getInt(StorageKeys.selectedCar) ?? 0;
    });
  }

  Future<void> _startGame() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => Directionality(
          textDirection: TextDirection.rtl,
          child: GameScreen(carIndex: _selectedCar),
        ),
      ),
    );
    await _loadStats();
  }

  Future<void> _openGarage() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const Directionality(
          textDirection: TextDirection.rtl,
          child: GarageScreen(),
        ),
      ),
    );
    await _loadStats();
  }

  void _showGuide() {
    HapticFeedback.selectionClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
          decoration: premiumPanelDecoration(radius: 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Icon(Icons.info_rounded, color: Color(0xFFFFD166), size: 28),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'راهنمای بازی',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const _GuideTile(icon: Icons.touch_app_rounded, title: 'کنترل سریع', text: 'سمت چپ یا راست صفحه را لمس کن تا ماشین بین ۳ لاین جابه‌جا شود.'),
              const _GuideTile(icon: Icons.flash_on_rounded, title: 'سختی مرحله‌ای', text: 'هرچه امتیاز بالاتر برود، سرعت جاده، تعداد ماشین‌ها و فاصله موانع سخت‌تر می‌شود.'),
              const _GuideTile(icon: Icons.shield_rounded, title: 'آیتم‌های ویژه', text: 'سپر جلوی برخورد را می‌گیرد، آهنربا سکه‌ها را جذب می‌کند و نیترو امتیاز را سریع‌تر بالا می‌برد.'),
              const _GuideTile(icon: Icons.local_fire_department_rounded, title: 'هدف', text: 'زنده بمان، سکه جمع کن، رکوردت را بشکن و ماشین‌های جدید را امتحان کن.'),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1D3474), Color(0xFF0B1332), Color(0xFF050816)],
              ),
            ),
            child: Stack(
              children: [
                Positioned.fill(child: HomeBackdrop(progress: _controller.value)),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(child: MiniStatCard(title: 'رکورد', value: _highScore.toString(), icon: Icons.emoji_events_rounded)),
                            const SizedBox(width: 12),
                            Expanded(child: MiniStatCard(title: 'سکه', value: _coins.toString(), icon: Icons.monetization_on_rounded)),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(child: MiniStatCard(title: 'بهترین مرحله', value: _bestLevel.toString(), icon: Icons.local_fire_department_rounded, compact: true)),
                            const SizedBox(width: 12),
                            Expanded(child: MiniStatCard(title: 'ماشین', value: CarSkins.all[_selectedCar].name, icon: Icons.directions_car_filled_rounded, compact: true)),
                          ],
                        ),
                        const Spacer(),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                          decoration: premiumPanelDecoration(radius: 38),
                          child: Column(
                            children: [
                              ShaderMask(
                                shaderCallback: (rect) => const LinearGradient(
                                  colors: [Color(0xFFFFFFFF), Color(0xFFC7F4FF)],
                                ).createShader(rect),
                                child: const Text(
                                  'جاده بی‌پایان',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 43,
                                    height: 1,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: -1.6,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 9),
                              Text(
                                'مسابقه عمودی، سریع، نئونی و مرحله‌ای',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.70),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 22),
                              AspectRatio(
                                aspectRatio: 1.45,
                                child: CustomPaint(
                                  painter: HeroRoadPainter(progress: _controller.value, carIndex: _selectedCar),
                                  child: const SizedBox.expand(),
                                ),
                              ),
                              const SizedBox(height: 20),
                              PremiumButton(
                                title: 'شروع بازی',
                                icon: Icons.play_arrow_rounded,
                                onPressed: _startGame,
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(child: SecondaryButton(title: 'راهنما', icon: Icons.info_outline_rounded, onPressed: _showGuide)),
                                  const SizedBox(width: 12),
                                  Expanded(child: SecondaryButton(title: 'گاراژ', icon: Icons.garage_rounded, onPressed: _openGarage)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const Spacer(),
                        Text(
                          'جاخالی بده، آیتم بگیر، سکه جمع کن و رکورد بزن.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.55),
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class GarageScreen extends StatefulWidget {
  const GarageScreen({super.key});

  @override
  State<GarageScreen> createState() => _GarageScreenState();
}

class _GarageScreenState extends State<GarageScreen> {
  int _selected = 0;
  int _coins = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _selected = prefs.getInt(StorageKeys.selectedCar) ?? 0;
      _coins = prefs.getInt(StorageKeys.totalCoins) ?? 0;
    });
  }

  Future<void> _select(int index) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(StorageKeys.selectedCar, index);
    HapticFeedback.selectionClick();
    if (!mounted) return;
    setState(() => _selected = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1D3474), Color(0xFF080D23)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              const Positioned.fill(child: StaticGarageBackdrop()),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        GlassIconButton(icon: Icons.arrow_forward_rounded, onTap: () => Navigator.pop(context)),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text('گاراژ ماشین‌ها', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: premiumPanelDecoration(radius: 22),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.monetization_on_rounded, color: Color(0xFFFFD166)),
                              const SizedBox(width: 6),
                              Text(_coins.toString(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'برای نسخه اول همه ماشین‌ها باز هستند. در نسخه‌های بعدی می‌شود خرید، ارتقا و مأموریت اضافه کرد.',
                      style: TextStyle(color: Colors.white.withOpacity(0.66), fontWeight: FontWeight.w600, height: 1.7),
                    ),
                    const SizedBox(height: 18),
                    Expanded(
                      child: ListView.separated(
                        itemCount: CarSkins.all.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 14),
                        itemBuilder: (context, index) {
                          final skin = CarSkins.all[index];
                          final selected = index == _selected;
                          return InkWell(
                            borderRadius: BorderRadius.circular(30),
                            onTap: () => _select(index),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                gradient: LinearGradient(
                                  begin: Alignment.topRight,
                                  end: Alignment.bottomLeft,
                                  colors: selected
                                      ? [skin.top.withOpacity(0.42), skin.bottom.withOpacity(0.16)]
                                      : [Colors.white.withOpacity(0.13), Colors.white.withOpacity(0.05)],
                                ),
                                border: Border.all(color: selected ? skin.top.withOpacity(0.85) : Colors.white.withOpacity(0.10), width: selected ? 1.4 : 1),
                                boxShadow: [
                                  BoxShadow(
                                    color: selected ? skin.top.withOpacity(0.22) : Colors.black.withOpacity(0.26),
                                    blurRadius: selected ? 34 : 18,
                                    offset: const Offset(0, 14),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 92,
                                    height: 92,
                                    child: CustomPaint(painter: SingleCarPainter(skin: skin, angle: -0.02)),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(skin.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                                        const SizedBox(height: 8),
                                        Text(
                                          skin.description,
                                          style: TextStyle(color: Colors.white.withOpacity(0.62), height: 1.5, fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  AnimatedContainer(
                                    duration: const Duration(milliseconds: 180),
                                    width: 42,
                                    height: 42,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: selected ? const Color(0xFF2DE1A2) : Colors.white.withOpacity(0.09),
                                      border: Border.all(color: Colors.white.withOpacity(0.16)),
                                    ),
                                    child: Icon(selected ? Icons.check_rounded : Icons.add_rounded, color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

enum RoadItemType { enemy, truck, cone, coin, shield, magnet, nitro }

class RoadItem {
  RoadItem({
    required this.id,
    required this.type,
    required this.lane,
    required this.y,
    required this.wobble,
  });

  final int id;
  final RoadItemType type;
  final int lane;
  double y;
  final double wobble;
  bool consumed = false;

  bool get isCollectible => type == RoadItemType.coin || type == RoadItemType.shield || type == RoadItemType.magnet || type == RoadItemType.nitro;
  bool get isVehicle => type == RoadItemType.enemy || type == RoadItemType.truck;
}

class SparkParticle {
  SparkParticle({required this.position, required this.velocity, required this.life, required this.color, required this.size});

  Offset position;
  Offset velocity;
  double life;
  final Color color;
  final double size;
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.carIndex});

  final int carIndex;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  static const int laneCount = 3;
  final math.Random _random = math.Random();
  late final Ticker _ticker;
  Duration _lastElapsed = Duration.zero;
  Size _size = Size.zero;
  int _nextObjectId = 1;

  bool _running = true;
  bool _gameOver = false;
  bool _saved = false;

  int _playerLane = 1;
  double _playerLaneVisual = 1;
  double _roadOffset = 0;
  double _score = 0;
  int _coins = 0;
  int _lives = 3;
  int _highScore = 0;
  int _totalCoinsBefore = 0;
  double _spawnTimer = 0.2;
  double _coinTimer = 0.65;
  double _powerTimer = 5.5;
  double _hitCooldown = 0;
  double _shieldTime = 0;
  double _magnetTime = 0;
  double _nitroTime = 0;
  double _levelBannerTime = 0;
  int _lastAnnouncedLevel = 1;

  final List<RoadItem> _items = <RoadItem>[];
  final List<SparkParticle> _particles = <SparkParticle>[];

  int get _level => math.max(1, (_score ~/ 900) + 1);
  double get _difficulty => math.min(1.0, (_level - 1) / 12.0);
  double get _baseSpeed => 285 + (_level * 19) + (_score * 0.012) + (_nitroTime > 0 ? 120 : 0);
  CarSkin get _playerSkin => CarSkins.all[widget.carIndex.clamp(0, CarSkins.all.length - 1).toInt()];

  @override
  void initState() {
    super.initState();
    _loadStats();
    _ticker = createTicker(_tick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Future<void> _loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _highScore = prefs.getInt(StorageKeys.highScore) ?? 0;
      _totalCoinsBefore = prefs.getInt(StorageKeys.totalCoins) ?? 0;
    });
  }

  Future<void> _saveGameResult() async {
    if (_saved) return;
    _saved = true;
    final prefs = await SharedPreferences.getInstance();
    final finalScore = _score.floor();
    final oldHigh = prefs.getInt(StorageKeys.highScore) ?? 0;
    final oldCoins = prefs.getInt(StorageKeys.totalCoins) ?? 0;
    final oldBestLevel = prefs.getInt(StorageKeys.bestLevel) ?? 1;
    if (finalScore > oldHigh) {
      await prefs.setInt(StorageKeys.highScore, finalScore);
    }
    await prefs.setInt(StorageKeys.totalCoins, oldCoins + _coins);
    if (_level > oldBestLevel) {
      await prefs.setInt(StorageKeys.bestLevel, _level);
    }
  }

  void _tick(Duration elapsed) {
    if (_lastElapsed == Duration.zero) {
      _lastElapsed = elapsed;
      return;
    }
    final dt = ((elapsed - _lastElapsed).inMicroseconds / 1000000.0).clamp(0.0, 0.033);
    _lastElapsed = elapsed;
    if (!_running || _gameOver || _size == Size.zero) return;
    _update(dt);
    if (mounted) setState(() {});
  }

  void _update(double dt) {
    final speed = _baseSpeed;
    _roadOffset = (_roadOffset + speed * dt) % 220;
    _score += dt * (44 + _level * 5) * (_nitroTime > 0 ? 1.45 : 1.0);
    _playerLaneVisual += (_playerLane - _playerLaneVisual) * math.min(1.0, dt * 12.0);

    if (_level > _lastAnnouncedLevel) {
      _lastAnnouncedLevel = _level;
      _levelBannerTime = 1.7;
      HapticFeedback.mediumImpact();
      _spawnLevelSparks();
    }

    _shieldTime = math.max(0, _shieldTime - dt);
    _magnetTime = math.max(0, _magnetTime - dt);
    _nitroTime = math.max(0, _nitroTime - dt);
    _hitCooldown = math.max(0, _hitCooldown - dt);
    _levelBannerTime = math.max(0, _levelBannerTime - dt);

    _spawnTimer -= dt;
    _coinTimer -= dt;
    _powerTimer -= dt;

    if (_spawnTimer <= 0) {
      _spawnObstacle();
      _spawnTimer = math.max(0.38, 1.06 - (_difficulty * 0.52) - _random.nextDouble() * 0.16);
    }

    if (_coinTimer <= 0) {
      _spawnCoinLine();
      _coinTimer = math.max(0.62, 1.28 - _difficulty * 0.38 + _random.nextDouble() * 0.24);
    }

    if (_powerTimer <= 0) {
      _spawnPowerUp();
      _powerTimer = math.max(4.4, 7.8 - _difficulty * 1.8 + _random.nextDouble() * 2.4);
    }

    for (final item in _items) {
      item.y += speed * dt * (item.type == RoadItemType.truck ? 0.92 : 1.0);
      if (_magnetTime > 0 && item.type == RoadItemType.coin) {
        final playerCenter = _playerCenter();
        final itemCenter = _itemCenter(item);
        final distance = (itemCenter - playerCenter).distance;
        if (distance < 170) {
          final dir = playerCenter - itemCenter;
          if (dir.distance > 1) {
            final pull = dir / dir.distance * 240 * dt;
            item.y += pull.dy;
          }
        }
      }
    }

    _handleCollisions();
    _items.removeWhere((item) => item.y > _size.height + 160 || item.consumed);
    _updateParticles(dt);
  }

  void _spawnObstacle() {
    final lane = _random.nextInt(laneCount);
    final roll = _random.nextDouble();
    final type = roll < 0.18 + _difficulty * 0.12 ? RoadItemType.truck : (roll < 0.74 ? RoadItemType.enemy : RoadItemType.cone);
    _items.add(RoadItem(id: _nextObjectId++, type: type, lane: lane, y: -120, wobble: _random.nextDouble() * math.pi * 2));

    if (_level >= 5 && _random.nextDouble() < 0.24) {
      final secondLane = (lane + 1 + _random.nextInt(2)) % laneCount;
      _items.add(RoadItem(id: _nextObjectId++, type: _random.nextBool() ? RoadItemType.enemy : RoadItemType.cone, lane: secondLane, y: -260, wobble: _random.nextDouble() * math.pi * 2));
    }
  }

  void _spawnCoinLine() {
    final lane = _random.nextInt(laneCount);
    final count = 3 + _random.nextInt(3);
    for (var i = 0; i < count; i++) {
      _items.add(RoadItem(id: _nextObjectId++, type: RoadItemType.coin, lane: lane, y: -95.0 - i * 58, wobble: _random.nextDouble() * math.pi * 2));
    }
  }

  void _spawnPowerUp() {
    final lane = _random.nextInt(laneCount);
    final values = [RoadItemType.shield, RoadItemType.magnet, RoadItemType.nitro];
    _items.add(RoadItem(id: _nextObjectId++, type: values[_random.nextInt(values.length)], lane: lane, y: -110, wobble: _random.nextDouble() * math.pi * 2));
  }

  void _handleCollisions() {
    final playerRect = _playerRect();
    for (final item in _items) {
      if (item.consumed) continue;
      final rect = _itemRect(item);
      if (!playerRect.overlaps(rect)) continue;

      if (item.isCollectible) {
        item.consumed = true;
        _collect(item);
      } else if (_hitCooldown <= 0) {
        item.consumed = true;
        _hit();
      }
    }
  }

  void _collect(RoadItem item) {
    HapticFeedback.selectionClick();
    final center = _itemCenter(item);
    switch (item.type) {
      case RoadItemType.coin:
        _coins += _magnetTime > 0 ? 2 : 1;
        _score += 25;
        _spawnSparks(center, const Color(0xFFFFD166), 12);
        break;
      case RoadItemType.shield:
        _shieldTime = 7.0;
        _score += 80;
        _spawnSparks(center, const Color(0xFF6C63FF), 18);
        break;
      case RoadItemType.magnet:
        _magnetTime = 7.5;
        _score += 80;
        _spawnSparks(center, const Color(0xFF36D8FF), 18);
        break;
      case RoadItemType.nitro:
        _nitroTime = 5.5;
        _score += 100;
        _spawnSparks(center, const Color(0xFFFF5EA8), 22);
        break;
      default:
        break;
    }
  }

  void _hit() {
    if (_shieldTime > 0) {
      _shieldTime = math.max(0, _shieldTime - 2.0);
      _hitCooldown = 0.8;
      HapticFeedback.lightImpact();
      _spawnSparks(_playerCenter(), const Color(0xFF6C63FF), 26);
      return;
    }
    _lives -= 1;
    _hitCooldown = 1.05;
    _nitroTime = 0;
    HapticFeedback.heavyImpact();
    _spawnSparks(_playerCenter(), const Color(0xFFFF4B5C), 32);
    if (_lives <= 0) {
      _endGame();
    }
  }

  void _endGame() {
    _gameOver = true;
    _running = false;
    _saveGameResult();
    HapticFeedback.heavyImpact();
    setState(() {});
  }

  void _restart() {
    HapticFeedback.mediumImpact();
    setState(() {
      _running = true;
      _gameOver = false;
      _saved = false;
      _lastElapsed = Duration.zero;
      _playerLane = 1;
      _playerLaneVisual = 1;
      _roadOffset = 0;
      _score = 0;
      _coins = 0;
      _lives = 3;
      _spawnTimer = 0.2;
      _coinTimer = 0.65;
      _powerTimer = 5.5;
      _hitCooldown = 0;
      _shieldTime = 0;
      _magnetTime = 0;
      _nitroTime = 0;
      _levelBannerTime = 0;
      _lastAnnouncedLevel = 1;
      _items.clear();
      _particles.clear();
    });
  }

  void _moveLeft() {
    if (!_running || _gameOver) return;
    if (_playerLane > 0) {
      setState(() => _playerLane--);
      HapticFeedback.selectionClick();
    }
  }

  void _moveRight() {
    if (!_running || _gameOver) return;
    if (_playerLane < laneCount - 1) {
      setState(() => _playerLane++);
      HapticFeedback.selectionClick();
    }
  }

  Offset _laneCenter(int lane, [double? y]) {
    final road = _roadRect();
    final laneWidth = road.width / laneCount;
    return Offset(road.left + laneWidth * (lane + 0.5), y ?? 0);
  }

  Rect _roadRect() {
    final safeTop = 122.0;
    return Rect.fromLTWH(_size.width * 0.12, safeTop, _size.width * 0.76, _size.height - safeTop + 80);
  }

  Offset _playerCenter() {
    final y = _size.height * 0.78;
    final road = _roadRect();
    final laneWidth = road.width / laneCount;
    return Offset(road.left + laneWidth * (_playerLaneVisual + 0.5), y);
  }

  Rect _playerRect() {
    final center = _playerCenter();
    return Rect.fromCenter(center: center, width: 52, height: 88).deflate(8);
  }

  Offset _itemCenter(RoadItem item) {
    final x = _laneCenter(item.lane).dx;
    return Offset(x, item.y);
  }

  Rect _itemRect(RoadItem item) {
    final center = _itemCenter(item);
    switch (item.type) {
      case RoadItemType.truck:
        return Rect.fromCenter(center: center, width: 68, height: 112).deflate(8);
      case RoadItemType.enemy:
        return Rect.fromCenter(center: center, width: 58, height: 96).deflate(8);
      case RoadItemType.cone:
        return Rect.fromCenter(center: center, width: 46, height: 54).deflate(5);
      case RoadItemType.coin:
        return Rect.fromCircle(center: center, radius: 23);
      case RoadItemType.shield:
      case RoadItemType.magnet:
      case RoadItemType.nitro:
        return Rect.fromCircle(center: center, radius: 28);
    }
  }

  void _spawnSparks(Offset center, Color color, int count) {
    for (var i = 0; i < count; i++) {
      final angle = _random.nextDouble() * math.pi * 2;
      final speed = 48 + _random.nextDouble() * 145;
      _particles.add(
        SparkParticle(
          position: center,
          velocity: Offset(math.cos(angle) * speed, math.sin(angle) * speed),
          life: 0.42 + _random.nextDouble() * 0.42,
          color: color,
          size: 2.0 + _random.nextDouble() * 4.5,
        ),
      );
    }
  }

  void _spawnLevelSparks() {
    final center = Offset(_size.width / 2, _size.height * 0.24);
    _spawnSparks(center, const Color(0xFF36D8FF), 26);
    _spawnSparks(center, const Color(0xFFFFD166), 20);
  }

  void _updateParticles(double dt) {
    for (final p in _particles) {
      p.life -= dt;
      p.position += p.velocity * dt;
      p.velocity = Offset(p.velocity.dx * 0.94, p.velocity.dy * 0.94 + 30 * dt);
    }
    _particles.removeWhere((p) => p.life <= 0);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) {
        if (!didPop) return;
        _saveGameResult();
      },
      child: Scaffold(
        body: LayoutBuilder(
          builder: (context, constraints) {
            _size = Size(constraints.maxWidth, constraints.maxHeight);
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (details) {
                if (_gameOver) return;
                if (details.localPosition.dy > constraints.maxHeight - 140) return;
                if (details.localPosition.dx < constraints.maxWidth / 2) {
                  _moveLeft();
                } else {
                  _moveRight();
                }
              },
              child: Stack(
                children: [
                  Positioned.fill(
                    child: CustomPaint(
                      painter: GameWorldPainter(
                        roadOffset: _roadOffset,
                        items: List<RoadItem>.of(_items),
                        particles: List<SparkParticle>.of(_particles),
                        playerLaneVisual: _playerLaneVisual,
                        score: _score,
                        level: _level,
                        playerSkin: _playerSkin,
                        shieldTime: _shieldTime,
                        magnetTime: _magnetTime,
                        nitroTime: _nitroTime,
                        hitCooldown: _hitCooldown,
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                      child: Column(
                        children: [
                          GameHud(
                            score: _score.floor(),
                            coins: _coins,
                            level: _level,
                            highScore: math.max(_highScore, _score.floor()),
                            lives: _lives,
                          ),
                          const Spacer(),
                          PowerStatusBar(shield: _shieldTime, magnet: _magnetTime, nitro: _nitroTime),
                          const SizedBox(height: 18),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              ControlPad(icon: Icons.chevron_left_rounded, onTap: _moveLeft),
                              ControlPad(icon: Icons.chevron_right_rounded, onTap: _moveRight),
                            ],
                          ),
                          const SizedBox(height: 14),
                        ],
                      ),
                    ),
                  ),
                  if (_levelBannerTime > 0)
                    Positioned(
                      top: math.max(150, constraints.maxHeight * 0.20),
                      left: 36,
                      right: 36,
                      child: IgnorePointer(
                        child: Opacity(
                          opacity: math.min(1, _levelBannerTime / 0.35),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
                            decoration: premiumPanelDecoration(radius: 26),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.local_fire_department_rounded, color: Color(0xFFFFD166), size: 30),
                                const SizedBox(width: 10),
                                Text('مرحله $_level', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                                const SizedBox(width: 8),
                                Text('سخت‌تر شد!', style: TextStyle(color: Colors.white.withOpacity(0.72), fontWeight: FontWeight.w800)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (_gameOver)
                    Positioned.fill(
                      child: GameOverOverlay(
                        score: _score.floor(),
                        coins: _coins,
                        level: _level,
                        totalCoins: _totalCoinsBefore + _coins,
                        isRecord: _score.floor() > _highScore,
                        onRestart: _restart,
                        onHome: () async {
                          await _saveGameResult();
                          if (mounted) Navigator.pop(context);
                        },
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class GameWorldPainter extends CustomPainter {
  const GameWorldPainter({
    required this.roadOffset,
    required this.items,
    required this.particles,
    required this.playerLaneVisual,
    required this.score,
    required this.level,
    required this.playerSkin,
    required this.shieldTime,
    required this.magnetTime,
    required this.nitroTime,
    required this.hitCooldown,
  });

  final double roadOffset;
  final List<RoadItem> items;
  final List<SparkParticle> particles;
  final double playerLaneVisual;
  final double score;
  final int level;
  final CarSkin playerSkin;
  final double shieldTime;
  final double magnetTime;
  final double nitroTime;
  final double hitCooldown;

  @override
  void paint(Canvas canvas, Size size) {
    _drawBackground(canvas, size);
    final road = Rect.fromLTWH(size.width * 0.12, 122, size.width * 0.76, size.height - 42);
    _drawRoad(canvas, size, road);
    _drawItems(canvas, road, size);
    _drawPlayer(canvas, road, size);
    _drawParticles(canvas);
    _drawVignette(canvas, size);
  }

  void _drawBackground(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF1A2E6B), Color(0xFF101B3B), Color(0xFF050816)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final glowPaint = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 46);
    glowPaint.color = const Color(0xFF36D8FF).withOpacity(0.12);
    canvas.drawCircle(Offset(size.width * 0.18, size.height * 0.52), 150, glowPaint);
    glowPaint.color = const Color(0xFF6C63FF).withOpacity(0.11);
    canvas.drawCircle(Offset(size.width * 0.84, size.height * 0.30), 170, glowPaint);
    glowPaint.color = const Color(0xFF2DE1A2).withOpacity(0.08);
    canvas.drawCircle(Offset(size.width * 0.50, size.height * 0.77), 140, glowPaint);

    final sidePaint = Paint()..color = Colors.white.withOpacity(0.035);
    for (var i = -1; i < 8; i++) {
      final y = ((i * 144 + roadOffset * 0.45) % (size.height + 180)) - 90;
      canvas.drawCircle(Offset(size.width * 0.065, y), 22, sidePaint);
      canvas.drawCircle(Offset(size.width * 0.935, y + 72), 22, sidePaint);
    }
  }

  void _drawRoad(Canvas canvas, Size size, Rect road) {
    final roadRRect = RRect.fromRectAndRadius(road.inflate(2), const Radius.circular(38));
    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.36)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 34);
    canvas.drawRRect(roadRRect.shift(const Offset(0, 12)), shadow);

    final roadPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF27314D), Color(0xFF151D31), Color(0xFF11182B)],
      ).createShader(road);
    canvas.drawRRect(roadRRect, roadPaint);

    final laneWidth = road.width / 3;
    final centerGlow = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFF36D8FF).withOpacity(0.13), Colors.transparent],
      ).createShader(Rect.fromCircle(center: road.center, radius: road.width * 0.95));
    canvas.drawRRect(roadRRect, centerGlow);

    final borderGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..color = const Color(0xFF36D8FF).withOpacity(0.52)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    canvas.drawLine(Offset(road.left + 3, road.top), Offset(road.left + 3, road.bottom), borderGlow);
    canvas.drawLine(Offset(road.right - 3, road.top), Offset(road.right - 3, road.bottom), borderGlow);

    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = const Color(0xFF5EE7FF).withOpacity(0.65);
    canvas.drawLine(Offset(road.left + 3, road.top), Offset(road.left + 3, road.bottom), border);
    canvas.drawLine(Offset(road.right - 3, road.top), Offset(road.right - 3, road.bottom), border);

    final dashPaint = Paint()
      ..color = Colors.white.withOpacity(0.58)
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;
    final dashGlow = Paint()
      ..color = Colors.white.withOpacity(0.14)
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    for (var lane = 1; lane <= 2; lane++) {
      final x = road.left + laneWidth * lane;
      for (double y = road.top - 220 + roadOffset; y < road.bottom + 160; y += 168) {
        canvas.drawLine(Offset(x, y), Offset(x, y + 70), dashGlow);
        canvas.drawLine(Offset(x, y), Offset(x, y + 70), dashPaint);
      }
    }

    final speedPaint = Paint()
      ..color = Colors.white.withOpacity(nitroTime > 0 ? 0.16 : 0.07)
      ..strokeWidth = nitroTime > 0 ? 3 : 2
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 10; i++) {
      final x = road.left + 18 + (i * 37 % road.width);
      final y = (roadOffset * 2.1 + i * 93) % road.height + road.top;
      canvas.drawLine(Offset(x, y), Offset(x, y + 22 + level.toDouble()), speedPaint);
    }
  }

  void _drawItems(Canvas canvas, Rect road, Size size) {
    final laneWidth = road.width / 3;
    for (final item in items) {
      final center = Offset(road.left + laneWidth * (item.lane + 0.5), item.y);
      if (item.y < -160 || item.y > size.height + 160) continue;
      switch (item.type) {
        case RoadItemType.enemy:
          final skin = CarSkins.enemy[(item.id + level) % CarSkins.enemy.length];
          _drawCar(canvas, center, skin, 1.0, enemy: true);
          break;
        case RoadItemType.truck:
          _drawTruck(canvas, center);
          break;
        case RoadItemType.cone:
          _drawCone(canvas, center);
          break;
        case RoadItemType.coin:
          _drawCoin(canvas, center, item.wobble + score / 160);
          break;
        case RoadItemType.shield:
          _drawPower(canvas, center, Icons.shield_rounded, const Color(0xFF6C63FF));
          break;
        case RoadItemType.magnet:
          _drawPower(canvas, center, Icons.auto_awesome_rounded, const Color(0xFF36D8FF));
          break;
        case RoadItemType.nitro:
          _drawPower(canvas, center, Icons.bolt_rounded, const Color(0xFFFF5EA8));
          break;
      }
    }
  }

  void _drawPlayer(Canvas canvas, Rect road, Size size) {
    final laneWidth = road.width / 3;
    final y = size.height * 0.78;
    final center = Offset(road.left + laneWidth * (playerLaneVisual + 0.5), y);
    final blink = hitCooldown > 0 && (hitCooldown * 16).floor().isEven;
    if (shieldTime > 0 || magnetTime > 0 || nitroTime > 0) {
      final auraPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = shieldTime > 0 ? 4 : 3
        ..color = (shieldTime > 0
                ? const Color(0xFF6C63FF)
                : magnetTime > 0
                    ? const Color(0xFF36D8FF)
                    : const Color(0xFFFF5EA8))
            .withOpacity(0.56)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
      canvas.drawCircle(center, magnetTime > 0 ? 72 : 55, auraPaint);
    }
    if (!blink) {
      _drawCar(canvas, center, playerSkin, 1.08, enemy: false, nitro: nitroTime > 0);
    }
  }

  void _drawParticles(Canvas canvas) {
    for (final p in particles) {
      final alpha = p.life.clamp(0.0, 1.0);
      final paint = Paint()..color = p.color.withOpacity(alpha);
      canvas.drawCircle(p.position, p.size * alpha, paint);
    }
  }

  void _drawVignette(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final paint = Paint()
      ..shader = RadialGradient(
        center: Alignment.center,
        radius: 0.98,
        colors: [Colors.transparent, Colors.black.withOpacity(0.36)],
        stops: const [0.62, 1.0],
      ).createShader(rect);
    canvas.drawRect(rect, paint);
  }

  void _drawCar(Canvas canvas, Offset center, CarSkin skin, double scale, {required bool enemy, bool nitro = false}) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);
    final shadow = Paint()
      ..color = skin.top.withOpacity(enemy ? 0.18 : 0.28)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: const Offset(0, 10), width: 62, height: 92), const Radius.circular(24)), shadow);

    if (nitro) {
      final flamePaint = Paint()
        ..shader = const LinearGradient(colors: [Color(0xFFFFD166), Color(0xFFFF5EA8), Colors.transparent]).createShader(const Rect.fromLTWH(-20, 38, 40, 60));
      final flame = Path()
        ..moveTo(-16, 38)
        ..quadraticBezierTo(0, 100, 16, 38)
        ..quadraticBezierTo(0, 56, -16, 38);
      canvas.drawPath(flame, flamePaint);
    }

    final body = RRect.fromRectAndRadius(const Rect.fromLTWH(-30, -48, 60, 96), const Radius.circular(26));
    final bodyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [skin.top, skin.bottom],
      ).createShader(body.outerRect);
    canvas.drawRRect(body, bodyPaint);

    final highlight = Paint()
      ..shader = LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Colors.white.withOpacity(0.22), Colors.transparent, Colors.white.withOpacity(0.12)],
      ).createShader(body.outerRect);
    canvas.drawRRect(body, highlight);

    final cabin = RRect.fromRectAndRadius(const Rect.fromLTWH(-20, -28, 40, 40), const Radius.circular(14));
    canvas.drawRRect(cabin, Paint()..color = const Color(0xFF15213B).withOpacity(0.82));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-12, -12, 24, 46), const Radius.circular(10)), Paint()..color = Colors.white.withOpacity(0.42));

    final lightPaint = Paint()..color = enemy ? const Color(0xFFFF5EA8) : const Color(0xFFFFF0A8);
    canvas.drawCircle(const Offset(-15, -39), 7, lightPaint);
    canvas.drawCircle(const Offset(15, -39), 7, lightPaint);

    final wheelPaint = Paint()..color = const Color(0xFF03060D);
    for (final x in [-35.0, 35.0]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 6, -34, 12, 28), const Radius.circular(8)), wheelPaint);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 6, 12, 12, 28), const Radius.circular(8)), wheelPaint);
    }
    canvas.restore();
  }

  void _drawTruck(Canvas canvas, Offset center) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.28)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-38, -60, 76, 120), const Radius.circular(20)), shadow);
    final body = RRect.fromRectAndRadius(const Rect.fromLTWH(-34, -58, 68, 116), const Radius.circular(18));
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFC857), Color(0xFFE85D04)],
        ).createShader(body.outerRect),
    );
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-24, -42, 48, 34), const Radius.circular(12)), Paint()..color = const Color(0xFF17213A).withOpacity(0.86));
    canvas.drawRect(const Rect.fromLTWH(-24, 5, 48, 44), Paint()..color = Colors.white.withOpacity(0.12));
    final wheel = Paint()..color = const Color(0xFF03060D);
    for (final x in [-40.0, 40.0]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 7, -38, 14, 32), const Radius.circular(8)), wheel);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 7, 20, 14, 32), const Radius.circular(8)), wheel);
    }
    canvas.restore();
  }

  void _drawCone(Canvas canvas, Offset center) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    final path = Path()
      ..moveTo(0, -30)
      ..lineTo(-26, 24)
      ..lineTo(26, 24)
      ..close();
    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawPath(path.shift(const Offset(0, 8)), shadow);
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(colors: [Color(0xFFFFD166), Color(0xFFFF6B35)]).createShader(const Rect.fromLTWH(-26, -30, 52, 54)),
    );
    final stripe = Paint()..color = Colors.white.withOpacity(0.78);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-16, 0, 32, 6), const Radius.circular(4)), stripe);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-20, 18, 40, 8), const Radius.circular(4)), Paint()..color = const Color(0xFF141A2E));
    canvas.restore();
  }

  void _drawCoin(Canvas canvas, Offset center, double t) {
    final pulse = 1 + math.sin(t * 3) * 0.05;
    final glow = Paint()
      ..color = const Color(0xFFFFD166).withOpacity(0.22)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawCircle(center, 26 * pulse, glow);
    canvas.drawCircle(center, 18 * pulse, Paint()..color = const Color(0xFFFFD166));
    canvas.drawCircle(center, 13 * pulse, Paint()..color = const Color(0xFFFFB703));
    final textPainter = TextPainter(
      text: const TextSpan(text: r'$', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF553C00), fontSize: 21)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(canvas, center - Offset(textPainter.width / 2, textPainter.height / 2));
  }

  void _drawPower(Canvas canvas, Offset center, IconData icon, Color color) {
    final glow = Paint()
      ..color = color.withOpacity(0.24)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13);
    canvas.drawCircle(center, 30, glow);
    canvas.drawCircle(center, 24, Paint()..color = color.withOpacity(0.95));
    canvas.drawCircle(center, 17, Paint()..color = Colors.white.withOpacity(0.20));
    final tp = TextPainter(
      text: TextSpan(text: String.fromCharCode(icon.codePoint), style: TextStyle(fontFamily: icon.fontFamily, package: icon.fontPackage, fontSize: 24, color: Colors.white)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant GameWorldPainter oldDelegate) => true;
}

class GameHud extends StatelessWidget {
  const GameHud({super.key, required this.score, required this.coins, required this.level, required this.highScore, required this.lives});

  final int score;
  final int coins;
  final int level;
  final int highScore;
  final int lives;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: premiumPanelDecoration(radius: 28, opacity: 0.11),
      child: Row(
        children: [
          Expanded(child: HudItem(icon: Icons.speed_rounded, title: 'امتیاز', value: score.toString())),
          Expanded(child: HudItem(icon: Icons.monetization_on_rounded, title: 'سکه', value: coins.toString())),
          Expanded(child: HudItem(icon: Icons.local_fire_department_rounded, title: 'مرحله', value: level.toString())),
          Expanded(child: HudItem(icon: Icons.emoji_events_rounded, title: 'رکورد', value: highScore.toString())),
          SizedBox(
            width: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (i) {
                return Icon(
                  i < lives ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  size: 17,
                  color: i < lives ? const Color(0xFFFF5EA8) : Colors.white.withOpacity(0.32),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

class HudItem extends StatelessWidget {
  const HudItem({super.key, required this.icon, required this.title, required this.value});
  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: const Color(0xFFFFD166), size: 22),
        const SizedBox(height: 4),
        Text(title, style: TextStyle(color: Colors.white.withOpacity(0.58), fontSize: 10, fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class PowerStatusBar extends StatelessWidget {
  const PowerStatusBar({super.key, required this.shield, required this.magnet, required this.nitro});
  final double shield;
  final double magnet;
  final double nitro;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _PowerPill(title: 'سپر', icon: Icons.shield_rounded, active: shield > 0, value: shield),
        const SizedBox(width: 8),
        _PowerPill(title: 'آهنربا', icon: Icons.auto_awesome_rounded, active: magnet > 0, value: magnet),
        const SizedBox(width: 8),
        _PowerPill(title: 'نیترو', icon: Icons.bolt_rounded, active: nitro > 0, value: nitro),
      ],
    );
  }
}

class _PowerPill extends StatelessWidget {
  const _PowerPill({required this.title, required this.icon, required this.active, required this.value});
  final String title;
  final IconData icon;
  final bool active;
  final double value;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: active ? Colors.white.withOpacity(0.16) : Colors.black.withOpacity(0.20),
        border: Border.all(color: active ? const Color(0xFF36D8FF).withOpacity(0.55) : Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 17, color: active ? const Color(0xFFFFD166) : Colors.white.withOpacity(0.35)),
          const SizedBox(width: 5),
          Text(active ? '${value.ceil()}s' : title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: active ? Colors.white : Colors.white.withOpacity(0.38))),
        ],
      ),
    );
  }
}

class ControlPad extends StatelessWidget {
  const ControlPad({super.key, required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 118,
        height: 84,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Colors.white.withOpacity(0.20), Colors.white.withOpacity(0.07)],
          ),
          border: Border.all(color: Colors.white.withOpacity(0.18)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.30), blurRadius: 22, offset: const Offset(0, 12)),
          ],
        ),
        child: Icon(icon, size: 52, color: Colors.white.withOpacity(0.95)),
      ),
    );
  }
}

class GameOverOverlay extends StatelessWidget {
  const GameOverOverlay({
    super.key,
    required this.score,
    required this.coins,
    required this.level,
    required this.totalCoins,
    required this.isRecord,
    required this.onRestart,
    required this.onHome,
  });

  final int score;
  final int coins;
  final int level;
  final int totalCoins;
  final bool isRecord;
  final VoidCallback onRestart;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ui.ImageFilter.blur(sigmaX: 8, sigmaY: 8),
      child: Container(
        color: Colors.black.withOpacity(0.46),
        child: Center(
          child: Container(
            margin: const EdgeInsets.all(22),
            padding: const EdgeInsets.all(22),
            decoration: premiumPanelDecoration(radius: 34, opacity: 0.15),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(isRecord ? Icons.emoji_events_rounded : Icons.sports_motorsports_rounded, size: 58, color: const Color(0xFFFFD166)),
                const SizedBox(height: 10),
                Text(
                  isRecord ? 'رکورد جدید!' : 'بازی تمام شد',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 31, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  'امتیازت ثبت شد. دوباره تلاش کن و مرحله بالاتری بزن.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white.withOpacity(0.63), fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(child: ResultBox(title: 'امتیاز', value: score.toString(), icon: Icons.speed_rounded)),
                    const SizedBox(width: 10),
                    Expanded(child: ResultBox(title: 'سکه', value: '+$coins', icon: Icons.monetization_on_rounded)),
                    const SizedBox(width: 10),
                    Expanded(child: ResultBox(title: 'مرحله', value: level.toString(), icon: Icons.local_fire_department_rounded)),
                  ],
                ),
                const SizedBox(height: 10),
                ResultBox(title: 'کل سکه‌ها بعد از این بازی', value: totalCoins.toString(), icon: Icons.account_balance_wallet_rounded, wide: true),
                const SizedBox(height: 18),
                PremiumButton(title: 'دوباره بازی کن', icon: Icons.refresh_rounded, onPressed: onRestart),
                const SizedBox(height: 10),
                SecondaryButton(title: 'برگشت به صفحه اصلی', icon: Icons.home_rounded, onPressed: onHome),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ResultBox extends StatelessWidget {
  const ResultBox({super.key, required this.title, required this.value, required this.icon, this.wide = false});
  final String title;
  final String value;
  final IconData icon;
  final bool wide;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: wide ? 16 : 8, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: const Color(0xFFFFD166), size: 22),
          const SizedBox(width: 7),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.56), fontSize: 11, fontWeight: FontWeight.w700)),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MiniStatCard extends StatelessWidget {
  const MiniStatCard({super.key, required this.title, required this.value, required this.icon, this.compact = false});
  final String title;
  final String value;
  final IconData icon;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: compact ? 78 : 96,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: premiumPanelDecoration(radius: 24, opacity: 0.10),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFFFD166), size: compact ? 26 : 32),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(color: Colors.white.withOpacity(0.58), fontSize: compact ? 12 : 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 18 : 24, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class PremiumButton extends StatelessWidget {
  const PremiumButton({super.key, required this.title, required this.icon, required this.onPressed});
  final String title;
  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 74,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.zero,
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        ),
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(colors: [Color(0xFF36D8FF), Color(0xFF6C63FF)]),
            boxShadow: [
              BoxShadow(color: const Color(0xFF36D8FF).withOpacity(0.30), blurRadius: 28, offset: const Offset(0, 14)),
            ],
          ),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white)),
                const SizedBox(width: 10),
                Icon(icon, color: Colors.white, size: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SecondaryButton extends StatelessWidget {
  const SecondaryButton({super.key, required this.title, required this.icon, required this.onPressed});
  final String title;
  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 58,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, color: Colors.white.withOpacity(0.78)),
        label: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: Colors.white.withOpacity(0.12)),
          backgroundColor: Colors.white.withOpacity(0.08),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
      ),
    );
  }
}

class GlassIconButton extends StatelessWidget {
  const GlassIconButton({super.key, required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 48,
        height: 48,
        decoration: premiumPanelDecoration(radius: 18, opacity: 0.10),
        child: Icon(icon, color: Colors.white, size: 28),
      ),
    );
  }
}

class _GuideTile extends StatelessWidget {
  const _GuideTile({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white.withOpacity(0.07),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF36D8FF).withOpacity(0.15)),
            child: Icon(icon, color: const Color(0xFFFFD166)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 4),
                Text(text, style: TextStyle(color: Colors.white.withOpacity(0.65), height: 1.6, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

BoxDecoration premiumPanelDecoration({double radius = 28, double opacity = 0.12}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topRight,
      end: Alignment.bottomLeft,
      colors: [Colors.white.withOpacity(opacity + 0.05), Colors.white.withOpacity(opacity * 0.38)],
    ),
    border: Border.all(color: Colors.white.withOpacity(0.12)),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.30), blurRadius: 30, offset: const Offset(0, 16)),
      BoxShadow(color: const Color(0xFF36D8FF).withOpacity(0.08), blurRadius: 34, offset: const Offset(0, 10)),
    ],
  );
}

class HomeBackdrop extends StatelessWidget {
  const HomeBackdrop({super.key, required this.progress});
  final double progress;

  @override
  Widget build(BuildContext context) => CustomPaint(painter: HomeBackdropPainter(progress: progress));
}

class HomeBackdropPainter extends CustomPainter {
  const HomeBackdropPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.fill;
    p.color = const Color(0xFF36D8FF).withOpacity(0.09);
    canvas.drawCircle(Offset(size.width * 0.10, size.height * (0.18 + math.sin(progress * math.pi * 2) * 0.02)), 150, p);
    p.color = const Color(0xFF6C63FF).withOpacity(0.12);
    canvas.drawCircle(Offset(size.width * 0.90, size.height * 0.42), 180, p);
    p.color = const Color(0xFFFFD166).withOpacity(0.07);
    canvas.drawCircle(Offset(size.width * 0.18, size.height * 0.84), 170, p);

    final dot = Paint()..color = Colors.white.withOpacity(0.055);
    for (var i = 0; i < 18; i++) {
      final x = (i * 73.0 + progress * 36) % size.width;
      final y = (i * 127.0 + progress * 160) % size.height;
      canvas.drawCircle(Offset(x, y), 2.0 + (i % 4), dot);
    }
  }

  @override
  bool shouldRepaint(covariant HomeBackdropPainter oldDelegate) => oldDelegate.progress != progress;
}

class StaticGarageBackdrop extends StatelessWidget {
  const StaticGarageBackdrop({super.key});

  @override
  Widget build(BuildContext context) => CustomPaint(painter: StaticGarageBackdropPainter());
}

class StaticGarageBackdropPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.045);
    for (var i = 0; i < 12; i++) {
      canvas.drawCircle(Offset(size.width * ((i * 37 % 100) / 100), size.height * ((i * 61 % 100) / 100)), 18 + (i % 4) * 8, paint);
    }
  }

  @override
  bool shouldRepaint(covariant StaticGarageBackdropPainter oldDelegate) => false;
}

class HeroRoadPainter extends CustomPainter {
  const HeroRoadPainter({required this.progress, required this.carIndex});
  final double progress;
  final int carIndex;

  @override
  void paint(Canvas canvas, Size size) {
    final road = RRect.fromRectAndRadius(Rect.fromCenter(center: size.center(Offset.zero), width: size.width * 0.58, height: size.height * 0.96), const Radius.circular(32));
    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);
    canvas.drawRRect(road.shift(const Offset(0, 8)), shadow);
    canvas.drawRRect(
      road,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF202A47), Color(0xFF11182A)],
        ).createShader(road.outerRect),
    );
    final lanePaint = Paint()
      ..color = Colors.white.withOpacity(0.56)
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    final x = road.outerRect.center.dx;
    for (double y = -70 + progress * 130; y < size.height + 60; y += 92) {
      canvas.drawLine(Offset(x, y), Offset(x, y + 42), lanePaint);
    }
    final carCenter = Offset(size.width / 2, size.height * 0.56 + math.sin(progress * math.pi * 2) * 4);
    SingleCarPainter(skin: CarSkins.all[carIndex.clamp(0, CarSkins.all.length - 1).toInt()], angle: 0).paintAt(canvas, carCenter, 1.28);
  }

  @override
  bool shouldRepaint(covariant HeroRoadPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.carIndex != carIndex;
}

class SingleCarPainter extends CustomPainter {
  const SingleCarPainter({required this.skin, this.angle = 0});
  final CarSkin skin;
  final double angle;

  void paintAt(Canvas canvas, Offset center, double scale) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    canvas.scale(scale);
    final shadow = Paint()
      ..color = skin.top.withOpacity(0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-28, -44, 56, 92).shift(const Offset(0, 8)), const Radius.circular(24)), shadow);
    final body = RRect.fromRectAndRadius(const Rect.fromLTWH(-29, -48, 58, 96), const Radius.circular(26));
    canvas.drawRRect(
      body,
      Paint()
        ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [skin.top, skin.bottom]).createShader(body.outerRect),
    );
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-18, -28, 36, 38), const Radius.circular(13)), Paint()..color = const Color(0xFF14213B).withOpacity(0.90));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-9, -10, 18, 44), const Radius.circular(8)), Paint()..color = Colors.white.withOpacity(0.40));
    canvas.drawCircle(const Offset(-14, -38), 7, Paint()..color = const Color(0xFFFFF0A8));
    canvas.drawCircle(const Offset(14, -38), 7, Paint()..color = const Color(0xFFFFF0A8));
    final wheel = Paint()..color = const Color(0xFF03060D);
    for (final x in [-34.0, 34.0]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 6, -32, 12, 28), const Radius.circular(8)), wheel);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 6, 12, 12, 28), const Radius.circular(8)), wheel);
    }
    canvas.restore();
  }

  @override
  void paint(Canvas canvas, Size size) => paintAt(canvas, size.center(Offset.zero), 1);

  @override
  bool shouldRepaint(covariant SingleCarPainter oldDelegate) => oldDelegate.skin != skin || oldDelegate.angle != angle;
}

class CarSkin {
  const CarSkin({required this.name, required this.description, required this.top, required this.bottom});
  final String name;
  final String description;
  final Color top;
  final Color bottom;
}

class CarSkins {
  static const all = <CarSkin>[
    CarSkin(name: 'آبی نئونی', description: 'متعادل، خوش‌فرم و مناسب شروع بازی.', top: Color(0xFF38DDF8), bottom: Color(0xFF1FB6D3)),
    CarSkin(name: 'بنفش توربو', description: 'ظاهر سریع‌تر با حس نیترو و سرعت.', top: Color(0xFF7C6CFF), bottom: Color(0xFF4F46E5)),
    CarSkin(name: 'طلایی شهر', description: 'ماشین نمایشی با رنگ گرم و پرنور.', top: Color(0xFFFFC857), bottom: Color(0xFFF59E0B)),
    CarSkin(name: 'سبز لیزری', description: 'ظاهر اسپرت و آینده‌نگر برای رکوردزنی.', top: Color(0xFF2DE1A2), bottom: Color(0xFF0EA876)),
  ];

  static const enemy = <CarSkin>[
    CarSkin(name: 'قرمز', description: '', top: Color(0xFFFF5EA8), bottom: Color(0xFFEF233C)),
    CarSkin(name: 'نارنجی', description: '', top: Color(0xFFFFB703), bottom: Color(0xFFFB8500)),
    CarSkin(name: 'یخی', description: '', top: Color(0xFFA0E9FF), bottom: Color(0xFF3A86FF)),
    CarSkin(name: 'سبز', description: '', top: Color(0xFF80ED99), bottom: Color(0xFF2D6A4F)),
  ];
}
